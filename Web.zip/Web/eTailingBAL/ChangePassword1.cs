#region Header
/*========================================================================================
'	Module Name			        : ChangePassword
'	Purpose				        : Modifying Password
'	Program Name		        : ChangePassword1.cs
'	Program Version		        : 1.0
'	Author Name			        : PMS - Deeparekha
'	Table(s) Used			    : Nil
'	Stored Procedure(s) Used	: PMS_SP_LOGINMASTER
'	View(s) Used		        : Nil
'	Include File(s) Used        : HovServices.RMO.dll
'	Date Started		        : 21 Sep 2009
'	From Page 			        : ChangePassword.aspx.cs
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By         Date Started            Description
'----------------------------------------------------------------------------------------
'=======================================================================================*/
#endregion

#region Namespaces
using System.Data;
using System.ComponentModel;
//using HOVDAL;
#endregion

#region Main
namespace eTailingBAL
{
    /// <summary>
    /// Summary description for Login1
    /// </summary>
    public class ChangePassword1
    {
        public static WebServiceClass WSC = new WebServiceClass();
        public static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
        private string _strUserName = string.Empty;
        private string _strUserID = string.Empty;
        private string _strOldPassword = string.Empty;
        private string _strEmail = string.Empty;
        private string _strNewPassword = string.Empty;
        private int _intActive;
        private string _strUsrSeqID;

        public string UserName
        {
            get { return _strUserName; }
            set { _strUserName = value; }
        }

        public string UserID
        {
            get { return _strUserID; }
            set { _strUserID = value; }
        }

        public string OldPassword
        {
            get { return _strOldPassword; }
            set { _strOldPassword = value; }
        }

        public string NewPassword
        {
            get { return _strNewPassword; }
            set { _strNewPassword = value; }
        }

        public int Active
        {
            get { return _intActive; }
            set { _intActive = value; }
        }

        public string Email
        {
            get { return _strEmail; }
            set { _strEmail = value; }
        }
        public string UserSeqID
        {
            get { return _strUsrSeqID; }
            set { _strUsrSeqID = value; }
        }


        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public static DataTable ChangePassword(ChangePassword1 Ch)
        {
            eTailingBAL.HOVDAL.SqlParameter[] Params =new eTailingBAL.HOVDAL.SqlParameter[4];

            Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[0].ParameterName = "@USERLOGINID";
            Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[0].Size = 15;
            Params[0].Value = Ch.UserName;

            Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[1].ParameterName = "@PASSWORD";
            Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[1].Size = 50;
            Params[1].Value = Ch.OldPassword;

            Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[2].ParameterName = "@NEWPASSWORD";
            Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[2].Size = 50;
            Params[2].Value = Ch.NewPassword;

            Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[3].ParameterName = "@MODE";
            Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[3].Size = 2;
            Params[3].Value = "U";

            DataTable DT = new DataTable();
            DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGINMASTER", Params);
            if (dsUserInfo.Tables.Count > 0)
                DT = dsUserInfo.Tables[0];
            return DT;
        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public static DataTable ChangePassword(string userName, string oldEncPassword,string newEncPassword)
        {
            eTailingBAL.HOVDAL.SqlParameter[] Params =new eTailingBAL.HOVDAL.SqlParameter[3];

            Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[0].ParameterName = "@USERLOGINID";
            Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[0].Size = 15;
            Params[0].Value = userName;

            Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[1].ParameterName = "@PASSWORD";
            Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[1].Size = 50;
            Params[1].Value = oldEncPassword;

            Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
            Params[2].ParameterName = "@NEWPASSWORD";
            Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
            Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
            Params[2].Size = 50;
            Params[2].Value = newEncPassword;

            DataTable DT = new DataTable();
            DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_ChangePassword", Params);
            if (dsUserInfo.Tables.Count > 0)
                DT = dsUserInfo.Tables[0];
            return DT;
        }
    }
}
#endregion
