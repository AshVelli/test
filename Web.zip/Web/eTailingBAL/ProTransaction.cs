using System;
using System.Data;

namespace eTailingBAL
{       
     public class ProTransaction
     {
          private static WebServiceClass WSC = new WebServiceClass();
          private static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
          //#Default Constructor
          public ProTransaction()
          {
               //
               // TODO: Add constructor logic here
               //
          }
          #region only for providerregiteration_variables

          private string _strUserLoginID = string.Empty;
          private string _strPassword = string.Empty;

          private string _strFirstName = string.Empty;
          private string _strMiddleName = string.Empty;
          private string _strLastName = string.Empty;
          private string _strCompanyURL = string.Empty;

          private string _strCardType = string.Empty;
          private string _strCardHolderName = string.Empty;
          private string _strCardNumber = string.Empty;
          private string _strCardCVV = string.Empty;
          private string _strEXPIRYDate = string.Empty;

          private int _intprdActiveStatus = 1;
          private int _intprdApproval = 0;
          private int _intUserSeqID = 0;
          private string _strCardorCheck = "";

          private int _intBillingType = 1;
          private string _strEMailID = string.Empty;
          private string _strAddress1 = string.Empty;
          private string _strAddress2 = string.Empty;
          private string _strCity = string.Empty;
          private string _strstate = string.Empty;
          private string _strCountry = string.Empty;
          private string _strZip = string.Empty;
          private string _strPhone = string.Empty;
          private string _strPhoneExtn = string.Empty;
          private string _strFax = string.Empty;
          private string _strMobile = string.Empty;
          private string _strPayAddress1 = string.Empty;
          private string _strPayAddress2 = string.Empty;
          private string _strPayCity = string.Empty;
          private string _strPaystate = string.Empty;
          private string _strPayCountry = string.Empty;
          private string _strPayZip = string.Empty;
          private string _strSecQuesId1 = string.Empty;
          private string _strAnswer1 = string.Empty;
          private string _strSecQuesId2 = string.Empty;
          private string _strAnswer2 = string.Empty;
          private string _strPayer = string.Empty;

          private decimal _CreditAmount_Bal = 0;

          private int intConfirmationFlg = 0;
          private string _strPayerShortName = string.Empty;
          private string _strSuffix = string.Empty;
          private string _strRoleSeqID = string.Empty;

          private string _strType = string.Empty;
          private string _strCCEmail = string.Empty; //For BSP Registration Purpose
          private string _strGroupName = string.Empty; //For BSP Registration Purpose

          public string CCEmail
          {
               get { return _strCCEmail; }
               set { _strCCEmail = value; }
          }

          public string GroupName
          {
               get { return _strGroupName; }
               set { _strGroupName = value; }
          }

          public string Type
          {
               get { return _strType; }
               set { _strType = value; }
          }

          public string RoleSeqID
          {
               get { return _strRoleSeqID; }
               set { _strRoleSeqID = value; }
          }

          public string Suffix
          {
               get { return _strSuffix; }
               set { _strSuffix = value; }
          }

          public string PayerShortName
          {
               get { return _strPayerShortName; }
               set { _strPayerShortName = value; }
          }


          public int ConfirmationFlg
          {
               get { return intConfirmationFlg; }
               set { intConfirmationFlg = value; }
          }

          public decimal CreditAmount_Bal
          {
               get { return _CreditAmount_Bal; }
               set { _CreditAmount_Bal = value; }
          }

          public string Payer
          {
               get { return _strPayer; }
               set { _strPayer = value; }
          }

          public string SecQuesId1
          {
               get { return _strSecQuesId1; }
               set { _strSecQuesId1 = value; }
          }

          public string Answer1
          {
               get { return _strAnswer1; }
               set { _strAnswer1 = value; }
          }

          public string SecQuesId2
          {
               get { return _strSecQuesId2; }
               set { _strSecQuesId2 = value; }
          }

          public string Answer2
          {
               get { return _strAnswer2; }
               set { _strAnswer2 = value; }
          }

          public int Approval
          {
               get { return _intprdApproval; }
               set { _intprdApproval = value; }

          }

          public string UserLoginID
          {
               get { return _strUserLoginID; }
               set { _strUserLoginID = value; }
          }

          public string Password
          {
               get { return _strPassword; }
               set { _strPassword = value; }
          }

          public string FirstName
          {
               get { return _strFirstName; }
               set { _strFirstName = value; }
          }

          public string MiddleName
          {
               get { return _strMiddleName; }
               set { _strMiddleName = value; }
          }

          public string LastName
          {
               get { return _strLastName; }
               set { _strLastName = value; }
          }

          public string Address1
          {
               get { return _strAddress1; }
               set { _strAddress1 = value; }
          }

          public string Address2
          {
               get { return _strAddress2; }
               set { _strAddress2 = value; }
          }

          public string City
          {
               get { return _strCity; }
               set { _strCity = value; }
          }

          public string state
          {
               get { return _strstate; }
               set { _strstate = value; }
          }

          public string Country
          {
               get { return _strCountry; }
               set { _strCountry = value; }
          }

          public string Zip
          {
               get { return _strZip; }
               set { _strZip = value; }
          }

          public string Phone
          {
               get { return _strPhone; }
               set { _strPhone = value; }
          }

          public string Fax
          {
               get { return _strFax; }
               set { _strFax = value; }
          }

          public string EMailID
          {
               get { return _strEMailID; }
               set { _strEMailID = value; }
          }

          public string CompanyURL
          {
               get { return _strCompanyURL; }
               set { _strCompanyURL = value; }
          }

          public int prdActiveStatus
          {
               get { return _intprdActiveStatus; }
               set { _intprdActiveStatus = value; }
          }

          public string CardType
          {
               get { return _strCardType; }
               set { _strCardType = value; }
          }

          public string CardHolderName
          {
               get { return _strCardHolderName; }
               set { _strCardHolderName = value; }
          }

          public string CardNumber
          {
               get { return _strCardNumber; }
               set { _strCardNumber = value; }
          }

          public string CardCVV
          {
               get { return _strCardCVV; }
               set { _strCardCVV = value; }
          }

          public string EXPIRYDate
          {
               get { return _strEXPIRYDate; }
               set { _strEXPIRYDate = value; }
          }

          public int UserSeqID
          {
               get { return _intUserSeqID; }
               set { _intUserSeqID = value; }
          }

          public string CardorCheck
          {
               get { return _strCardorCheck; }
               set { _strCardorCheck = value; }
          }

          public int BillingType
          {
               get { return _intBillingType; }
               set { _intBillingType = value; }
          }

          public string PhoneExtn
          {
               get { return _strPhoneExtn; }
               set { _strPhoneExtn = value; }
          }

          public string Mobile
          {
               get { return _strMobile; }
               set { _strMobile = value; }
          }

          public string PayAddress1
          {
               get { return _strPayAddress1; }
               set { _strPayAddress1 = value; }
          }

          public string PayAddress2
          {
               get { return _strPayAddress2; }
               set { _strPayAddress2 = value; }
          }

          public string PayCity
          {
               get { return _strPayCity; }
               set { _strPayCity = value; }
          }

          public string Paystate
          {
               get { return _strPaystate; }
               set { _strPaystate = value; }
          }

          public string PayCountry
          {
               get { return _strPayCountry; }
               set { _strPayCountry = value; }
          }

          public string PayZip
          {
               get { return _strPayZip; }
               set { _strPayZip = value; }
          }

          public string PGApprovalCode
          {
               get { return strPGApprovalCode; }
               set { strPGApprovalCode = value; }
          }

          public string PGAuthCode
          {
               get { return strPGAuthCode; }
               set { strPGAuthCode = value; }
          }

          public string PGPNRef
          {
               get { return strPGPNRef; }
               set { strPGPNRef = value; }
          }

          private string _eSort;

          public string ESort
          {
               get { return _eSort; }
               set { _eSort = value; }
          }

          private string _Payers;

          public string Payers
          {
               get { return _Payers; }
               set { _Payers = value; }
          }



          private string strPGApprovalCode = string.Empty;
          private string strPGAuthCode = string.Empty;
          private string strPGPNRef = string.Empty;

          #endregion

          public static DataTable CheckUserInfo(string UserName, string Password, string Mode)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[3];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = UserName;

               Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[1].ParameterName = "@PASSWORD";
               Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[1].Size = 50;
               Params[1].Value = Password;

               Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[2].ParameterName = "@MODE";
               Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[2].Size = 2;
               Params[2].Value = Mode;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGINMASTER", Params);
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }

          public static DataTable CheckInfo(string UserName)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = UserName;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGIN", Params);
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }

          public static DataTable GetUserSecQuest(string username)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = username;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetUserSecurityQuest", Params);
               //PMS_SP_GetUserSecureQuest
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }

          public static DataTable CheckUserSecurity(string username, string ans1, string Quest1, string Email, string Mobile, string Mode)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[6];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = username;

               Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[1].ParameterName = "@Ans1";
               Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[1].Size = 200;
               Params[1].Value = ans1;

               Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[2].ParameterName = "@Quest1";
               Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               Params[2].Size = 20;
               Params[2].Value = Quest1;

               Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[3].ParameterName = "@EmailID";
               Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[3].Size = 50;
               Params[3].Value = Email;

               Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[4].ParameterName = "@Mobile";
               Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[4].Size = 200;
               Params[4].Value = Mobile;

               Params[5] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[5].ParameterName = "@Mode";
               Params[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[5].Size = 50;
               Params[5].Value = Mode;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_VerifySecurityQA", Params);
               //PMS_SP_GetUserSecure
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }

          public static DataTable CheckEmailInfo(string email, string mobile)
          {
               DataTable DT = new DataTable();
               try
               {
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[3];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@EmailID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar; //Suresh -01-Apr-2011
                    Params[0].Size = 200;
                    Params[0].Value = email;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@Mobile";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar; //Rakesh April 09 2011
                    Params[1].Size = 200;
                    Params[1].Value = mobile;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@MODE";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar; //Suresh -01-Apr-2011
                    Params[2].Size = 2;
                    Params[2].Value = "FU";


                    DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGINMASTER", Params);
                    if (dsUserInfo.Tables.Count > 0)
                         DT = dsUserInfo.Tables[0];
               }
               catch (Exception ex)
               {
                    throw ex;
               }
               return DT;
          }

          public static DataTable GetUserSecQuestForEmailMobile(string Email, string Mobile)
          {
               DataTable DT = new DataTable();
               try
               {
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[2];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@EmailID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[0].Size = 100;
                    Params[0].Value = Email;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@MobileNo";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[1].Size = 30;
                    Params[1].Value = Mobile;

                    DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetUserSecurityQuestFormEmail", Params); //PMS_SP_GetUserSecureQuestForEmail
                    if (dsUserInfo.Tables.Count > 0)
                         DT = dsUserInfo.Tables[0];

               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "BLL_ForgotPassword.cs", "", 0, "GetUserSecQuestForEmail");
                    throw ex;
               }
               return DT;
          }

          public static DataSet GetCountryNames()
          {
               eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
               return WSC.HDAL.ExecuteDataset(GlobalVal.strcon, cmt, "ET_SP_GetCountryList".ToString());
          }

          public static DataSet GetStateNames()
          {
               eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
               return WSC.HDAL.ExecuteDataset(GlobalVal.strcon, cmt, GlobalVal.StoreProcedure.ET_SP_GetStateList.ToString());
          }

          public static DataSet GetQuestions()
          {
               eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
               return WSC.HDAL.ExecuteDataset(GlobalVal.strcon, cmt, GlobalVal.StoreProcedure.ET_SP_SecQuestion.ToString());
          }

          public static bool CheckPrvAvailability(string UserLoginID)
          {
               bool blflg = false;

               try
               {
                    eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] SQPM = new eTailingBAL.HOVDAL.SqlParameter[1];

                    SQPM[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    SQPM[0].ParameterName = "@UserLoginID";
                    SQPM[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    SQPM[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    SQPM[0].Size = 15;
                    SQPM[0].Value = UserLoginID;

                    int isexist =
                        (int)
                            WSC.HDAL.ExecuteScalar(GlobalVal.strcon, cmt,
                                GlobalVal.StoreProcedure.ET_SP_CheckAvailability.ToString(), SQPM);
                    if (isexist > 0)
                    {
                         blflg = true;
                    }
               }
               catch (Exception ex)
               {
                    throw ex;
               }
               return blflg;
          }

          public static string[] RegProviderInfo(ProTransaction PR)
          {
               string[] strOutputValues = new string[2];
               try
               {
                    eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[44];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@UserLoginID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[0].Size = 15;
                    Params[0].Value = PR.UserLoginID;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@Password";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[1].Size = -1;
                    Params[1].Value = PR.Password;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@FirstName";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[2].Size = 50;
                    Params[2].Value = PR.FirstName;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@MiddleName";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[3].Size = 50;
                    Params[3].Value = PR.MiddleName;

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[4].ParameterName = "@LastName";
                    Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[4].Size = 100;
                    Params[4].Value = PR.LastName;

                    Params[5] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[5].ParameterName = "@EMailID";
                    Params[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[5].Size = 100;
                    Params[5].Value = PR.EMailID;

                    Params[6] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[6].ParameterName = "@CompanyURL";
                    Params[6].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[6].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[6].Size = 160;
                    Params[6].Value = PR.CompanyURL;

                    Params[7] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[7].ParameterName = "@prdActiveStatus";
                    Params[7].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[7].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[7].Size = 4;
                    Params[7].Value = PR.prdActiveStatus;

                    Params[8] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[8].ParameterName = "@Address1";
                    Params[8].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[8].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[8].Size = 300;
                    Params[8].Value = PR.Address1;

                    Params[9] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[9].ParameterName = "@Address2";
                    Params[9].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[9].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[9].Size = 300;
                    Params[9].Value = PR.Address2;

                    Params[10] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[10].ParameterName = "@City";
                    Params[10].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[10].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[10].Size = 300;
                    Params[10].Value = PR.City;

                    Params[11] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[11].ParameterName = "@state";
                    Params[11].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[11].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[11].Size = 300;
                    Params[11].Value = PR.state;

                    Params[12] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[12].ParameterName = "@Country";
                    Params[12].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[12].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[12].Size = 300;
                    Params[12].Value = PR.Country;

                    Params[13] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[13].ParameterName = "@Zip";
                    Params[13].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[13].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[13].Size = 300;
                    Params[13].Value = PR.Zip;

                    Params[14] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[14].ParameterName = "@Phone";
                    Params[14].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[14].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[14].Size = 300;
                    Params[14].Value = PR.Phone;

                    Params[15] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[15].ParameterName = "@Fax";
                    Params[15].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[15].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[15].Size = 300;
                    Params[15].Value = PR.Fax;

                    Params[16] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[16].ParameterName = "@PhoneExtn";
                    Params[16].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[16].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[16].Size = 300;
                    Params[16].Value = PR.PhoneExtn;

                    Params[17] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[17].ParameterName = "@Mobile";
                    Params[17].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[17].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[17].Size = 300;
                    Params[17].Value = PR.Mobile;

                    Params[18] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[18].ParameterName = "@CardHolderName";
                    Params[18].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[18].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[18].Size = 300;
                    Params[18].Value = PR.CardHolderName;

                    Params[19] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[19].ParameterName = "@CardNumber";
                    Params[19].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[19].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[19].Size = 350;
                    Params[19].Value = PR.CardNumber;

                    Params[20] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[20].ParameterName = "@Esort";
                    Params[20].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[20].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[20].Size = 30;
                    Params[20].Value = PR.ESort;

                    Params[21] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[21].ParameterName = "@EXPIRYDate";
                    Params[21].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[21].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[21].Size = 300;
                    Params[21].Value = PR.EXPIRYDate;

                    Params[22] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[22].ParameterName = "@CardOrCheck";
                    Params[22].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[22].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[22].Size = 10;
                    Params[22].Value = PR.CardorCheck;

                    Params[23] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[23].ParameterName = "@CardType";
                    Params[23].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[23].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[23].Size = 20;
                    Params[23].Value = PR.CardType;

                    Params[24] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[24].ParameterName = "@PayAddress1";
                    Params[24].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[24].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[24].Size = 300;
                    Params[24].Value = PR.PayAddress1;

                    Params[25] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[25].ParameterName = "@PayAddress2";
                    Params[25].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[25].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[25].Size = 300;
                    Params[25].Value = PR.PayAddress2;

                    Params[26] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[26].ParameterName = "@PayCity";
                    Params[26].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[26].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[26].Size = 300;
                    Params[26].Value = PR.PayCity;

                    Params[27] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[27].ParameterName = "@Paystate";
                    Params[27].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[27].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[27].Size = 100;
                    Params[27].Value = PR.Paystate;

                    Params[28] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[28].ParameterName = "@PayCountry";
                    Params[28].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[28].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[28].Size = 300;
                    Params[28].Value = PR.PayCountry;

                    Params[29] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[29].ParameterName = "@PayZip";
                    Params[29].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[29].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[29].Size = 300;
                    Params[29].Value = PR.PayZip;

                    Params[30] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[30].ParameterName = "@SecQuesId1";
                    Params[30].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[30].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.BigInt;
                    Params[30].Size = 15;
                    Params[30].Value = PR.SecQuesId1;

                    Params[31] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[31].ParameterName = "@Answer1";
                    Params[31].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[31].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[31].Size = 300;
                    Params[31].Value = PR.Answer1;

                    Params[32] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[32].ParameterName = "@SecQuesId2";
                    Params[32].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[32].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.BigInt;
                    Params[32].Size = 15;
                    Params[32].Value = PR.SecQuesId2;

                    Params[33] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[33].ParameterName = "@Answer2";
                    Params[33].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[33].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[33].Size = 300;
                    Params[33].Value = PR.Answer2;

                    Params[34] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[34].ParameterName = "@PGApprovalCode";
                    Params[34].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[34].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[34].Size = 50;
                    Params[34].Value = PR.PGApprovalCode;

                    Params[35] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[35].ParameterName = "@PGAuthCode";
                    Params[35].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[35].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[35].Size = 50;
                    Params[35].Value = PR.PGAuthCode;

                    Params[36] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[36].ParameterName = "@PGPNRef";
                    Params[36].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[36].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[36].Size = 50;
                    Params[36].Value = PR.PGPNRef;

                    Params[37] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[37].ParameterName = "@ConfirmationFlg";
                    Params[37].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[37].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[37].Size = 4;
                    Params[37].Value = PR.ConfirmationFlg;

                    Params[38] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[38].ParameterName = "@Suffix";
                    Params[38].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[38].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[38].Size = 20;
                    Params[38].Value = PR.Suffix;

                    Params[39] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[39].ParameterName = "@BillingType";
                    Params[39].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[39].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[39].Size = 4;
                    Params[39].Value = PR.BillingType;

                    Params[40] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[40].ParameterName = "@UserCode";
                    Params[40].Direction = eTailingBAL.HOVDAL.ParameterDirection.Output;
                    Params[40].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[40].Size = 7;


                    Params[41] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[41].ParameterName = "@UserSeqID";
                    Params[41].Direction = eTailingBAL.HOVDAL.ParameterDirection.Output;
                    Params[41].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[41].Size = 10;


                    Params[42] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[42].ParameterName = "@PayerName";
                    Params[42].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[42].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[42].Size = 250;
                    Params[42].Value = PR.Payers;

                    Params[43] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[43].ParameterName = "@CARDCVV";
                    Params[43].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[43].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[43].Value = PR.CardCVV;
                    eTailingBAL.HOVDAL.OutParams[] OPR = WSC.HDAL.ExecuteScalarOP(GlobalVal.strcon, cmt, "ET_SP_ProviderReg", Params);
                    strOutputValues = new string[2];
                    if (OPR != null && OPR.Length > 0)
                    {
                         strOutputValues[0] = OPR[0].OParamValue.ToString();
                         strOutputValues[1] = OPR[1].OParamValue.ToString();
                    }
               }
               catch (Exception ex)
               {
                    strOutputValues[0] = "0";
               }
               return strOutputValues;
          }

          public void UpdateProfile(ProTransaction mUserInfo)
          {
               try
               {
                    eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[21];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@FirstName",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 50,
                         Value = mUserInfo.FirstName
                    };

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@MiddleName",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 50,
                         Value = mUserInfo.MiddleName
                    };

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@LastName",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 100,
                         Value = mUserInfo.LastName
                    };

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@EMailID",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 100,
                         Value = mUserInfo.EMailID
                    };

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@CompanyURL",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 160,
                         Value = mUserInfo.CompanyURL
                    };

                    Params[5] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Suffix",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 20,
                         Value = mUserInfo.Suffix
                    };

                    Params[6] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Address1",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Address1
                    };

                    Params[7] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Address2",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Address2
                    };

                    Params[8] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@City",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.City
                    };

                    Params[9] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@state",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.state
                    };

                    Params[10] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Country",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Country
                    };

                    Params[11] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Zip",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Zip
                    };

                    Params[12] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Phone",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Phone
                    };

                    Params[13] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PhoneExtn",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PhoneExtn
                    };

                    Params[14] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Mobile",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Mobile
                    };

                    Params[15] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Fax",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Fax
                    };

                    Params[16] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@SecQuesId1",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.BigInt,
                         Size = 15,
                         Value = mUserInfo.SecQuesId1
                    };

                    Params[17] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Answer1",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Answer1
                    };

                    Params[18] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@SecQuesId2",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.BigInt,
                         Size = 15,
                         Value = mUserInfo.SecQuesId2
                    };

                    Params[19] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Answer2",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Answer2
                    };

                    Params[20] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@USERSEQID",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                         Value = mUserInfo.UserSeqID
                    };

                    WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, cmt, "ET_SP_UpdateProfile", Params);

               }
               catch (Exception ex)
               {
                    string error = ex.Message;
               }
          }

          public void UpdateCCInfo(ProTransaction mUserInfo)
          {

               try
               {
                    eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[14];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@CardType",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 20,
                         Value = mUserInfo.CardType
                    };

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@CardHolderName",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.CardHolderName
                    };

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@CardNumber",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 350,
                         Value = mUserInfo.CardNumber
                    };

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@EXPIRYDate",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.EXPIRYDate
                    };

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PayAddress1",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PayAddress1
                    };

                    Params[5] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PayAddress2",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PayAddress2
                    };

                    Params[6] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PayCity",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PayCity
                    };

                    Params[7] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Paystate",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 100,
                         Value = mUserInfo.Paystate
                    };

                    Params[8] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PayCountry",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PayCountry
                    };

                    Params[9] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PayZip",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PayZip
                    };

                    Params[10] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Phone",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Phone
                    };

                    Params[11] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@PhoneExtn",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.PhoneExtn
                    };

                    Params[12] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@Mobile",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                         Size = 300,
                         Value = mUserInfo.Mobile
                    };

                    Params[13] = new eTailingBAL.HOVDAL.SqlParameter
                    {
                         ParameterName = "@UserSeqID",
                         Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                         SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                         Value = mUserInfo.UserSeqID
                    };

                    WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, cmt, "ET_SP_UpdateCCInfo", Params);
               }
               catch (Exception ex)
               {
                    throw ex;
               }
          }

          public static bool CheckEmailAvailability(string emailId)
          {
               bool blflg = false;
               try
               {
                    eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] SQPM = new eTailingBAL.HOVDAL.SqlParameter[1];
                    SQPM[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    SQPM[0].ParameterName = "@EMailID";
                    SQPM[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    SQPM[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    SQPM[0].Size = 50;
                    SQPM[0].Value = emailId;
                    int isexist = (int)WSC.HDAL.ExecuteScalar(GlobalVal.strcon, cmt, "ET_SP_CheckEmailAvailability", SQPM);
                    if (isexist > 0)
                    {
                         blflg = true;
                    }
               }
               catch (Exception ex)
               {
                    throw ex;
               }
               return blflg;
          }
     }

     public class RemotePost
     {
          private System.Collections.Specialized.NameValueCollection Inputs = new System.Collections.Specialized.NameValueCollection();

          public string Url = "";
          public string Method = "post";
          public string FormName = "form1";

          public void Add(string name, string value)
          {
               Inputs.Add(name, value);
          }

          public void Post()
          {
               System.Web.HttpContext.Current.Response.Clear();
               System.Web.HttpContext.Current.Response.Write("");
               System.Web.HttpContext.Current.Response.Write(string.Format("", FormName));
               System.Web.HttpContext.Current.Response.Write(string.Format("", FormName, Method, Url));
               for (int i = 0; i < Inputs.Keys.Count; i++)
               {
                    System.Web.HttpContext.Current.Response.Write(string.Format("", Inputs.Keys[i], Inputs[Inputs.Keys[i]]));
               }
               System.Web.HttpContext.Current.Response.Write("");
               System.Web.HttpContext.Current.Response.Write("");
          }
     }
}