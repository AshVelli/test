using System;
using System.Data;
using System.ComponentModel;

namespace eTailingBAL
{
     /// <summary>
     /// Summary description for myprofileInfo
     /// </summary>
     public class myprofileInfo
     {
          public myprofileInfo()
          {
               //
               // TODO: Add constructor logic here
               //
          }

          static WebServiceClass WSC = new WebServiceClass();
          eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;

          private int _intUserSeqID = 0;

          private string _strLoginName = string.Empty;
          private string _strOrgOrLastName = string.Empty;
          private string _strLastName = string.Empty;
          private string _strFirstName = string.Empty;
          private string _strMiddleName = string.Empty;

          private string _strAddress1 = string.Empty;
          private string _strAddress2 = string.Empty;
          private string _strCity = string.Empty;
          private string _strstate = string.Empty;
          private string _strCountry = string.Empty;
          private string _strZip = string.Empty;

          private string _strPhone = string.Empty;
          private string _strPhoneExtn = string.Empty;
          private string _strEMailID = string.Empty;
          private string _strFax = string.Empty;
          private string _strMobile = string.Empty;
          private string _strCompanyURL = string.Empty;

          private string _strEIN = string.Empty;
          private string _strTAXID = string.Empty;
          private string _strNPI = string.Empty;
          private string _strContactPreference = string.Empty;

          private Int64 _strSecQuesId1 = 0;
          private string _strQueName1 = string.Empty;
          private string _strQueName2 = string.Empty;

          private string _strAnswer1 = string.Empty;
          private Int64 _strSecQuesId2 = 0;
          private string _strAnswer2 = string.Empty;

          private string _strPassword = string.Empty;

          private string _strFlag = string.Empty;

          private int _intProvSeqID = 0;
          private string _strProviderPayerName = string.Empty;
          private string _strPayerShortName = string.Empty;
          private int _intActivestatus = 0;

          private int _intApprovalFlag = 0;
          private int _intBillingType = 0;

          private string _strSuffix = string.Empty;
          private string _strRoleDesc = string.Empty;

          private int _intRoleSeqID = 0;
          private int intImgStorageinDays = 0;
          private string _strImgStorageFlag = string.Empty;
          private string _strCCEMailID = string.Empty;

          private string _eSort;

          public int ImgStorageInDays
          {
               get { return intImgStorageinDays; }
               set { intImgStorageinDays = value; }
          }
          public string ImgStorageFlag
          {
               get { return _strImgStorageFlag; }
               set { _strImgStorageFlag = value; }
          }
          public string CCEMailID
          {
               get { return _strCCEMailID; }
               set { _strCCEMailID = value; }
          }
          public string LoginName
          {
               get { return _strLoginName; }
               set { _strLoginName = value; }
          }
          public string QueName1
          {
               get { return _strQueName1; }
               set { _strQueName1 = value; }
          }
          public string QueName2
          {
               get { return _strQueName2; }
               set { _strQueName2 = value; }
          }
          public int ApprovalFlag
          {
               get { return _intApprovalFlag; }
               set { _intApprovalFlag = value; }
          }
          public int BillingType
          {
               get { return _intBillingType; }
               set { _intBillingType = value; }
          }
          public int UserSeqID
          {
               get { return _intUserSeqID; }
               set { _intUserSeqID = value; }
          }
          public string OrgOrLastName
          {
               get { return _strOrgOrLastName; }
               set { _strOrgOrLastName = value; }
          }
          public string LastName
          {
               get { return _strLastName; }
               set { _strLastName = value; }
          }
          public string FirstName
          {
               get { return _strFirstName; }
               set { _strFirstName = value; }
          }
          public string MiddleName
          {
               get { return _strMiddleName; }
               set { _strMiddleName = value; }
          }
          public string Address1
          {
               get { return _strAddress1; }
               set { _strAddress1 = value; }
          }
          public string Address2
          {
               get { return _strAddress2; }
               set { _strAddress2 = value; }
          }
          public string City
          {
               get { return _strCity; }
               set { _strCity = value; }
          }
          public string state
          {
               get { return _strstate; }
               set { _strstate = value; }
          }
          public string Country
          {
               get { return _strCountry; }
               set { _strCountry = value; }
          }
          public string Zip
          {
               get { return _strZip; }
               set { _strZip = value; }
          }
          public string Phone
          {
               get { return _strPhone; }
               set { _strPhone = value; }
          }
          public string PhoneExtn
          {
               get { return _strPhoneExtn; }
               set { _strPhoneExtn = value; }
          }
          public string EMailID
          {
               get { return _strEMailID; }
               set { _strEMailID = value; }
          }
          public string Fax
          {
               get { return _strFax; }
               set { _strFax = value; }
          }
          public string Mobile
          {
               get { return _strMobile; }
               set { _strMobile = value; }
          }
          public string CompanyURL
          {
               get { return _strCompanyURL; }
               set { _strCompanyURL = value; }
          }
          public string EIN
          {
               get { return _strEIN; }
               set { _strEIN = value; }
          }
          public string TAXID
          {
               get { return _strTAXID; }
               set { _strTAXID = value; }
          }
          public string NPI
          {
               get { return _strNPI; }
               set { _strNPI = value; }
          }
          public string ContactPreference
          {
               get { return _strContactPreference; }
               set { _strContactPreference = value; }
          }
          public Int64 SecQuesId1
          {
               get { return _strSecQuesId1; }
               set { _strSecQuesId1 = value; }
          }
          public string Answer1
          {
               get { return _strAnswer1; }
               set { _strAnswer1 = value; }
          }
          public Int64 SecQuesId2
          {
               get { return _strSecQuesId2; }
               set { _strSecQuesId2 = value; }
          }
          public string Answer2
          {
               get { return _strAnswer2; }
               set { _strAnswer2 = value; }
          }
          public string Password
          {
               get { return _strPassword; }
               set { _strPassword = value; }
          }                   
          public string Flag
          {
               get { return _strFlag; }
               set { _strFlag = value; }
          }                            
          public int ProvSeqID
          {
               get { return _intProvSeqID; }
               set { _intProvSeqID = value; }
          }                       
          public string ProviderPayerName
          {
               get { return _strProviderPayerName; }
               set { _strProviderPayerName = value; }
          } 
          public string PayerShortName
          {
               get { return _strPayerShortName; }
               set { _strPayerShortName = value; }
          }      
          public int Activestatus
          {
               get { return _intActivestatus; }
               set { _intActivestatus = value; }
          }
          public string Suffix
          {
               get { return _strSuffix; }
               set { _strSuffix = value; }
          }
          public string ESort
          {
               get { return _eSort; }
               set { _eSort = value; }
          }
          public string RoleDesc
          {
               get { return _strRoleDesc; }
               set { _strRoleDesc = value; }
          }
          public int RoleSeqID
          {
               get { return _intRoleSeqID; }
               set { _intRoleSeqID = value; }

          }

     }
}