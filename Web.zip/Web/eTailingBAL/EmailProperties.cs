﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;                 
/// <summary>
/// Summary description for ProviderMail
/// </summary>
namespace eTailingBAL
{

     public class EmailProperties
     {

          public string _strFromMailAddr = string.Empty;
          public string _strUserName = string.Empty;
          public string _strPassword = string.Empty;
          public string _strToMailAddr = string.Empty;
          public string _strURL = string.Empty;
          public string _strProviderID = string.Empty;
          public string _strCc = string.Empty;
          public string _strBcc = string.Empty;
          public string _strSub = string.Empty;
          public string _strCont = string.Empty;
          public string _strEmailConfig = string.Empty;

          public string _strCc1 = string.Empty;//Added By Durga -30 Oct 2010 RR changes 

          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;


          //Assign and Rettrive the Provider Registration Details
          public EmailProperties()
          {
          }


          public string FromMailAddress
          {
               get { return Convert.ToString(ConfigurationManager.AppSettings["FromAddress"]); }
          }

          public string ToMailAddress
          {
               get { return _strToMailAddr; }
               set { _strToMailAddr = value; }
          }

          public string UserName
          {
               get { return _strUserName; }
               set { _strUserName = value; }
          }
          public string Password
          {
               get { return _strPassword; }
               set { _strPassword = value; }
          }

          public string ProviderID
          {
               get { return _strProviderID; }
               set { _strProviderID = value; }
          }

          public string ServerURL
          {
               get { return Convert.ToString(HttpContext.Current.Session["Url"]); }
          }

          public string ContactNumber
          {
               get { return Convert.ToString(ConfigurationManager.AppSettings["Contact_No"]); }

          }

          public string MailCc
          {
               get { return _strCc = string.Empty; }
               set { _strCc = value; }
          }
          public string MailCc1
          {
               get { return _strCc1; }
               set { _strCc1 = value; }
          }
          public string MailBcc
          {
               get { return _strBcc; }

               set { _strBcc = value; }
          }

          public string MailSubject
          {
               get { return _strSub; }
               set { _strSub = value; }
          }

          public string MailContent
          {
               get { return _strCont; }
               set { _strCont = value; }
          }

          public string HostAddress
          {
               get { return Convert.ToString(ConfigurationManager.AppSettings["SmtpServer"]); }
          }
          public string GetEmailConfigStatus
          {
               get { return _strEmailConfig; }
               set { _strEmailConfig = value; }
          }

     }
}