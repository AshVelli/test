#region Header
/*========================================================================================
'	Module Name			        : ResetPassword1
'	Purpose				        : Resetting password
'	Program Name		        : ResetPassword1.cs
'	Program Version		        : 1.0
'	Author Name			        : PMS - Deepareka
'	Table(s) Used			    : Nil
'	Stored Procedure(s) Used	: PMS_SP_LOGINMASTER
'	View(s) Used		        : Nil
'	Include File(s) Used        : HovServices.RMO.dll
'	Date Started		        : 21 Sep 2009
'	From Page 			        : Nil
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By                  Date Started        Description
'----------------------------------------------------------------------------------------
'=======================================================================================*/
#endregion

#region Namespaces
using System.Data;
using System.ComponentModel;
//using HOVDAL;                
#endregion

#region Main
/// <summary>
/// Summary description for ResetPassword
/// </summary>
namespace eTailingBAL
{

     public class ResetPassword1
     {
          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
          private string _strUserName = string.Empty;
          private string _strEmail = string.Empty;
          private string _strPassword = string.Empty;
          private string _strUsrSeqID = string.Empty;

          public string UserName
          {
               get { return _strUserName; }
               set { _strUserName = value; }
          }

          public string Email
          {
               get { return _strEmail; }
               set { _strEmail = value; }
          }

          public string Password
          {
               get { return _strPassword; }
               set { _strPassword = value; }
          }

          public string UserSeqID
          {
               get { return _strUsrSeqID; }
               set { _strUsrSeqID = value; }
          }
     }

}
#endregion