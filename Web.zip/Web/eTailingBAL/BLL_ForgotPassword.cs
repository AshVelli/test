#region Header
/*========================================================================================
'	Module Name			        : ForgetPassword
'	Purpose				        : Sending password to the user on request
'	Program Name		        : ForgetPassword.cs
'	Program Version		        : 1.0
'	Author Name			        : PMS - Deeparaka
'	Table(s) Used			    : Nil
'	Stored Procedure(s) Used	: PMS_SP_LOGINMASTER, PMS_SP_GetUserSecure, PMS_SP_GetUserSecureQuest
'	View(s) Used		        : Nil
'	Include File(s) Used        : Nil
'	Date Started		        : 21 Sep 2009
'	From Page 			        : Nil
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By         Date Started            Description
'----------------------------------------------------------------------------------------
'=======================================================================================*/
#endregion

#region Namespaces
using System;
using System.Data;
using System.ComponentModel;                                     
#endregion

#region Main
/// <summary>
/// Class for Forgot Password 
/// </summary>
namespace eTailingBAL
{
     public class ForgotPassword
     {
          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
          private string _strUserName = string.Empty;
          private string _strEmail = string.Empty;
          private string _strPassword = string.Empty;
          private string _strSecureAns1 = string.Empty;
          private string _strSecureAns2 = string.Empty;
          private string _strUsrSeqID = string.Empty;

          private string _strUserCode = string.Empty;
          private string _Mobile = string.Empty;

          public string UserName
          {
               get { return _strUserName; }
               set { _strUserName = value; }
          }

          public string Email
          {
               get { return _strEmail; }
               set { _strEmail = value; }
          }

          public string Password
          {
               get { return _strPassword; }
               set { _strPassword = value; }
          }
          public string SecureAns1
          {
               get { return _strSecureAns1; }
               set { _strSecureAns1 = value; }
          }
          public string SecureAns2
          {
               get { return _strSecureAns2; }
               set { _strSecureAns2 = value; }
          }

          public string UserSeqID
          {
               get { return _strUsrSeqID; }
               set { _strUsrSeqID = value; }

          }
          public string UserCode
          {
               get { return _strUserCode; }
               set { _strUserCode = value; }
          }
          public string Mobile
          {
               get { return _Mobile; }
               set { _Mobile = value; }
          }

          /// <summary>
          /// 
          /// </summary>
          /// <param name="Pass"></param>
          /// <returns></returns>
          [DataObjectMethod(DataObjectMethodType.Select, true)]
          public static DataTable CheckUserInfo(ForgotPassword Pass)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[2];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = Pass.UserName;

               Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[1].ParameterName = "@MODE";
               Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[1].Size = 2;
               Params[1].Value = "C";

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGINMASTER", Params);
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }
          /// <summary>
          /// For Verifying user answers
          /// </summary>
          /// <param name="Secure">UserName, Security Answer 1, , Security Answer 2</param>
          /// <returns>Returns user name, email id and password</returns>
          [DataObjectMethod(DataObjectMethodType.Select, true)]
          public static DataTable CheckUserSecurity(ForgotPassword Secure)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[3];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = Secure.UserName;

               Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[1].ParameterName = "@Ans1";
               Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[1].Size = 200;
               Params[1].Value = Secure.SecureAns1;

               Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[2].ParameterName = "@Ans2";
               Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[2].Size = 200;
               Params[2].Value = Secure.SecureAns2;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetUserSecure", Params);
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }
          /// <summary>
          /// For getting user security questions
          /// </summary>
          /// <param name="Secure">User Name</param>
          /// <returns>Security Question 1</returns>
          [DataObjectMethod(DataObjectMethodType.Select, true)]
          public static DataTable GetUserSecQuest(ForgotPassword Secure)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERLOGINID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 15;
               Params[0].Value = Secure.UserName;

               DataTable DT = new DataTable();
               DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetUserSecureQuest", Params);
               if (dsUserInfo.Tables.Count > 0)
                    DT = dsUserInfo.Tables[0];
               return DT;
          }

          public static DataTable CheckEmailInfo(ForgotPassword Pass)
          {
               DataTable DT = new DataTable();
               try
               {
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[3];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@EmailID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[0].Size = 200;
                    Params[0].Value = Pass.Email;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@Mobile";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[1].Size = 200;
                    Params[1].Value = Pass.Mobile;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@MODE";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[2].Size = 2;
                    Params[2].Value = "FU";


                    DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_LOGINMASTER", Params);
                    if (dsUserInfo.Tables.Count > 0)
                         DT = dsUserInfo.Tables[0];
               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "BLL_ForgotPassword.cs", "", 0, "CheckEmailInfo");
                    throw ex;
               }
               return DT;
          }

          [DataObjectMethod(DataObjectMethodType.Select, true)]
          public static DataTable GetUserSecQuestForEmailMobile(ForgotPassword Secure)
          {
               DataTable DT = new DataTable();
               try
               {
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[2];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@EmailID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[0].Size = 100;
                    Params[0].Value = Secure.Email;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@MobileNo";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[1].Size = 15;
                    Params[1].Value = Secure.Mobile;


                    DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetUserSecureQuestForEmail", Params);
                    if (dsUserInfo.Tables.Count > 0)
                         DT = dsUserInfo.Tables[0];

               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "BLL_ForgotPassword.cs", "", 0, "GetUserSecQuestForEmail");
                    throw ex;
               }
               return DT;
          }

          [DataObjectMethod(DataObjectMethodType.Select, true)]
          public static DataTable CheckEmailSecurity(ForgotPassword Secure)
          {
               DataTable DT = new DataTable();
               try
               {
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[4];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@EmailID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[0].Size = 200;
                    Params[0].Value = Secure.Email;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@Mobile";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[1].Size = 200;
                    Params[1].Value = Secure.Mobile;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@Ans1";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[2].Size = 200;
                    Params[2].Value = Secure.SecureAns1;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@Ans2";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[3].Size = 200;
                    Params[3].Value = Secure.SecureAns2;


                    DataSet dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetEmailSecure", Params);
                    if (dsUserInfo.Tables.Count > 0)
                         DT = dsUserInfo.Tables[0];
               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "BLL_ForgotPassword.cs", "", 0, "CheckEmailSecurity");
                    throw ex;
               }
               return DT;
          }                       
     }        
}
#endregion
