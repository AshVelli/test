﻿
#region Header
/*========================================================================================
'	Module Name			        : Contact Preference
'	Purpose				        : Get User Contact Details via 1]Phone,2]Email,3]FAX and 4]SMS
'	Program Name		        : ContactPreferences.cs
'	Program Version		        : 1.0
'	Author Name			        : PMS - Shanmugam.P
'	Table(s) Used			    : t_userMaster,t_Loginmaster,t_Emailqueue,t_Emailconfig
'	Stored Procedure(s) Used	: PMS_SP_EmailConfigStatus-Get Preference Code,PMS_SP_UserMasandLoginMas-Get User Login Information,PMS_SP_InsertProv_EmailQueue-Insert Email Details into Queue
'	View(s) Used		        : Nil
'   Class Files                 : Nil
'   Namespace used              : Pms
'	Include File(s) Used        : Nil
'	Date Started		        : 15/04/2010
'	From Page 			        : Nil
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By                  Date Started        Description
'----------------------------------------------------------------------------------------
'=======================================================================================*/
#endregion



using System;
using System.Data;
using System.Linq;
//using HOVDAL;        
using System.Text;
using System.Configuration;
using System.Web;

namespace eTailingBAL
{

     public class ContactPref
     {

          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;

          StringBuilder strbMailCnt = null;
          //string EmailFromAddress = Convert.ToString(ConfigurationManager.AppSettings["FromAddress"]);
          string WebConfigBCC = Convert.ToString(ConfigurationManager.AppSettings["BccAddress"]);
          string EmailToAddress = Convert.ToString(HttpContext.Current.Session["EMailID"]);
          string strEmailBCC = string.Empty;
          string strEmailCC = string.Empty;


          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Email Configuration Block Starts here<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
          #region EmailConfiguration
          //retrive provider information from Emailconfig table based on type id and active status
          private DataTable GetEmailConfigDetails(int TypeID)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@TypID";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               ProvInfoParams[0].Size = 10;
               ProvInfoParams[0].Value = TypeID;
               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_EmailConfigStatus", ProvInfoParams).Tables[0];
               return dt;
          }
          //Retrive username,password,Email from user master and login master tables
          private DataTable GetProviderLoginInfo()
          {
               eTailingBAL.HOVDAL.SqlParameter[] LoginInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               DataTable dtProvinfo = new DataTable();
               dtProvinfo = null;
               if (System.Web.HttpContext.Current.Session["providersqlID"] != null)
               {
                    LoginInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    LoginInfoParams[0].ParameterName = "@UseqID";
                    LoginInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    LoginInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    LoginInfoParams[0].Size = 10;
                    LoginInfoParams[0].Value = Convert.ToString(System.Web.HttpContext.Current.Session["providersqlID"]);
                    dtProvinfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_UserMasandLoginMas", LoginInfoParams).Tables[0];
               }
               return dtProvinfo;
          }
          //insert Provider Registration information into Emailqueue table.
          private void InsertEmailQueue(EmailProperties prm)
          {
               eTailingBAL.HOVDAL.SqlParameter[] InsertParams = new eTailingBAL.HOVDAL.SqlParameter[6];

               InsertParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[0].ParameterName = "@FrmAddr";
               InsertParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[0].Size = 100;
               InsertParams[0].Value = prm.FromMailAddress;

               InsertParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[1].ParameterName = "@ToAddr";
               InsertParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[1].Size = 1000;
               InsertParams[1].Value = prm.ToMailAddress;

               InsertParams[2] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[2].ParameterName = "@CCAddr";
               InsertParams[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[2].Size = 1000;
               InsertParams[2].Value = prm.MailCc;

               InsertParams[3] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[3].ParameterName = "@BccAddr";
               InsertParams[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[3].Size = 1000;
               InsertParams[3].Value = prm.MailBcc;

               InsertParams[4] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[4].ParameterName = "@MailSub";
               InsertParams[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[4].Size = 100;
               InsertParams[4].Value = prm.MailSubject;


               InsertParams[5] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[5].ParameterName = "@MailCont";
               InsertParams[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[5].Size = 8000;
               InsertParams[5].Value = prm.MailContent;

               WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_InsertProv_EmailQueue", InsertParams);

          }

          #region ProviderRegistration_Type1
          public void ProviderRegistrationDetails()
          {
               EmailProperties prdMail = new EmailProperties();
               string strUserCode = string.Empty;

               DataTable dtProvinfo = GetProviderLoginInfo();       //Retrive Provider Login Information
               DataTable dtMailinfo = GetEmailConfigDetails(1);       //Retrive Provider Email Informatiom for Type Id 1

               if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)             //Retrive Login information from Usermaster and Loginmaster tables
               {
                    prdMail.ToMailAddress = Convert.ToString(dtProvinfo.Rows[0]["EMailID"]);
                    prdMail.UserName = Convert.ToString(dtProvinfo.Rows[0]["UserLoginID"]);
                    prdMail.Password = Convert.ToString(dtProvinfo.Rows[0]["Password"]);
                    strUserCode = Convert.ToString(dtProvinfo.Rows[0]["UserCode"]);
               }

               if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)                                 //Get Email information from email config table
               {
                    if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")

                         prdMail.MailBcc = string.Empty;

                    else
                    {  //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');

                    }


                    if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) != "True")
                    {
                         prdMail.ToMailAddress = string.Empty;
                    }

                    prdMail.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);

                    prdMail.MailContent = ReplaceProviderRegMailArgument(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]), prdMail.UserName, prdMail.Password, strUserCode, prdMail.ServerURL);


                    InsertEmailQueue(prdMail);
               }

          }

          //Replace MailContent parameters to Provider details
          private string ReplaceProviderRegMailArgument(string MailCont, string PuserName, string Ppassword, string PprovID, string ServerURL)
          {

               PasswordEncription pwdDec = new PasswordEncription();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", PuserName);
               strbMailCnt.Replace("{1}", pwdDec.Decription(Ppassword));
               strbMailCnt.Replace("{2}", PprovID);
               strbMailCnt.Replace("{3}", ServerURL);
               return Convert.ToString(strbMailCnt);
          }

          private string ReplaceMailArgument(string MailCont, string provider, string NPI)
          {
               EmailProperties prdMail = new EmailProperties();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", provider);
               strbMailCnt.Replace("{1}", NPI);
               return Convert.ToString(strbMailCnt);
          }


          #endregion  ProviderRegistration_Type1

          #region McClaimSubmit_Type2

          public void SendMCMail(string strHTN, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtMCMail = GetEmailConfigDetails(2);          //Type ID 2
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               if (dtMCMail != null && dtMCMail.Rows.Count != 0)        //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtMCMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["McToAddress"]);
                    }
                    else
                         prdMail.ToMailAddress = string.Empty;

                    if (Convert.ToString(dtMCMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {
                         //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMCMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMCMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtMCMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtMCMail.Rows[0]["MailContent"]), strHTN, 2);

                    InsertEmailQueue(prdMail);
               }
          }

          #endregion McClaimSubmit_Type2
          #region PKClaimSubmit_Type3

          public void SendPKMail(string strHTN, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtPKMail = GetEmailConfigDetails(3);          //Type ID 3
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               if (dtPKMail != null && dtPKMail.Rows.Count != 0)        //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtPKMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["PKToAddress"]);
                    }
                    else
                         //prdMail.ToMailAddress = string.Empty;
                         prdMail.ToMailAddress = WebConfigBCC;
                    if (Convert.ToString(dtPKMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {
                         //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtPKMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtPKMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtPKMail.Rows[0]["MailSubject"]);
                    prdMail._strURL = ConfigurationManager.AppSettings["RegisterRedirectURLPK"].ToString();
                    //prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtPKMail.Rows[0]["MailContent"]), strHTN, 2);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtPKMail.Rows[0]["MailContent"]), strHTN, prdMail._strURL, 3);

                    InsertEmailQueue(prdMail);
               }
          }

          #endregion PKClaimSubmit_Type2

          #region Reject Resubmission Success Mail (HOV To Provider)

          private DataTable GetProviderContatcInfo(string userseqid)
          {
               eTailingBAL.HOVDAL.SqlParameter[] LoginInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               DataTable dtProvinfo = new DataTable();
               dtProvinfo = null;
               if (System.Web.HttpContext.Current.Session["StrThisUT"] != null)
               {
                    LoginInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    LoginInfoParams[0].ParameterName = "@UseqID";
                    LoginInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    LoginInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    LoginInfoParams[0].Size = 10;
                    LoginInfoParams[0].Value = userseqid;
                    dtProvinfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_UserMasandLoginMas", LoginInfoParams).Tables[0];
               }
               return dtProvinfo;
          }

          public void RRSendSuccessMail(string HTNvalue, string UserSeqID)
          {
               DataTable dtContacts = GetProviderContatcInfo(UserSeqID);
               EmailProperties prdMail = new EmailProperties();
               DataTable dtSuccessMail = GetEmailConfigDetails(18);         //Type ID 18        
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               if (dtSuccessMail != null && dtSuccessMail.Rows.Count != 0) //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                              if (dtContacts != null)
                              {
                                   if (dtContacts.Rows.Count > 0)
                                   {
                                        //prdMail.ToMailAddress = EmailToAddress;
                                        prdMail.ToMailAddress = Convert.ToString(dtContacts.Rows[0]["EMailID"]);
                                   }
                              }
                    }
                    else
                    {
                         prdMail.ToMailAddress = string.Empty;
                    }
                    prdMail.MailBcc = string.Empty;
                    prdMail.MailCc1 = "Puneetailing.test@banctec.in";
                    //if (Convert.ToString(dtSuccessMail.Rows[0]["AdminMail"]) != "True")
                    //{
                    //    prdMail.MailBcc = string.Empty;
                    //}
                    //else
                    //{    //Mail Bind CC Address into BCC Address          
                    //    if (!string.IsNullOrEmpty(WebConfigBCC))
                    //        strEmailBCC = WebConfigBCC;
                    //    else
                    //        strEmailBCC = string.Empty;
                    //    if (!string.IsNullOrEmpty(Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"])))
                    //    {
                    //        strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"]);
                    //    }
                    //    prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    //}
                    prdMail.MailSubject = Convert.ToString(dtSuccessMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtSuccessMail.Rows[0]["MailContent"]), HTNvalue, 3);
                    InsertEmailQueue1(prdMail);
               }
          }

          private void InsertEmailQueue1(EmailProperties prm)
          {
               eTailingBAL.HOVDAL.SqlParameter[] InsertParams = new eTailingBAL.HOVDAL.SqlParameter[6];

               InsertParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[0].ParameterName = "@FrmAddr";
               InsertParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[0].Size = 100;
               InsertParams[0].Value = prm.FromMailAddress;

               InsertParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[1].ParameterName = "@ToAddr";
               InsertParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[1].Size = 1000;
               InsertParams[1].Value = prm.ToMailAddress;

               InsertParams[2] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[2].ParameterName = "@CCAddr";
               InsertParams[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[2].Size = 1000;
               InsertParams[2].Value = prm.MailCc1;

               InsertParams[3] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[3].ParameterName = "@BccAddr";
               InsertParams[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[3].Size = 1000;
               InsertParams[3].Value = prm.MailBcc;

               InsertParams[4] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[4].ParameterName = "@MailSub";
               InsertParams[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[4].Size = 100;
               InsertParams[4].Value = prm.MailSubject;


               InsertParams[5] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[5].ParameterName = "@MailCont";
               InsertParams[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[5].Size = 8000;
               InsertParams[5].Value = prm.MailContent;

               WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_InsertProv_EmailQueue", InsertParams);

          }


          #endregion

          #region ClaimUpload_Type3
          //Send  Mail after Successful Data Entry
          public void SendSuccessMail(string HTNvalue, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtSuccessMail = GetEmailConfigDetails(3);     //Type ID 3        
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               if (dtSuccessMail != null && dtSuccessMail.Rows.Count != 0) //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = EmailToAddress;

                    }
                    else
                         prdMail.ToMailAddress = string.Empty;


                    //if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                    //{
                    //    prdMail.ToMailAddress = EmailToAddress;
                    //}


                    if (Convert.ToString(dtSuccessMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {    //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtSuccessMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtSuccessMail.Rows[0]["MailContent"]), HTNvalue, 3);

                    InsertEmailQueue(prdMail);
               }


          }

          #endregion ClaimUpload_Type3

          #region ClaimUpload_Type4
          //Failed DataEntry mail
          public void SendFailureMail(string HTNvalue, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);//Get Contact Preferences Based on UserSeqID        
               DataTable dtFailureMail = GetEmailConfigDetails(4);     //Type ID 4

               if (dtFailureMail != null && dtFailureMail.Rows.Count != 0)              //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtFailureMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = EmailToAddress;
                    }
                    else
                         prdMail.ToMailAddress = string.Empty;


                    //if (Convert.ToString(dtFailureMail.Rows[0]["CustomerMail"]) == "True")
                    //{
                    //    prdMail.ToMailAddress = EmailToAddress;

                    //}


                    if (Convert.ToString(dtFailureMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {
                         //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtFailureMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtFailureMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtFailureMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtFailureMail.Rows[0]["MailContent"]), HTNvalue, 3);

                    InsertEmailQueue(prdMail);
               }


          }
          #endregion ClaimUpload_Type4

          //#region PaymentConfirmation_Type5

          //public void SendPaymentConMail(PaymentConfirmation PCon)
          //{
          //    EmailProperties prdMail = new EmailProperties();

          //    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(PCon.UserSeqId));//Get Contact Preferences Based on UserSeqID   
          //    DataTable dtMailinfo = GetEmailConfigDetails(5);                            //Type ID 5

          //    if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)                       //Get Email information from email config table
          //    {
          //        if (intArrEmailFlag.Contains(2))
          //        {
          //            if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) == "True")
          //                prdMail.ToMailAddress = PCon.EmailID;
          //        }
          //        else
          //            prdMail.ToMailAddress = string.Empty;

          //        //if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) == "True")
          //        //{
          //        //    prdMail.ToMailAddress = PCon.EmailID;

          //        //}

          //        if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
          //        {
          //            prdMail.MailBcc = string.Empty;
          //        }
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;
          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //        }

          //        prdMail.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
          //        strbMailCnt = new StringBuilder(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]));
          //        strbMailCnt.Replace("{0}", PCon.Balance);
          //        strbMailCnt.Replace("{1}", prdMail.ServerURL);
          //        prdMail.MailContent = Convert.ToString(strbMailCnt);

          //        InsertEmailQueue(prdMail);
          //    }
          //}


          //#endregion PaymentConfirmation_Type5

          #region ForgotPassword_Type6

          public int ForgetPasswordMail(ForgotPassword FP)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(FP.UserSeqID);//Get Contact Preferences Based on UserSeqID
                    DataTable dtFPwd = GetEmailConfigDetails(6);            //Type ID 6
                    if (dtFPwd != null && dtFPwd.Rows.Count != 0)          //Get Email information from email config table
                    {
                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtFPwd.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = FP.Email;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;



                         if (Convert.ToString(dtFPwd.Rows[0]["AdminMail"]) != "True")
                              prdMail.MailBcc = string.Empty;
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtFPwd.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtFPwd.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }

                         prdMail.MailSubject = Convert.ToString(dtFPwd.Rows[0]["MailSubject"]);
                         strbMailCnt = new StringBuilder(Convert.ToString(dtFPwd.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", FP.UserName);
                         strbMailCnt.Replace("{1}", FP.Password);
                         strbMailCnt.Replace("{2}", prdMail.ServerURL);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);
                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }

               catch
               {
                    return 1;
               }

          }

          #endregion ForgotPassword_Type6

          #region ResetPassword_Type7
          public int ResetPasswordMail(ResetPassword1 RPassword)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(RPassword.UserSeqID);     //Get Contact Preferences Based on UserSeqID       
                    DataTable dtResetPWD = GetEmailConfigDetails(7);                    //Type ID 7        

                    if (dtResetPWD != null && dtResetPWD.Rows.Count != 0)                //Get Email information from email config table
                    {
                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtResetPWD.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = RPassword.Email;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;

                         //if (Convert.ToString(dtResetPWD.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = RPassword.Email;

                         //}
                         if (Convert.ToString(dtResetPWD.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtResetPWD.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtResetPWD.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }

                         prdMail.MailSubject = Convert.ToString(dtResetPWD.Rows[0]["MailSubject"]);


                         strbMailCnt = new StringBuilder(Convert.ToString(dtResetPWD.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", RPassword.UserName);
                         strbMailCnt.Replace("{1}", RPassword.Password);
                         strbMailCnt.Replace("{2}", prdMail.ServerURL);
                         strbMailCnt.Replace("{4}", prdMail.HostAddress);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);
                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }

          }

          #endregion ResetPassword_Type7

          # region ChangePassword_Type8

          //Processing Change Password request
          public int ChangePasswordMail(ChangePassword1 CHPwd)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(CHPwd.UserSeqID);                     //Get Contact Preferences Based on UserSeqID
                    DataTable dtChangePassword = GetEmailConfigDetails(8);                           //Type ID 8

                    if (dtChangePassword != null && dtChangePassword.Rows.Count != 0)              //Get Email information from email config table
                    {
                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangePassword.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;


                         //if (Convert.ToString(dtChangePassword.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}

                         if (Convert.ToString(dtChangePassword.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangePassword.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangePassword.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');


                         }
                         prdMail.MailSubject = Convert.ToString(dtChangePassword.Rows[0]["MailSubject"]);
                         strbMailCnt = new StringBuilder(Convert.ToString(dtChangePassword.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", CHPwd.UserName);
                         strbMailCnt.Replace("{1}", CHPwd.NewPassword);
                         strbMailCnt.Replace("{2}", prdMail.ServerURL);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }

          }


          #endregion ChangePassword_Type8

          #region ChangeSecurityInformation_Type9
          //Processing Security Information Change request.
          public int ChangeSecurityInfoMail(myprofileInfo MPSecurity)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(MPSecurity.UserSeqID));   //Get Contact Preferences Based on UserSeqID        
                    DataTable dtChangeSecurity = GetEmailConfigDetails(9);                              //Type ID 9      

                    if (dtChangeSecurity != null && dtChangeSecurity.Rows.Count != 0)                   //Get Email information from email config table
                    {

                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangeSecurity.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;


                         //if (Convert.ToString(dtChangeSecurity.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}                                    

                         if (Convert.ToString(dtChangeSecurity.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {  //Mail Bind CC Address into BCC Address  
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangeSecurity.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangeSecurity.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }
                         prdMail.MailSubject = Convert.ToString(dtChangeSecurity.Rows[0]["MailSubject"]);

                         prdMail.MailContent = ReplaceSecurityInfoMailArgument(Convert.ToString(dtChangeSecurity.Rows[0]["MailContent"]), MPSecurity.QueName1, MPSecurity.Answer1, MPSecurity.QueName2, MPSecurity.Answer2, prdMail.ServerURL);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }


          }

          private string ReplaceSecurityInfoMailArgument(string MailCont, string QueName1, string Answer1, string QueName2, string Answer2, string ServerURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", QueName1);
               strbMailCnt.Replace("{1}", Answer1);
               strbMailCnt.Replace("{2}", QueName2);
               strbMailCnt.Replace("{3}", Answer2);
               strbMailCnt.Replace("{4}", ServerURL);
               return Convert.ToString(strbMailCnt);

          }
          #endregion ChangeSecurityInformation_Type9

          #region ChangeNameInfo_Type10

          public int ChangeNameInfoMail(myprofileInfo MPName)
          {

               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(MPName.UserSeqID));   //Get Contact Preferences Based on UserSeqID        

                    DataTable dtChangeNameInfo = GetEmailConfigDetails(10);                          //Type ID 10


                    if (dtChangeNameInfo != null && dtChangeNameInfo.Rows.Count != 0)              //Get Email information from email config table
                    {
                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangeNameInfo.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;

                         //if (Convert.ToString(dtChangeNameInfo.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}

                         if (Convert.ToString(dtChangeNameInfo.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {

                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangeNameInfo.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangeNameInfo.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');

                         }
                         prdMail.MailSubject = Convert.ToString(dtChangeNameInfo.Rows[0]["MailSubject"]);
                         prdMail.MailContent = ReplaceNameInfoMailArgument(Convert.ToString(dtChangeNameInfo.Rows[0]["MailContent"]), MPName.LoginName, MPName.LastName, MPName.FirstName, MPName.MiddleName, MPName.EMailID, prdMail.ServerURL);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }


          }

          private string ReplaceNameInfoMailArgument(string MailCont, string LoginName, string LastName, string FirstName, string MiddleName, string EMailID, string ServerURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", LoginName);
               strbMailCnt.Replace("{1}", LastName);
               strbMailCnt.Replace("{2}", FirstName);
               strbMailCnt.Replace("{3}", MiddleName);
               strbMailCnt.Replace("{4}", EMailID);
               strbMailCnt.Replace("{5}", ServerURL);
               return Convert.ToString(strbMailCnt);
          }

          #endregion ChangeNameInfo_Type10

          #region ChangeAddressInfo_Type11

          public int ChangeAddressInfoMail(myprofileInfo MPAddress)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(MPAddress.UserSeqID));   //Get Contact Preferences Based on UserSeqID        

                    DataTable dtChangeAddress = GetEmailConfigDetails(11);                              //Type ID 11

                    if (dtChangeAddress != null && dtChangeAddress.Rows.Count != 0)                      //Get Email information from email config table
                    {

                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangeAddress.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;

                         //if (Convert.ToString(dtChangeAddress.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}


                         if (Convert.ToString(dtChangeAddress.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }

                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangeAddress.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangeAddress.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');

                         }
                         prdMail.MailSubject = Convert.ToString(dtChangeAddress.Rows[0]["MailSubject"]);
                         prdMail.MailContent = ReplaceAddressInfoMailArgument(Convert.ToString(dtChangeAddress.Rows[0]["MailContent"]), MPAddress.Address1, MPAddress.Address2, MPAddress.City, MPAddress.state, MPAddress.Country, MPAddress.Zip, prdMail.ServerURL);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }


          }

          private string ReplaceAddressInfoMailArgument(string MailCont, string Address1, string Address2, string City, string state, string Country, string Zip, string ServerURL)
          {

               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", Address1);
               strbMailCnt.Replace("{1}", Address2);
               strbMailCnt.Replace("{2}", City);
               strbMailCnt.Replace("{3}", state);
               strbMailCnt.Replace("{4}", Country);
               strbMailCnt.Replace("{5}", Zip);
               strbMailCnt.Replace("{6}", ServerURL);

               return Convert.ToString(strbMailCnt);

          }

          #endregion ChangeAddressInfo_Type11

          #region ChangeContactInfo_Type12
          public int ChangeContactInfoMail(myprofileInfo MPContact)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(MPContact.UserSeqID));   //Get Contact Preferences Based on UserSeqID     

                    DataTable dtChangeContactInfo = GetEmailConfigDetails(12);                         //Type ID 12
                    if (dtChangeContactInfo != null && dtChangeContactInfo.Rows.Count != 0)              //Get Email information from email config table
                    {

                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangeContactInfo.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;


                         //if (Convert.ToString(dtChangeContactInfo.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}



                         if (Convert.ToString(dtChangeContactInfo.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangeContactInfo.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangeContactInfo.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }
                         prdMail.MailSubject = Convert.ToString(dtChangeContactInfo.Rows[0]["MailSubject"]);
                         prdMail.MailContent = ReplaceContactInfoMailArgument(Convert.ToString(dtChangeContactInfo.Rows[0]["MailContent"]), MPContact.Phone, MPContact.PhoneExtn, MPContact.EMailID, MPContact.Fax, MPContact.Mobile, MPContact.CompanyURL, prdMail.ServerURL);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }


          }

          public string ReplaceContactInfoMailArgument(string MailCont, string Phone, string PhoneExtn, string Emailid, string Fax, string Mobile, string CompanyUrl, string ServerURl)
          {


               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", Phone);
               strbMailCnt.Replace("{1}", PhoneExtn);
               strbMailCnt.Replace("{2}", Emailid);
               strbMailCnt.Replace("{3}", Fax);
               strbMailCnt.Replace("{4}", Mobile);
               strbMailCnt.Replace("{5}", CompanyUrl);
               strbMailCnt.Replace("{6}", ServerURl);
               return Convert.ToString(strbMailCnt);
          }

          #endregion ChangeContactInfo_Type12


          #region ChangePreference_Type13

          public int ChangePreferenceInfoMail(myprofileInfo MPPreference)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(MPPreference.UserSeqID));   //Get Contact Preferences Based on UserSeqID     

                    string SetEPN = "";
                    string SetEPNval = "";
                    if (MPPreference.EIN != "")
                    {
                         SetEPN = "EIN";
                         SetEPNval = MPPreference.EIN;
                    }
                    else
                    {
                         SetEPN = "TAXID";
                         SetEPNval = MPPreference.TAXID;
                    }

                    DataTable dtChangePreference = GetEmailConfigDetails(13);               //Type ID 13     

                    if (dtChangePreference != null && dtChangePreference.Rows.Count != 0) //Get Email information from email config table
                    {
                         if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtChangePreference.Rows[0]["CustomerMail"]) == "True")
                                   prdMail.ToMailAddress = EmailToAddress;
                         }
                         else
                              prdMail.ToMailAddress = string.Empty;

                         //if (Convert.ToString(dtChangePreference.Rows[0]["CustomerMail"]) == "True")
                         //{
                         //    prdMail.ToMailAddress = EmailToAddress;

                         //}


                         if (Convert.ToString(dtChangePreference.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangePreference.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangePreference.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');

                         }
                         prdMail.MailSubject = Convert.ToString(dtChangePreference.Rows[0]["MailSubject"]);
                         prdMail.MailContent = ReplacePreferenceInfoMailArgument(Convert.ToString(dtChangePreference.Rows[0]["MailContent"]), SetEPN, SetEPNval, MPPreference.NPI, MPPreference.ContactPreference, prdMail.ServerURL);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               { return 1; }

          }

          private string ReplacePreferenceInfoMailArgument(string MailCont, string EPN, string EPNval, string NPI, string ContactPref, string ServerURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", EPN);
               strbMailCnt.Replace("{1}", EPNval);
               strbMailCnt.Replace("{2}", NPI);
               strbMailCnt.Replace("{3}", ContactPref);
               strbMailCnt.Replace("{4}", ServerURL);
               return Convert.ToString(strbMailCnt);

          }

          #endregion ChangePreference_Type13


          #region HOVUserRegistration_Type14

          //public int GenerateMail(HovRegistrationMethods PMus)
          //{

          //    try
          //    {
          //        EmailProperties prdMail = new EmailProperties();

          //        int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(PMus.UserSeqID));   //Get Contact Preferences Based on UserSeqID
          //        DataTable dtUserReg = GetEmailConfigDetails(14);                               //Type ID 14      

          //        if (dtUserReg != null && dtUserReg.Rows.Count != 0)                            //Get Email information from email config table
          //        {
          //            if (intArrEmailFlag.Contains(2))
          //            {
          //                if (Convert.ToString(dtUserReg.Rows[0]["CustomerMail"]) == "True")
          //                    prdMail.ToMailAddress = PMus.EMailID;
          //            }
          //            else
          //                prdMail.ToMailAddress = string.Empty;


          //            if (Convert.ToString(dtUserReg.Rows[0]["CustomerMail"]) == "True")
          //            {
          //                prdMail.ToMailAddress = PMus.EMailID;

          //            }

          //            if (Convert.ToString(dtUserReg.Rows[0]["AdminMail"]) != "True")
          //            {
          //                prdMail.MailBcc = string.Empty;
          //            }
          //            else
          //            {
          //                Mail Bind CC Address into BCC Address          
          //                if (!string.IsNullOrEmpty(WebConfigBCC))
          //                    strEmailBCC = WebConfigBCC;
          //                else
          //                    strEmailBCC = string.Empty;
          //                if (!string.IsNullOrEmpty(Convert.ToString(dtUserReg.Rows[0]["MoreRecipients"])))
          //                {
          //                    strEmailBCC = strEmailBCC + "," + Convert.ToString(dtUserReg.Rows[0]["MoreRecipients"]);
          //                }
          //                prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //            }

          //            prdMail.MailSubject = Convert.ToString(dtUserReg.Rows[0]["MailSubject"]);
          //            prdMail.MailContent = ReplaceUserRegMailArgument(Convert.ToString(dtUserReg.Rows[0]["MailContent"]), PMus.OrgOrLastName, PMus.DecreptPassWord, PMus.ServerUrl);

          //            InsertEmailQueue(prdMail);
          //        }
          //        return 0;
          //    }
          //    catch { return 1; }


          //}


          private string ReplaceUserRegMailArgument(string MailCont, string OrgLastName, string DecryptPWD, string sUrl)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", OrgLastName);
               strbMailCnt.Replace("{1}", DecryptPWD);
               strbMailCnt.Replace("{2}", sUrl);
               return Convert.ToString(strbMailCnt);
          }


          #endregion HOVUserRegistration_Type14

          #region ForumThread_Type15


          //public int GrievenceSendMail(grievance.GrievanceBusiness Gm)
          //{
          //    try
          //    {
          //        EmailProperties prdMail = new EmailProperties();
          //        int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(Gm.UserSeqId));   //Get Contact Preferences Based on UserSeqID         
          //        DataTable dtGrievence = GetEmailConfigDetails(15);                         //Type ID 15
          //        if (dtGrievence != null && dtGrievence.Rows.Count != 0)                     //Get Email information from email config table
          //        {
          //            if (intArrEmailFlag.Contains(2))
          //            {
          //                if (Convert.ToString(dtGrievence.Rows[0]["CustomerMail"]) == "True")
          //                    prdMail.ToMailAddress = Convert.ToString(Gm.EmailId); ;
          //            }
          //            else
          //                prdMail.ToMailAddress = string.Empty;


          //            //if (Convert.ToString(dtGrievence.Rows[0]["CustomerMail"]) == "True")
          //            //{
          //            //    prdMail.ToMailAddress = Convert.ToString(Gm.EmailId);

          //            //}

          //            if (Convert.ToString(dtGrievence.Rows[0]["AdminMail"]) != "True")
          //            {
          //                prdMail.MailBcc = string.Empty;
          //            }
          //            else
          //            {
          //                //Mail Bind CC Address into BCC Address          
          //                if (!string.IsNullOrEmpty(WebConfigBCC))
          //                    strEmailBCC = WebConfigBCC;
          //                else
          //                    strEmailBCC = string.Empty;
          //                if (!string.IsNullOrEmpty(Convert.ToString(dtGrievence.Rows[0]["MoreRecipients"])))
          //                {
          //                    strEmailBCC = strEmailBCC + "," + Convert.ToString(dtGrievence.Rows[0]["MoreRecipients"]);
          //                }
          //                prdMail.MailBcc = strEmailBCC.TrimStart(',');

          //            }
          //            prdMail.MailSubject = Gm.Subject;
          //            prdMail.MailContent = ReplaceGrievenceArgument(Convert.ToString(dtGrievence.Rows[0]["MailContent"]), Gm.User, Gm.Subject, Gm.GrievanceDetails, prdMail.ServerURL, prdMail.HostAddress);
          //            prdMail.ToMailAddress = "shanmugamp@hovservices.in";
          //            InsertEmailQueue(prdMail);
          //        }
          //        return 0;
          //    }
          //    catch { return 1; }

          //}


          private string ReplaceGrievenceArgument(string MailCont, string GmUser, string GmSubject, string GmDetails, string sURL, string HostAddress)
          {

               string todaydate = System.DateTime.Now.ToString("MM/dd/yyyy");
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", GmUser);
               strbMailCnt.Replace("{1}", todaydate);
               strbMailCnt.Replace("{2}", GmSubject);
               strbMailCnt.Replace("{3}", GmDetails);
               strbMailCnt.Replace("{4}", sURL);
               strbMailCnt.Replace("{6}", HostAddress);
               return Convert.ToString(strbMailCnt);
          }

          #endregion ForumThread_Type15

          #region ForumThread_Type16

          //public int GrievenceGetMail(grievance.GrievanceBusiness Gm)
          //{
          //    try
          //    {
          //        EmailProperties prdMail = new EmailProperties();
          //        int[] intArrEmailFlag = GetContactPreferences(Convert.ToString(Gm.UserSeqId));   //Get Contact Preferences Based on UserSeqID         
          //        string todaydate = System.DateTime.Now.ToString("MM/dd/yyyy");

          //        DataTable dtGrievenceMail = GetEmailConfigDetails(16);                      //Type ID 16

          //        if (dtGrievenceMail != null && dtGrievenceMail.Rows.Count != 0)              //Get Email information from email config table
          //        {

          //            if (intArrEmailFlag.Contains(2))
          //            {
          //                if (Convert.ToString(dtGrievenceMail.Rows[0]["CustomerMail"]) == "True")
          //                    prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["wfsupport"]);

          //            }
          //            else
          //                prdMail.ToMailAddress = string.Empty;


          //            //if (Convert.ToString(dtGrievenceMail.Rows[0]["CustomerMail"]) == "True")
          //            //{
          //            //    prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["wfsupport"]);

          //            //}



          //            if (Convert.ToString(dtGrievenceMail.Rows[0]["AdminMail"]) != "True")
          //            {
          //                prdMail.MailBcc = string.Empty;
          //            }
          //            else
          //            {    //Mail Bind CC Address into BCC Address          
          //                if (!string.IsNullOrEmpty(WebConfigBCC))
          //                    strEmailBCC = WebConfigBCC;
          //                else
          //                    strEmailBCC = string.Empty;
          //                if (!string.IsNullOrEmpty(Convert.ToString(dtGrievenceMail.Rows[0]["MoreRecipients"])))
          //                {
          //                    strEmailBCC = strEmailBCC + "," + Convert.ToString(dtGrievenceMail.Rows[0]["MoreRecipients"]);
          //                }
          //                prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //            }

          //            prdMail.MailSubject = Gm.Subject;
          //            prdMail.MailContent = ReplaceGrievenceGetMailArgument(Convert.ToString(dtGrievenceMail.Rows[0]["MailContent"]), Gm.User, Gm.Subject, Gm.GrievanceDetails);

          //            InsertEmailQueue(prdMail);
          //        }
          //        return 0;
          //    }
          //    catch
          //    { return 1; }

          //}

          private string ReplaceGrievenceGetMailArgument(string MailCont, string GmUser, string GmSubject, string GmDetails)
          {
               string todaydate = System.DateTime.Now.ToString("MM/dd/yyyy");
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", GmUser);
               strbMailCnt.Replace("{1}", todaydate);
               strbMailCnt.Replace("{2}", GmSubject);
               strbMailCnt.Replace("{3}", GmDetails);
               return Convert.ToString(strbMailCnt);
          }

          #endregion ForumThread_Type16

          #region PayerRegistration_Type20

          //public int SendMail(PayerRegistrationMail PRM)
          //{
          //    try
          //    {
          //        EmailProperties prdMail = new EmailProperties();

          //        DataTable dtPayerRegMail = GetEmailConfigDetails(20);     //Type ID 20
          //        int[] intArrEmailFlag = GetContactPreferences(PRM.UserSeqID);   //Get Contact Preferences Based on UserSeqID         

          //        if (dtPayerRegMail != null && dtPayerRegMail.Rows.Count != 0) //Get Email information from email config table
          //        {

          //            if (intArrEmailFlag.Contains(2))
          //            {
          //                if (Convert.ToString(dtPayerRegMail.Rows[0]["CustomerMail"]) == "True")
          //                    prdMail.ToMailAddress = PRM.ToMailAddr;

          //            }
          //            else
          //                prdMail.ToMailAddress = string.Empty;


          //            //if (Convert.ToString(dtPayerRegMail.Rows[0]["CustomerMail"]) == "True")
          //            //{
          //            //    prdMail.ToMailAddress = PRM.ToMailAddr;

          //            //}

          //            if (Convert.ToString(dtPayerRegMail.Rows[0]["AdminMail"]) != "True")
          //            {
          //                prdMail.MailBcc = string.Empty;
          //            }
          //            else
          //            {
          //                //Mail Bind CC Address into BCC Address          
          //                if (!string.IsNullOrEmpty(WebConfigBCC))
          //                    strEmailBCC = WebConfigBCC;
          //                else
          //                    strEmailBCC = string.Empty;
          //                if (!string.IsNullOrEmpty(Convert.ToString(dtPayerRegMail.Rows[0]["MoreRecipients"])))
          //                {
          //                    strEmailBCC = strEmailBCC + "," + Convert.ToString(dtPayerRegMail.Rows[0]["MoreRecipients"]);
          //                }
          //                prdMail.MailBcc = strEmailBCC.TrimStart(',');

          //            }
          //            prdMail.MailSubject = Convert.ToString(dtPayerRegMail.Rows[0]["MailSubject"]);
          //            prdMail.MailContent = ReplaceRegPayerMailArgument(Convert.ToString(dtPayerRegMail.Rows[0]["MailContent"]), PRM.UserName, PRM.Password, PRM.URL);

          //            InsertEmailQueue(prdMail);
          //        }
          //        return 0;
          //    }
          //    catch
          //    { return 1; }



          //}

          private string ReplaceRegPayerMailArgument(string MailCont, string PuserName, string Ppassword, string PURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", PuserName);
               strbMailCnt.Replace("{1}", Ppassword);
               strbMailCnt.Replace("{2}", PURL);
               return Convert.ToString(strbMailCnt);
          }

          #endregion PayerRegistration_Type20

          #region OuterContactusUser_Type21

          //public void contactUserMail(bllContactUs Gr)
          //{

          //    EmailProperties prdMail = new EmailProperties();
          //    DataTable dtContactUserMail = GetEmailConfigDetails(21);            //Type ID 21

          //    if (dtContactUserMail != null && dtContactUserMail.Rows.Count != 0)  //Get Email information from email config table
          //    {
          //        if (Convert.ToString(dtContactUserMail.Rows[0]["CustomerMail"]) == "True")
          //        {
          //            prdMail.ToMailAddress = Gr.EMailID;
          //        }
          //        else
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }

          //        if (Convert.ToString(dtContactUserMail.Rows[0]["AdminMail"]) != "True")
          //        {
          //            prdMail.MailBcc = string.Empty;
          //        }
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;
          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtContactUserMail.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtContactUserMail.Rows[0]["MoreRecipients"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');

          //        }
          //        prdMail.MailSubject = Convert.ToString(dtContactUserMail.Rows[0]["MailSubject"]);
          //        prdMail.MailContent = ReplaceContactUserArgument(Convert.ToString(dtContactUserMail.Rows[0]["MailContent"]), Gr.ServerUrl);

          //        InsertEmailQueue(prdMail);
          //    }



          //}

          private string ReplaceContactUserArgument(string MailCont, string SvURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", SvURL);
               return Convert.ToString(strbMailCnt);

          }

          #endregion OuterContactusUser_Type21


          #region OuterContactusAdmin_Type22

          //public int contactHovSupportMail(bllContactUs Gr)
          //{
          //    try
          //    {
          //        EmailProperties prdMail = new EmailProperties();
          //        DataTable dtHovSupportMail = GetEmailConfigDetails(22);            //Type ID 22
          //        if (dtHovSupportMail != null && dtHovSupportMail.Rows.Count != 0)  //Get Email information from email config table
          //        {
          //            if (Convert.ToString(dtHovSupportMail.Rows[0]["CustomerMail"]) == "True")
          //            {
          //                prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["wfsupport"]);

          //            }
          //            else
          //            {
          //                prdMail.ToMailAddress = string.Empty;
          //            }
          //            if (Convert.ToString(dtHovSupportMail.Rows[0]["AdminMail"]) != "True")
          //            {
          //                prdMail.MailBcc = string.Empty;
          //            }
          //            else
          //            {
          //                //Mail Bind CC Address into BCC Address          
          //                if (!string.IsNullOrEmpty(WebConfigBCC))
          //                    strEmailBCC = WebConfigBCC;
          //                else
          //                    strEmailBCC = string.Empty;
          //                if (!string.IsNullOrEmpty(Convert.ToString(dtHovSupportMail.Rows[0]["MoreRecipients"])))
          //                {
          //                    strEmailBCC = strEmailBCC + "," + Convert.ToString(dtHovSupportMail.Rows[0]["MoreRecipients"]);
          //                }
          //                prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //            }
          //            prdMail.MailSubject = Convert.ToString(dtHovSupportMail.Rows[0]["MailSubject"]);
          //            prdMail.MailContent = ReplaceHovSupportArgument(Convert.ToString(dtHovSupportMail.Rows[0]["MailContent"]), Gr.FullName, Gr.CompanyName, Gr.Address, Gr.City, Gr.State, Gr.Zip, Gr.EMailID, Gr.Phone, Gr.Fax, Gr.Subject, Gr.Message);

          //            InsertEmailQueue(prdMail);
          //        }
          //        return 0;

          //    }
          //    catch
          //    { return 1; }
          //}

          private string ReplaceHovSupportArgument(string MailCont, string FullName, string CompanyName, string Address, string City, string State, string Zip, string EMailID, string Phone, string Fax, string Subject, string Message)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", FullName);
               strbMailCnt.Replace("{1}", CompanyName);
               strbMailCnt.Replace("{2}", Address);
               strbMailCnt.Replace("{3}", City);
               strbMailCnt.Replace("{4}", State);
               strbMailCnt.Replace("{5}", Zip);
               strbMailCnt.Replace("{6}", EMailID);
               strbMailCnt.Replace("{7}", Phone);
               strbMailCnt.Replace("{8}", Fax);
               strbMailCnt.Replace("{9}", Subject);
               strbMailCnt.Replace("{10}", Message);
               return Convert.ToString(strbMailCnt);
          }

          #endregion OuterContactusAdmin_Type22


          #region SubUserRegistration_Type23

          //public void SubUserRegistrationMail(BLL_SubUserMaster PRM)
          //{
          //    EmailProperties prdMail = new EmailProperties();

          //    DataTable dtSubUserReg = GetEmailConfigDetails(23);                             //Type ID 23

          //    if (dtSubUserReg != null && dtSubUserReg.Rows.Count != 0)                       //Get Email information from email config table
          //    {
          //        if (Convert.ToString(dtSubUserReg.Rows[0]["CustomerMail"]) == "True")
          //        {
          //            prdMail.ToMailAddress = PRM.Email;
          //        }
          //        else
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }
          //        if (Convert.ToString(dtSubUserReg.Rows[0]["AdminMail"]) != "True")
          //        {
          //            prdMail.MailBcc = string.Empty;
          //        }
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;

          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');

          //        }
          //        prdMail.MailSubject = Convert.ToString(dtSubUserReg.Rows[0]["MailSubject"]);
          //        prdMail.MailContent = ReplaceSubUserRegArgument(Convert.ToString(dtSubUserReg.Rows[0]["MailContent"]), PRM.UserName, PRM.PasswordPlain, prdMail.ServerURL);

          //        InsertEmailQueue(prdMail);
          //    }
          //}


          private string ReplaceSubUserRegArgument(string MailCont, string SuserName, string SplainPWD, string ServerURL)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", SuserName);
               strbMailCnt.Replace("{1}", SplainPWD);
               strbMailCnt.Replace("{2}", ServerURL);
               return Convert.ToString(strbMailCnt);

          }

          #endregion SubUserRegistration_Type23

          #region SubUserUpdate_Type38

          //public void SubUserUpdateMail(BLL_SubUserMaster PRM)
          //{
          //    EmailProperties prdMail = new EmailProperties();
          //    DataTable dtProvinfo = GetProviderLoginInfo();

          //    DataTable dtSubUserReg = GetEmailConfigDetails(38);                             //Type ID 38

          //    if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)             //Retrive Login information from Usermaster and Loginmaster tables
          //    {

          //        prdMail.MailCc = Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);

          //    }


          //    if (dtSubUserReg != null && dtSubUserReg.Rows.Count != 0)                       //Get Email information from email config table
          //    {
          //        if (Convert.ToString(dtSubUserReg.Rows[0]["CustomerMail"]) == "True")
          //        {
          //            prdMail.ToMailAddress = PRM.Email;
          //        }
          //        else
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }


          //        if (Convert.ToString(dtSubUserReg.Rows[0]["AdminMail"]) != "True")
          //        {
          //            prdMail.MailBcc = string.Empty;

          //        }
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;

          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"]);

          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //            prdMail.MailCc = strEmailCC;

          //        }
          //        prdMail.MailSubject = Convert.ToString(dtSubUserReg.Rows[0]["MailSubject"]);
          //        prdMail.MailContent = Convert.ToString(dtSubUserReg.Rows[0]["MailContent"]);

          //        InsertEmailQueue(prdMail);
          //    }


          //}

          #endregion SubUserUpdate_Type38


          private string ReplaceMailArgument(string MailCont, string strHtn, Int32 noOfArg)
          {
               EmailProperties prdMail = new EmailProperties();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               switch (noOfArg)
               {
                    case 2:
                         strbMailCnt.Replace("{0}", strHtn);
                         break;
                    case 3:
                         strbMailCnt.Replace("{0}", strHtn);
                         strbMailCnt.Replace("{1}", prdMail.ServerURL);
                         break;
               }
               return Convert.ToString(strbMailCnt);
          }

          #endregion EmailConfiguration
          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>End of Email Configuration Block <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<



          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>FAX Configuration Block Starts here<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
          #region FAXConfiguration
          private static void RegisterFax()
          {

          }
          #endregion FAXConfiguration
          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>End of FAX Configuration Block <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<



          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>SMS Configuration Block Starts here<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
          #region SMSConfiguration
          private static void RegisterSMS()
          {


          }
          #endregion SMSConfiguration
          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>End of SMS Configuration Block <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<



          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>PHONE Configuration Block Starts here<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
          #region PHONEConfiguration
          private static void RegisterPhone()
          {

          }
          #endregion PHONEConfiguration
          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>End of PHONE Configuration Block <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

          //public static EmailProperties GetContactPreferences(string UsrSeqID)
          //{
          //    EmailProperties objEmailProperty = new EmailProperties();
          //    string strContact = string.Empty;
          //    string[] split = null;

          //    DataTable dt = new DataTable();
          //    dt = null;
          //    eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams =new eTailingBAL.HOVDAL.SqlParameter[1];
          //    ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
          //    ProvInfoParams[0].ParameterName = "@UserSequentialID";
          //    ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
          //    ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
          //    ProvInfoParams[0].Size = 10;
          //    ProvInfoParams[0].Value = UsrSeqID;
          //    dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_GetContactPreference", ProvInfoParams).Tables[0];
          //    if (dt.Rows.Count != null)
          //    {
          //        if (Convert.ToString(dt.Rows[0]["ContactPreference"]) != "")
          //        {
          //            strContact = Convert.ToString(dt.Rows[0]["ContactPreference"]);
          //            split = strContact.Split(',');

          //            foreach (string ContactitemCode in split)
          //            {
          //                switch (ContactitemCode)
          //                {
          //                    case "2":
          //                        objEmailProperty.GetEmailConfigStatus = ContactitemCode;

          //                        break;
          //                }
          //            }
          //        }

          //    }
          //    return objEmailProperty;

          //}

          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Get Contact Preference Code from UserMaster Starts Here<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


          public int[] GetContactPreferences(string UsrSeqID)
          {
               string strContact = string.Empty;
               string[] split = null;
               int[] arrMailFlag = new int[4];

               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@UserSequentialID";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               ProvInfoParams[0].Size = 10;
               ProvInfoParams[0].Value = UsrSeqID;//UsrSeqID
               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "USP_SP_GetContactPreference", ProvInfoParams).Tables[0];
               if (dt != null && dt.Rows.Count != 0)
               {
                    if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["ContactPreference"])))
                    {
                         strContact = Convert.ToString(dt.Rows[0]["ContactPreference"]);
                         split = strContact.Split(',');
                         for (int i = 0; i <= split.Length - 1; i++)
                         {
                              if (Convert.ToString(split[i]) == "2")
                              {
                                   arrMailFlag[i] = Convert.ToInt32(split[i]);//IF contact preference Mail is set to True assign into Array
                              }
                         }
                    }
               }
               return arrMailFlag;
          }

          public void DeclaimerMail(string ProviderName, string NPI)
          {
               EmailProperties objEmailProperty = new EmailProperties();
               string strEmailBCC = string.Empty;
               DataTable dtMailinfo = GetEmailConfigDetails(29);         //Type ID 17

               if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)              //Get Email information from email config table
               {
                    ////if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) == "True")
                    ////{
                    ////    objEmailProperty.ToMailAddress = EmailID;

                    ////}
                    ////else
                    ////{ objEmailProperty.ToMailAddress = string.Empty; }


                    if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
                    {
                         objEmailProperty.MailBcc = string.Empty;
                    }
                    else
                    {    //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
                         }
                         objEmailProperty.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    objEmailProperty.ToMailAddress = "pch@hovservices.com";
                    objEmailProperty.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
                    objEmailProperty.MailContent = ReplaceMailArgument(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]), ProviderName, NPI);
                    InsertEmailQueue(objEmailProperty);
               }

          }
          //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>End of Get Contact Preference Code from UserMaster<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
          //BCBSNC Email
          public int BCBSNCMail(int Emailconfigid, string Content)
          {
               try
               {
                    EmailProperties objEmailProperty = new EmailProperties();
                    string strEmailBCC = string.Empty;
                    DataTable dtMailinfo = GetEmailConfigDetails(42);

                    if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)              //Get Email information from email config table
                    {
                         if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
                         {
                              objEmailProperty.MailBcc = string.Empty;
                         }
                         else
                         {    //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;

                         }
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
                         }
                         objEmailProperty.MailBcc = strEmailBCC.TrimStart(',');
                         objEmailProperty.ToMailAddress = "Puneetailing.test@banctec.in";
                         objEmailProperty.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
                         objEmailProperty.MailContent = Content;
                         InsertEmailQueue(objEmailProperty);
                    }
                    return 0;
               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("BCBSNCMail : " + ex.Message, "ContactPreferences", "", 0);
                    return 1;
               }
          }

          //BSP Related 

          #region BSPProviderRegistration_Type41

          //public void BSPProviderRegistrationDetails(string StrUserName)
          //{
          //    ProviderPaymentRegistration PUM = new ProviderPaymentRegistration();
          //    EmailProperties prdMail = new EmailProperties();
          //    string strUserCode = string.Empty;

          //    //DataTable dtProvinfo = GetProviderLoginInfo();      
          //    DataTable dtProvinfo = GetEmailids(StrUserName);
          //    DataTable dtMailinfo = GetEmailConfigDetails(41);
          //    if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)
          //    {
          //        prdMail.ToMailAddress = Convert.ToString(dtProvinfo.Rows[0]["EMailID"]);
          //        prdMail.MailCc = Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);
          //        prdMail.UserName = Convert.ToString(dtProvinfo.Rows[0]["UserLoginID"]);
          //        prdMail.Password = Convert.ToString(dtProvinfo.Rows[0]["Password"]);
          //        strUserCode = Convert.ToString(dtProvinfo.Rows[0]["UserCode"]);
          //    }
          //    if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)
          //    {
          //        if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
          //            prdMail.MailBcc = string.Empty;
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;
          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
          //            }
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"])))
          //            {
          //                //strEmailBCC = strEmailBCC + "," + Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //        }
          //        if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) != "True")
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }
          //        prdMail.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
          //        prdMail._strURL = ConfigurationManager.AppSettings["RegisterRedirectURL"].ToString();  //HttpContext.Current.Request.Url.ToString().Substring(0, Convert.ToInt32(HttpContext.Current.Request.Url.ToString().LastIndexOf('/')));
          //        prdMail.MailContent = ReplaceProviderRegMailArgument(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]), prdMail.UserName, prdMail.Password, strUserCode, prdMail._strURL);

          //        InsertEmailQueue(prdMail);
          //    }
          //}

          #endregion SubUserUpdate_Type41

          #region BSP Sub User Registration Mail

          //public void BSPSubUserRegistrationMail(BLL_SubUserMaster PRM)
          //{
          //    ProviderPaymentRegistration PUM = new ProviderPaymentRegistration();
          //    EmailProperties prdMail = new EmailProperties();
          //    string strUserCode = string.Empty;

          //    DataTable dtProvinfo = GetEmailids(PRM.UserName);
          //    DataTable dtMailinfo = GetEmailConfigDetails(23);

          //    if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)
          //    {
          //        prdMail.ToMailAddress = Convert.ToString(dtProvinfo.Rows[0]["EMailID"]);
          //        prdMail.MailCc = Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);
          //        prdMail.UserName = Convert.ToString(dtProvinfo.Rows[0]["UserLoginID"]);
          //        prdMail.Password = Convert.ToString(dtProvinfo.Rows[0]["Password"]);
          //        strUserCode = Convert.ToString(dtProvinfo.Rows[0]["UserCode"]);
          //    }

          //    if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)
          //    {
          //        if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
          //            prdMail.MailBcc = string.Empty;
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;
          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
          //            }
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');
          //        }
          //        if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) != "True")
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }
          //        prdMail.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
          //        prdMail.MailContent = ReplaceProviderRegMailArgument(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]), prdMail.UserName, prdMail.Password, strUserCode, prdMail.ServerURL);

          //        InsertEmailQueue(prdMail);
          //    }
          //}

          //#endregion

          //#region BSP Sub User Deactivation Mail
          //public void BSPSubUserDeactivationMail(BLL_SubUserMaster PRM)
          //{
          //    EmailProperties prdMail = new EmailProperties();
          //    string strUserCode = string.Empty;

          //    DataTable dtProvinfo = GetEmailids(PRM.UserName);
          //    DataTable dtSubUserReg = GetEmailConfigDetails(38);

          //    if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)
          //    {
          //        prdMail.ToMailAddress = Convert.ToString(dtProvinfo.Rows[0]["EMailID"]);
          //        prdMail.MailCc = Convert.ToString(dtProvinfo.Rows[0]["CCEMailID"]);
          //        prdMail.UserName = Convert.ToString(dtProvinfo.Rows[0]["UserLoginID"]);
          //        prdMail.Password = Convert.ToString(dtProvinfo.Rows[0]["Password"]);
          //        strUserCode = Convert.ToString(dtProvinfo.Rows[0]["UserCode"]);
          //    }

          //    if (dtSubUserReg != null && dtSubUserReg.Rows.Count != 0)
          //    {
          //        if (Convert.ToString(dtSubUserReg.Rows[0]["CustomerMail"]) == "True")
          //        {
          //            prdMail.ToMailAddress = PRM.Email;
          //        }
          //        else
          //        {
          //            prdMail.ToMailAddress = string.Empty;
          //        }
          //        if (Convert.ToString(dtSubUserReg.Rows[0]["AdminMail"]) != "True")
          //        {
          //            prdMail.MailBcc = string.Empty;
          //        }
          //        else
          //        {
          //            //Mail Bind CC Address into BCC Address          
          //            if (!string.IsNullOrEmpty(WebConfigBCC))
          //                strEmailBCC = WebConfigBCC;

          //            else
          //                strEmailBCC = string.Empty;
          //            if (!string.IsNullOrEmpty(Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"])))
          //            {
          //                strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSubUserReg.Rows[0]["MoreRecipients"]);
          //            }
          //            prdMail.MailBcc = strEmailBCC.TrimStart(',');

          //        }
          //        prdMail.MailSubject = Convert.ToString(dtSubUserReg.Rows[0]["MailSubject"]);
          //        //prdMail.MailContent = ReplaceSubUserRegArgument(Convert.ToString(dtSubUserReg.Rows[0]["MailContent"]), PRM.UserName, PRM.PasswordPlain, prdMail.ServerURL);
          //        prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtSubUserReg.Rows[0]["MailContent"]), PRM.UserName, 2);
          //        InsertEmailQueue(prdMail);
          //    }
          //}


          #endregion

          #region BSPClaimUpload_Type 34,35
          //Send  Mail after Successful Data Entry
          public void SendSuccessMailBulkBSP(string HTNvalue, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtSuccessMail = GetEmailConfigDetails(34);
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);
               DataTable dtMailate = GetEmailDate(HTNvalue, "PST");
               string StrEmailDate = Convert.ToString(dtMailate.Rows[0]["Createdon"]);//Get HTN Created on date
               if (dtSuccessMail != null && dtSuccessMail.Rows.Count != 0) //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = EmailToAddress;
                    }
                    else
                         prdMail.ToMailAddress = string.Empty;
                    //if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                    //{d
                    //    prdMail.ToMailAddress = EmailToAddress;
                    //}
                    if (Convert.ToString(dtSuccessMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {    //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"]);
                         }
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailate.Rows[0]["CCEmailID"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailate.Rows[0]["CCEmailID"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtSuccessMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgumentBSP(Convert.ToString(dtSuccessMail.Rows[0]["MailContent"]), HTNvalue, 3, StrEmailDate);

                    InsertEmailQueue(prdMail);
               }
          }

          public void SendSuccessMailBSP(string HTNvalue, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtSuccessMail = GetEmailConfigDetails(35);     //Type ID 3        
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               DataTable dtMailate = GetEmailDate(HTNvalue, "PST");
               string StrEmailDate = Convert.ToString(dtMailate.Rows[0]["Createdon"]);//Get HTN Created on date
               if (dtSuccessMail != null && dtSuccessMail.Rows.Count != 0) //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = EmailToAddress;
                    }
                    else
                         prdMail.ToMailAddress = string.Empty;
                    //if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                    //{
                    //    prdMail.ToMailAddress = EmailToAddress;
                    //}
                    if (Convert.ToString(dtSuccessMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {    //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"]);
                         }
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailate.Rows[0]["CCEmailID"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailate.Rows[0]["CCEmailID"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtSuccessMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgumentBSP(Convert.ToString(dtSuccessMail.Rows[0]["MailContent"]), HTNvalue, 3, StrEmailDate);

                    InsertEmailQueue(prdMail);
               }
          }

          private string ReplaceMailArgumentBSP(string MailCont, string strHtn, Int32 noOfArg, string CRdate)
          {
               EmailProperties prdMail = new EmailProperties();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);

               switch (noOfArg)
               {
                    case 2:
                         strbMailCnt.Replace("{0}", strHtn);
                         strbMailCnt.Replace("{2}", CRdate);
                         break;
                    case 3:
                         strbMailCnt.Replace("{0}", strHtn);
                         strbMailCnt.Replace("{1}", prdMail.ServerURL);
                         strbMailCnt.Replace("{2}", CRdate);
                         break;
               }
               return Convert.ToString(strbMailCnt);
          }
          #endregion ClaimUpload_Type3

          # region BSP Search Related_type 43
          public void SendSuccessMailBSPsearch(string HTNvalue, string UserSeqID, string BSCDocnumber)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtSuccessMail = GetEmailConfigDetails(43);     //Type ID 43        
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               DataTable dtMailCurentHTN = GetEmailDate(HTNvalue, "");
               DataTable dtMailOLDHTN = GetEmailDate(HTNvalue, "Ser", BSCDocnumber);

               string StrEmailDate = string.Empty;
               if (dtMailCurentHTN != null && dtMailCurentHTN.Rows.Count > 0)
               {
                    // DataTable dtmailCC = GetEmailCCDetails(BSCDocnumber);
                    StrEmailDate = Convert.ToString(dtMailCurentHTN.Rows[0]["Createdon"]);//Get HTN Created on date
               }
               if (dtSuccessMail != null && dtSuccessMail.Rows.Count != 0) //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         //if (Convert.ToString(dtSuccessMail.Rows[0]["CustomerMail"]) == "True")
                         //prdMail.ToMailAddress = EmailToAddress;
                    }
                    else
                         prdMail.ToMailAddress = string.Empty;

                    if (Convert.ToString(dtSuccessMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {    //Mail Bind CC Address into BCC Address          

                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;

                         if (!string.IsNullOrEmpty(Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtSuccessMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');

                         if (dtMailOLDHTN != null)
                         {
                              if (dtMailOLDHTN.Rows.Count > 0)
                              {
                                   if (!string.IsNullOrEmpty(Convert.ToString(dtMailOLDHTN.Rows[0]["EmailID"])))
                                   {
                                        strEmailCC = Convert.ToString(dtMailOLDHTN.Rows[0]["EmailID"]);
                                        strEmailCC = strEmailCC + "," + Convert.ToString(dtMailOLDHTN.Rows[0]["Emailid"]);
                                   }
                                   if (!string.IsNullOrEmpty(Convert.ToString(dtMailOLDHTN.Rows[0]["CCEmailID"])))
                                   {
                                        strEmailCC = Convert.ToString(dtMailOLDHTN.Rows[0]["CCEmailID"]);
                                        strEmailCC = strEmailCC + "," + Convert.ToString(dtMailOLDHTN.Rows[0]["CCEmailid"]);
                                   }
                              }
                         }

                         prdMail.MailCc = strEmailCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtSuccessMail.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceMailArgumentBSP(Convert.ToString(dtSuccessMail.Rows[0]["MailContent"]), HTNvalue, 3, StrEmailDate);

                    InsertEmailQueue(prdMail);
               }
          }
          #endregion

          #region BSP Date  & CCEmail  Related

          private DataTable GetEmailids(string strUSERLOGINID)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];

               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@USERlOGINID";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[0].Size = 50;
               ProvInfoParams[0].Value = strUSERLOGINID;

               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_GETEmailDETAILS", ProvInfoParams).Tables[0];
               return dt;
          }
          private DataTable GetEmailDate(string HTN, string Mode)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[2];

               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@HTN";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[0].Size = 21;
               ProvInfoParams[0].Value = HTN;

               ProvInfoParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[1].ParameterName = "@Mode";
               ProvInfoParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[1].Size = 3;
               ProvInfoParams[1].Value = Mode;

               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_EmailConfigStatus", ProvInfoParams).Tables[0];
               return dt;
          }
          private DataTable GetEmailDate(string HTN, string Mode, string BSCDocnumber)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[3];

               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@HTN";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[0].Size = 21;
               ProvInfoParams[0].Value = HTN;

               ProvInfoParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[1].ParameterName = "@Mode";
               ProvInfoParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[1].Size = 3;
               ProvInfoParams[1].Value = Mode;

               ProvInfoParams[2] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[2].ParameterName = "@BSCDocnumber";
               ProvInfoParams[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[2].Size = 30;
               ProvInfoParams[2].Value = BSCDocnumber;

               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "PMS_SP_EmailConfigStatus", ProvInfoParams).Tables[0];
               return dt;
          }

          public DataTable GetEmailCCDetails(string BSCDocnumber)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@BSCDocnumber";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               ProvInfoParams[0].Size = 30;
               ProvInfoParams[0].Value = BSCDocnumber;
               DataTable dtmailCC = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "BSP_SP_Emailsearchupload", ProvInfoParams).Tables[0];
               return dtmailCC;
          }
          #endregion

          private string ReplaceMailArgument(string MailCont, string strHtn, string strURL, Int32 noOfArg)
          {
               EmailProperties prdMail = new EmailProperties();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               switch (noOfArg)
               {
                    case 2:
                         strbMailCnt.Replace("{0}", strHtn);
                         break;
                    case 3:
                         strbMailCnt.Replace("{0}", strHtn);
                         strbMailCnt.Replace("{1}", strURL);
                         break;
               }
               return Convert.ToString(strbMailCnt);
          }
          public void SendHMSRejectMail(string strHTN, string UserSeqID)
          {
               EmailProperties prdMail = new EmailProperties();
               DataTable dtPKMail = GetEmailConfigDetails(44);          //Type ID 3
               int[] intArrEmailFlag = GetContactPreferences(UserSeqID);   //Get Contact Preferences Based on UserSeqID
               if (dtPKMail != null && dtPKMail.Rows.Count != 0)        //Get Email information from email config table
               {
                    if (intArrEmailFlag.Contains(2))
                    {
                         if (Convert.ToString(dtPKMail.Rows[0]["CustomerMail"]) == "True")
                              prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["HMSToAddress"]);
                    }
                    else
                         //prdMail.ToMailAddress = string.Empty;
                         prdMail.ToMailAddress = WebConfigBCC;
                    if (Convert.ToString(dtPKMail.Rows[0]["AdminMail"]) != "True")
                    {
                         prdMail.MailBcc = string.Empty;
                    }
                    else
                    {
                         //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtPKMail.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtPKMail.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    prdMail.MailSubject = Convert.ToString(dtPKMail.Rows[0]["MailSubject"]);
                    prdMail._strURL = ConfigurationManager.AppSettings["RegisterRedirectURLPK"].ToString();
                    //prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtPKMail.Rows[0]["MailContent"]), strHTN, 2);
                    prdMail.MailContent = ReplaceMailArgument(Convert.ToString(dtPKMail.Rows[0]["MailContent"]), strHTN, prdMail._strURL, 3);

                    InsertEmailQueue(prdMail);
               }
          }

     }

}

