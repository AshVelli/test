#region Header
/*========================================================================================
'	Module Name			        : Login1
'	Purpose				        : Users loging in
'	Program Name		        : Login1.cs
'	Program Version		        : 1.0
'	Author Name			        : PMS - Deepareka
'	Table(s) Used			    : Nil
'	Stored Procedure(s) Used	: PMS_SP_SESSIONLOG,PMS_SP_LOGINMASTER,PMS_SP_RoleMaster
'	View(s) Used		        : Nil
'	Include File(s) Used        : HovServices.RMO.dll
'	Date Started		        : 21 Sep 2009
'	From Page 			        : Nil
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By         Date Started            Description
'----------------------------------------------------------------------------------------
 * nill         SABARIGIRI      01-Oct-2010             to check usercode for uhi and to retrieve logo
'=======================================================================================*/
#endregion

#region Namespaces
using System.Data;
using System.ComponentModel;
//using HOVDAL;
#endregion

#region Main
namespace eTailingBAL
{
     /// <summary>
     /// Summary description for Login1
     /// </summary>
     public class BLL_Login
     {
          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
          
          public static int GetUserSeqId(string userLoginId)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];
               Params[0] = new eTailingBAL.HOVDAL.SqlParameter
               {
                    ParameterName = "@USERLOGINID",
                    Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                    SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar,
                    Size = 50,
                    Value = userLoginId
               };
               var i = (int)WSC.HDAL.ExecuteScalar(GlobalVal.strcon, objCommand, "ET_SP_GetUserSeqId", Params);
               return i;
          }

          public static DataTable GetUserInfo(int mUserSeqId)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];
               Params[0] = new eTailingBAL.HOVDAL.SqlParameter
               {
                    ParameterName = "@USERSEQID",
                    Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                    SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                    Value = mUserSeqId
               };
               DataTable dtUserInfo = new DataTable();
               DataSet DS = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetAllDetailsToUpdateProfile", Params);
               if (DS.Tables.Count > 0)
                    dtUserInfo = DS.Tables[0];
               return dtUserInfo;
          }

          public static int GetUserLoggedInFlag(int userSeqId)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];
               Params[0] = new eTailingBAL.HOVDAL.SqlParameter
               {
                    ParameterName = "@USERSEQID",
                    Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                    SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                    Value = userSeqId
               };
               var i = (int)WSC.HDAL.ExecuteScalar(GlobalVal.strcon, objCommand, "ET_SP_GetLoggedInFlag", Params);
               return i;
          }

          public static void SetFlagInSessionLog(int userSeqId, int setFlag)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[2];
               Params[0] = new eTailingBAL.HOVDAL.SqlParameter
               {
                    ParameterName = "@USERSEQID",
                    Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                    SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                    Value = userSeqId
               };
               Params[1] = new eTailingBAL.HOVDAL.SqlParameter
               {
                    ParameterName = "@FLG",
                    Direction = eTailingBAL.HOVDAL.ParameterDirection.Input,
                    SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int,
                    Value = setFlag
               };
               WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, objCommand, "ET_SP_SetFlagInSessionLog", Params);
          }

          [DataObjectMethod(DataObjectMethodType.Insert, true)]
          public static void SessionLog(int UserSeqID, string SessionLogID, string IPAddr,int sessionTimeOutMin)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[4];       

               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@SESSIONID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[0].Size = 25;
               Params[0].Value = SessionLogID;
               
               Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[1].ParameterName = "@USERSEQID";
               Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.BigInt;
               Params[1].Value = UserSeqID;
               
               Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[2].ParameterName = "@IPADDRESS";
               Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               Params[2].Size = 15;
               Params[2].Value = IPAddr;

               Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[3].ParameterName = "@SessionTimeOutMin";
               Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               Params[3].Value = sessionTimeOutMin;

               WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, objCommand, "ET_SP_SESSIONLOG", Params);
          }     
     }
}
#endregion
