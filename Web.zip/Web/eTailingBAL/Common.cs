#region Header
/*========================================================================================
'	Module Name			        : Common.
'	Purpose				        : Common functions.
'	Program Name		        : Common.cs
'	Program Version		        : 1.0
'	Author Name			        : ANINDA
'	Table(s) Used			    : Nil
'	Stored Procedure(s) Used	: Nil
'	View(s) Used		        : Nil
'	Include File(s) Used        : PMS
'	Date Started		        : 20 March 2012
'	From Page 			        : Nil
'	To Page 			        : Nil
'   CC#                         : Nil
''===================================Modification Log=====================================
' Track ID     Done By         Date Started            Description
'----------------------------------------------------------------------------------------
'=======================================================================================*/
#endregion

using System;
using System.Data;
using System.Diagnostics;
using System.Reflection;

namespace eTailingBAL
{
     public class Common
     {
          static WebServiceClass WSC = new WebServiceClass();
          public static string strCMS1500 = "CMS1500";
          public static string strUB04 = "UB04";
          public static string strEOB = "EOB";
          public static string strCorrespondence = "Correspondence";
          public static string strCoversheet = "Coversheet";
          public static string strPrimaryHCFA = "Primary CMS1500";
          public static string strSecondaryHCFA = "Secondary CMS1500";
          public static string strPrimaryUB = "Primary UB04";
          public static string strSecondaryUB = "Secondary UB04";
          public static string strHCFACorrespondance = "CMS1500 Correspondence";
          public static string strUBCorrespondence = "UB04 Correspondence";

          static string _appName;
          public static string ApplicationName
          {
               get { return _appName; }
               set { _appName = value; }
          }

          static string _exceptionDetail;
          public static string ExceptionDetail
          {
               get { return _exceptionDetail; }
               set { _exceptionDetail = value; }
          }

          static string _funcName;
          public static string FunctionName
          {
               get { return _funcName; }
               set { _funcName = value; }
          }

          static string _processInfoClass;
          public static string ProcessInfoClass
          {
               get { return _processInfoClass; }
               set { _processInfoClass = value; }
          }


          public static bool InsertErrorLog(string Description, string Module, string StrHTN, int statuscode)
          {
               bool result = false;
               try
               {
                    eTailingBAL.HOVDAL.CommandType ComType = eTailingBAL.HOVDAL.CommandType.StoredProcedure;

                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[5];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@ApplicationName";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[0].Size = 100;
                    Params[0].Value = "PCHWebPortal";

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@ProcessInfo";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[1].Size = 100;
                    Params[1].Value = Module;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@ExceptionDetail";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[2].Size = -1;
                    Params[2].Value = Description;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@HTN";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[3].Size = 25;
                    Params[3].Value = StrHTN;

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[4].ParameterName = "@StatusSeqId";
                    Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[4].Size = 4;
                    Params[4].Value = statuscode;

                    WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, ComType, "ET_SP_AppErrLog", Params);

                    result = true;
               }
               catch (Exception Ex)
               {
                    result = false;
                    string Exceptionmsg = "";

                    Exceptionmsg = Ex.Message;
                    if (Ex.StackTrace != null)
                         Exceptionmsg += " " + Ex.StackTrace;
                    if (Ex.Source != null)
                         Exceptionmsg += " " + Ex.Source;
                    Common.InsertErrorLog("Pch_Web: " + Exceptionmsg, "NCMetaData.aspx.cs", "", 0, "InsertErrorLog");
               }
               return result;
          }

          public static void InsertErrorLog(string ExceptionDetail, string ProcessInfoClass, string FunctionName)
          {
               try
               {
                    eTailingBAL.HOVDAL.CommandType ComType = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[4];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@ApplicationName";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[0].Size = 100;
                    Params[0].Value = "eTailing";

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@ProcessInfo";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[1].Size = -1;
                    Params[1].Value = ProcessInfoClass;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@ExceptionDetail";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[2].Size = 250;
                    Params[2].Value = ExceptionDetail;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@FunctionName";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[3].Size = 600;
                    Params[3].Value = FunctionName;

                    WSC.HDAL.ExecuteNonQuery(GlobalVal.strcon, ComType, "ET_SP_AppErrLog", Params);
                    //DataSet ds = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, ComType, "PMS_SP_AppErrLog", Params);
                    //return ds.Tables[0].Rows[0][0].ToString();
               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "Common.cs", "InsertErrorLog()");
               }
          }

          public static string InsertErrorLog(string Description, string Module, string StrHTN, int statuscode, string FunctionName)
          {
               try
               {
                    eTailingBAL.HOVDAL.CommandType ComType = eTailingBAL.HOVDAL.CommandType.StoredProcedure;

                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[6];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@ApplicationName";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[0].Size = 100;
                    Params[0].Value = "PCFWebPortal";

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@ProcessInfo";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[1].Size = 100;
                    Params[1].Value = Module;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@ExceptionDetail";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[2].Size = 250;
                    Params[2].Value = Description;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@HTN";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[3].Size = 25;
                    Params[3].Value = StrHTN;

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[4].ParameterName = "@StatusSeqId";
                    Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    Params[4].Size = 4;
                    Params[4].Value = statuscode;

                    Params[5] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[5].ParameterName = "@FunctionName";
                    Params[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.NVarChar;
                    Params[5].Size = 600;
                    Params[5].Value = FunctionName;

                    DataSet ds = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, ComType, "ET_SP_AppErrLog", Params);
                    return ds.Tables[0].Rows[0][0].ToString();
               }
               catch (Exception ex)
               {
                    Common.InsertErrorLog("Web-App_Code:" + ex.Message, "Common.cs", "", 0, "InsertErrorLog");
                    return "";
               }
          }
     }
}

