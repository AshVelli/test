using System;
using System.Data;
using System.ComponentModel;
using System.Collections.Generic;
namespace eTailingBAL
{

	/// <summary>
	/// Summary description for OASISGlobalMethods
	/// </summary>
	public class PmsUserMethods
	{

		public PmsUserMethods()
		{
			//
			// TODO: Add constructor logic here
			//

		}

		/// <summary>
		/// General Methods for Provider Registration
		/// </summary>

		public class ProviderRegistration
		{
			static WebServiceClass WSC = new WebServiceClass();                                                                                

			private string _strUserLoginID = string.Empty;
			private string _strPassword = string.Empty;
			private string _strUserType = string.Empty;
			private string _strOrgOrLastName = string.Empty;
			private string _strFirstName = string.Empty;
			private string _strMiddleName = string.Empty;
			private string _strLastName = string.Empty;
			private string _strCompanyURL = string.Empty;

			private string _strCardType = string.Empty;
			private string _strCardHolderName = string.Empty;
			private string _strCardNumber = string.Empty;

			private string _strCVC = string.Empty;
			private string _strEXPIRYDate = string.Empty;
			private string _strBankcode = string.Empty;

			private int _intprdActiveStatus = 1;
			private int _intprdApproval = 0;
			private int _intUserSeqID = 0;

			private string _strCardorCheck = "";

			private int _intBillingType = 0;
			private string _strContactPreference = string.Empty;

			private string _strEMailID = string.Empty;
			private string _strAddress1 = string.Empty;
			private string _strAddress2 = string.Empty;
			private string _strCity = string.Empty;
			private string _strstate = string.Empty;
			private string _strCountry = string.Empty;
			private string _strZip = string.Empty;
			private string _strPhone = string.Empty;
			private string _strPhoneExtn = string.Empty;
			private string _strFax = string.Empty;
			private string _strMobile = string.Empty;

			private string _strPayAddress1 = string.Empty;
			private string _strPayAddress2 = string.Empty;
			private string _strPayCity = string.Empty;
			private string _strPaystate = string.Empty;
			private string _strPayCountry = string.Empty;
			private string _strPayZip = string.Empty;
			private string _strPayPhone = string.Empty;
			private string _strPayPhoneExtn = string.Empty;
			private string _strPayMobile = string.Empty;

			private string _strBillAddress1 = string.Empty;
			private string _strBillAddress2 = string.Empty;
			private string _strBillCity = string.Empty;
			private string _strBillstate = string.Empty;
			private string _strBillCountry = string.Empty;
			private string _strBillZip = string.Empty;
			private string _strBillPhone = string.Empty;
			private string _strBillPhoneExtn = string.Empty;
			private string _strBillMobile = string.Empty;
			private string _strBillFax = string.Empty;
			private string _strBillingName = string.Empty;

			private string _strSecQuesId1 = string.Empty;
			private string _strAnswer1 = string.Empty;
			private string _strSecQuesId2 = string.Empty;
			private string _strAnswer2 = string.Empty;

			private string _strPlanType = string.Empty;

			private string _strPayer = string.Empty;

			//Added For BSP
			private string _wildCardSearch = string.Empty;
			private string _Searchmode = string.Empty;
			private string _strGroupName = string.Empty;
			private string _strTodate = string.Empty;
			private string _strUserCode = string.Empty;

			public string ToDate
			{
				get { return _strTodate; }
				set { _strTodate = value; }
			}
			public string UserCode
			{
				get { return _strUserCode; }
				set { _strUserCode = value; }
			}


			public string ProviderNameSearch
			{
				get
				{
					return _wildCardSearch;
				}
				set
				{
					_wildCardSearch = value;
				}
			}


			public string Payer
			{
				get { return _strPayer; }
				set { _strPayer = value; }
			}

			public string SecQuesId1
			{
				get { return _strSecQuesId1; }
				set { _strSecQuesId1 = value; }
			}
			public string Answer1
			{
				get { return _strAnswer1; }
				set { _strAnswer1 = value; }
			}

			public string SecQuesId2
			{
				get { return _strSecQuesId2; }
				set { _strSecQuesId2 = value; }
			}
			public string Answer2
			{
				get { return _strAnswer2; }
				set { _strAnswer2 = value; }
			}

			public string PlanType
			{
				get { return _strPlanType; }
				set { _strPlanType = value; }
			}

			public string BillAddress1
			{
				get { return _strBillAddress1; }
				set { _strBillAddress1 = value; }
			}
			public string BillAddress2
			{
				get { return _strBillAddress2; }
				set { _strBillAddress2 = value; }
			}

			public string BillCity
			{
				get { return _strBillCity; }
				set { _strBillCity = value; }
			}
			public string Billstate
			{
				get { return _strBillstate; }
				set { _strBillstate = value; }
			}
			public string BillCountry
			{
				get { return _strBillCountry; }
				set { _strBillCountry = value; }
			}
			public string BillZip
			{
				get { return _strBillZip; }
				set { _strBillZip = value; }
			}

			public string BillPhone
			{
				get { return _strBillPhone; }
				set { _strBillPhone = value; }
			}
			public string BillFax
			{
				get { return _strBillFax; }
				set { _strBillFax = value; }
			}

			public int Approval
			{
				get { return _intprdApproval; }
				set { _intprdApproval = value; }

			}
			public string BillingName
			{
				get { return _strBillingName; }
				set { _strBillingName = value; }
			}

			public string BillPhoneExtn
			{
				get { return _strBillPhoneExtn; }
				set { _strBillPhoneExtn = value; }
			}

			public string BillMobile
			{
				get { return _strBillMobile; }
				set { _strBillMobile = value; }
			}
			public string UserLoginID
			{
				get { return _strUserLoginID; }
				set { _strUserLoginID = value; }
			}
			public string Password
			{
				get { return _strPassword; }
				set { _strPassword = value; }
			}

			public string UserType
			{
				get { return _strUserType; }
				set { _strUserType = value; }
			}
			public string OrgOrLastName
			{
				get { return _strOrgOrLastName; }
				set { _strOrgOrLastName = value; }
			}
			public string FirstName
			{
				get { return _strFirstName; }
				set { _strFirstName = value; }
			}
			public string MiddleName
			{
				get { return _strMiddleName; }
				set { _strMiddleName = value; }
			}
			public string LastName
			{
				get { return _strLastName; }
				set { _strLastName = value; }
			}

			public string Address1
			{
				get { return _strAddress1; }
				set { _strAddress1 = value; }
			}
			public string Address2
			{
				get { return _strAddress2; }
				set { _strAddress2 = value; }
			}
			public string City
			{
				get { return _strCity; }
				set { _strCity = value; }
			}
			public string state
			{
				get { return _strstate; }
				set { _strstate = value; }
			}
			public string Country
			{
				get { return _strCountry; }
				set { _strCountry = value; }
			}
			public string Zip
			{
				get { return _strZip; }
				set { _strZip = value; }
			}

			public string Phone
			{
				get { return _strPhone; }
				set { _strPhone = value; }
			}
			public string Fax
			{
				get { return _strFax; }
				set { _strFax = value; }
			}
			public string EMailID
			{
				get { return _strEMailID; }
				set { _strEMailID = value; }
			}
			public string CompanyURL
			{
				get { return _strCompanyURL; }
				set { _strCompanyURL = value; }
			}

			public int prdActiveStatus
			{
				get { return _intprdActiveStatus; }
				set { _intprdActiveStatus = value; }
			}

			public string CardType
			{
				get { return _strCardType; }
				set { _strCardType = value; }
			}

			public string CardHolderName
			{
				get { return _strCardHolderName; }
				set { _strCardHolderName = value; }
			}
			public string CardNumber
			{
				get { return _strCardNumber; }
				set { _strCardNumber = value; }
			}
			public string CVC
			{
				get { return _strCVC; }
				set { _strCVC = value; }
			}

			public string EXPIRYDate
			{
				get { return _strEXPIRYDate; }
				set { _strEXPIRYDate = value; }
			}

			public string Bankcode
			{
				get { return _strBankcode; }
				set { _strBankcode = value; }
			}

			public int UserSeqID
			{
				get { return _intUserSeqID; }
				set { _intUserSeqID = value; }
			}

			public string CardorCheck
			{
				get { return _strCardorCheck; }
				set { _strCardorCheck = value; }
			}
			public int BillingType
			{
				get { return _intBillingType; }
				set { _intBillingType = value; }
			}

			public string ContactPreference
			{
				get { return _strContactPreference; }
				set { _strContactPreference = value; }
			}

			public string PhoneExtn
			{
				get { return _strPhoneExtn; }
				set { _strPhoneExtn = value; }
			}

			public string Mobile
			{
				get { return _strMobile; }
				set { _strMobile = value; }
			}

			public string PayPhoneExtn
			{
				get { return _strPayPhoneExtn; }
				set { _strPayPhoneExtn = value; }
			}

			public string PayAddress1
			{
				get { return _strPayAddress1; }
				set { _strPayAddress1 = value; }
			}
			public string PayAddress2
			{
				get { return _strPayAddress2; }
				set { _strPayAddress2 = value; }
			}
			public string PayCity
			{
				get { return _strPayCity; }
				set { _strPayCity = value; }
			}
			public string Paystate
			{
				get { return _strPaystate; }
				set { _strPaystate = value; }
			}
			public string PayCountry
			{
				get { return _strPayCountry; }
				set { _strPayCountry = value; }
			}
			public string PayZip
			{
				get { return _strPayZip; }
				set { _strPayZip = value; }
			}

			public string PayPhone
			{
				get { return _strPayPhone; }
				set { _strPayPhone = value; }
			}
			public string PayMobile
			{
				get { return _strPayMobile; }
				set { _strPayMobile = value; }
			}

			public string Searchmode
			{
				get { return _Searchmode; }
				set { _Searchmode = value; }
			}
			public string StrGroupName
			{
				get { return _strGroupName; }
				set { _strGroupName = value; }
			}

			public static DataSet GetUserDetails(string UserLoginId)
			{
				try
				{
					eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
					eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];

					Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
					Params[0].ParameterName = "@UserLoginID";
					Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
					Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
					Params[0].Size = 50;
					Params[0].Value = UserLoginId;

					DataSet dsUserInfo = new DataSet();
                         dsUserInfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, cmt, "ET_SP_EditGetUserInfo", Params);
					return dsUserInfo;

				}
				catch
				{
					return null;
				}

			}

			[DataObjectMethod(DataObjectMethodType.Select, true)]
			public static DataSet GetCCDetails(string userLoginId)
			{
				try
				{
					eTailingBAL.HOVDAL.CommandType cmt = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
					eTailingBAL.HOVDAL.SqlParameter[] tempParameter = new eTailingBAL.HOVDAL.SqlParameter[1];

					tempParameter[0] = new eTailingBAL.HOVDAL.SqlParameter();
					tempParameter[0].ParameterName = "@UserLoginID";
					tempParameter[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
					tempParameter[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
					tempParameter[0].Size = 15;
					tempParameter[0].Value = userLoginId;

					return WSC.HDAL.ExecuteDataset(GlobalVal.strcon, cmt, "ET_SP_GetCCDetails", tempParameter);
				}
				catch(Exception ex)
				{
					throw ex;
				}
			}        
		}
	}

}

