using System;
using System.Net;

namespace eTailingBAL
{
    /// <summary>
    /// Summary description for WebServiceClass
    /// </summary>
    public class WebServiceClass
    {
        //public eTailingBAL.HOVDAL.HOVDAL.HOVSDAL HDAL;
        public eTailingBAL.HOVDAL.HOVSDAL HDAL;
        public WebServiceClass()
        {
            HDAL = new eTailingBAL.HOVDAL.HOVSDAL();
            HDAL.Proxy = (WebProxy)setProxy(GlobalVal.proxyAddress, GlobalVal.proxyUserName, GlobalVal.proxyPassword);
        }


        /// <summary>
        /// General Methods for Provider payment confirmation
        /// </summary>

        /// <summary>
        /// ByPass the proxy Seetings
        /// </summary>
        public static WebProxy setProxy(string proxyAddress, string username, string password)
        {
            WebProxy myProxy = new WebProxy();
            if (proxyAddress.Length > 0)
            {
                Uri newUri = new Uri(proxyAddress);
                myProxy.Address = newUri;
                myProxy.Credentials = new NetworkCredential(username, password);
            }
            return myProxy;
        }
    }
}