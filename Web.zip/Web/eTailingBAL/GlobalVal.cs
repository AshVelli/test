using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using System;
using System.Configuration;
using System.Text;


namespace eTailingBAL
{
     /// <summary>
     /// Summary description for GlobalVal
     /// </summary>
     public class GlobalVal
     {


          public GlobalVal()
          {
               //
               // TODO: Add constructor logic here
               //
          }
          public enum StoreProcedure
          {
               ET_SP_ProviderReg,
               ET_SP_GetStateList,
               ET_SP_SecQuestion,
               ET_SP_GetBankNames,
               ET_SP_GetBillingType,
               ET_SP_CheckAvailability,
               ET_SP_SelectUserAddress,
               ET_SP_ProviderHOVPayerMap,
               ET_SP_ProviderHOVPayerListForUser,
               ET_SP_ProviderHOVPayerMapUpdate,
               ET_SP_CheckPayerAvailability,
               ET_SP_UpdUsrPaymentInfo,
               ET_SP_SelectUserList,
               ET_SP_UpdateUserInfo,
               ET_SP_EditGetUserInfo,
               ET_SP_EditProviderRegistration,
               ET_SP_CheckNPIAvailability,
               ET_SP_ChangePassword
          }

          #region Global Values
          public static string strcon = System.Configuration.ConfigurationManager.ConnectionStrings["PMSConnectionString"].ToString();
          public static string proxyAddress = System.Configuration.ConfigurationManager.AppSettings["ProxyAddress"].ToString();
          public static string proxyUserName = System.Configuration.ConfigurationManager.AppSettings["ProxyUserName"].ToString();
          public static string proxyPassword = System.Configuration.ConfigurationManager.AppSettings["ProxyPassword"].ToString();


          #endregion

          public static string strEncDecKey = ConfigurationManager.AppSettings["EncDecKey"].ToString();

          public static string StrSmtpServer = ConfigurationManager.AppSettings["SmtpServer"].ToString();

          public static string GetDecryptValue(string val)
          {
               string retValue = string.Empty;
               try
               {
                    if (val == "")
                         return "";
                    PasswordEncription pass = new PasswordEncription();
                    retValue = pass.Encription(val);
               }
               catch (Exception ex)
               {
                    string strErrorId = string.Empty;
                    strErrorId = Common.InsertErrorLog(ex.Message, "GlobalVal.cs", "", 0, "GetDecryptValue");
               }
               return retValue;
          }                                                                             
     }
}