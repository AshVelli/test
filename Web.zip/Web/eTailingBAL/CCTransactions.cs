﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;



#region Main
/// <summary>
/// Summary description for CCTransactions
/// </summary>                                
namespace eTailingBAL
{
     public class CCTransactions{
          static WebServiceClass WSC = new WebServiceClass();

          public CCTransactions()
          {
               //
               // TODO: Add constructor logic here
               //
          }

          #region Variables
          private string _strET_TransactionID = string.Empty;
          private string _strPG_TransactionID = string.Empty;
          private string _strStatus = string.Empty;
          private string _strErrorDescription = string.Empty;
          private int _intUserSeqId = 0;
          private int _intPaymentSeqId = 0;
          private decimal _strTransactionAmount = 0;
          private string _strApplicationCode = string.Empty;
          private DateTime _dtCreatedOn = DateTime.MinValue;

          public string ET_TransactionID
          {
               get { return _strET_TransactionID; }
               set { _strET_TransactionID = value; }
          }

          public string PG_TransactionID
          {
               get { return _strPG_TransactionID; }
               set { _strPG_TransactionID = value; }
          }

          public string Status
          {
               get { return _strStatus; }
               set { _strStatus = value; }
          }

          public string ErrorDescription
          {
               get { return _strErrorDescription; }
               set { _strErrorDescription = value; }
          }

          public int UserSeqId
          {
               get { return _intUserSeqId; }
               set { _intUserSeqId = value; }
          }

          public int PaymentSeqId
          {
               get { return _intPaymentSeqId; }
               set { _intPaymentSeqId = value; }
          }

          public decimal TransactionAmount
          {
               get { return _strTransactionAmount; }
               set { _strTransactionAmount = value; }
          }

          public string ApplicationCode
          {
               get { return _strApplicationCode; }
               set { _strApplicationCode = value; }
          }

          public DateTime CreatedOn
          {
               get { return _dtCreatedOn; }
               set { _dtCreatedOn = value; }
          }
          #endregion

          public void InsertUserTransactionLog(string userLoginID)
          {
               try
               {
                    eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
                    eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[7];

                    Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[0].ParameterName = "@ET_TransactionID";
                    Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[0].Size = 10;
                    Params[0].Value = _strET_TransactionID;

                    Params[1] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[1].ParameterName = "@PG_TransactionID";
                    Params[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[1].Size = 20;
                    Params[1].Value = _strPG_TransactionID;

                    Params[2] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[2].ParameterName = "@Status";
                    Params[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[2].Size = 25;
                    Params[2].Value = _strStatus;

                    Params[3] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[3].ParameterName = "@ErrorDescription";
                    Params[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[3].Size = 100;
                    Params[3].Value = _strErrorDescription;

                    //Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
                    //Params[4].ParameterName = "@UserSeqId";
                    //Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    //Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    //Params[4].Value = ccTransaction.UserSeqId;

                    //Params[5] = new eTailingBAL.HOVDAL.SqlParameter();
                    //Params[5].ParameterName = "@PaymentSeqId";
                    //Params[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    //Params[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    //Params[5].Value = ccTransaction.PaymentSeqId;

                    Params[4] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[4].ParameterName = "@TransactionAmount";
                    Params[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Decimal;
                    Params[4].Value = _strTransactionAmount;

                    Params[5] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[5].ParameterName = "@ApplicationCode";
                    Params[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[5].Size = 20;
                    Params[5].Value = _strApplicationCode;

                    Params[6] = new eTailingBAL.HOVDAL.SqlParameter();
                    Params[6].ParameterName = "@UserLoginID";
                    Params[6].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    Params[6].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
                    Params[6].Size = 20;
                    Params[6].Value = userLoginID;

                    WSC.HDAL.ExecuteScalar(GlobalVal.strcon, objCommand, "ET_SP_UserTransactionLg", Params);
               }
               catch (Exception)
               {

                    throw;
               }
          }
     }

}                  
#endregion