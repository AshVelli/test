using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Text;

/// <summary>
/// Summary description for SendMail
/// </summary>
namespace eTailingBAL
{                           
     public class SendMail
     {
          static WebServiceClass WSC = new WebServiceClass();
          static eTailingBAL.HOVDAL.CommandType objCommand = eTailingBAL.HOVDAL.CommandType.StoredProcedure;
          public static string _emailId;
          static StringBuilder strbMailCnt = null;
          //string EmailFromAddress = Convert.ToString(ConfigurationManager.AppSettings["FromAddress"]);
          static string WebConfigBCC = Convert.ToString(ConfigurationManager.AppSettings["BccAddress"]);
          static string EmailToAddress = Convert.ToString(HttpContext.Current.Session["EMailID"]);
          static string strEmailBCC = string.Empty;
          static string strEmailCC = string.Empty;

          public SendMail()
          {
               //
               // TODO: Add constructor logic here
               //
          }

          private static DataTable GetEmailId(int userSeqId)
          {
               eTailingBAL.HOVDAL.SqlParameter[] Params = new eTailingBAL.HOVDAL.SqlParameter[1];
               Params[0] = new eTailingBAL.HOVDAL.SqlParameter();
               Params[0].ParameterName = "@USERSEQID";
               Params[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               Params[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               Params[0].Value = userSeqId;
               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_GetEmailId", Params).Tables[0];
               return dt;
          }

          private static DataTable GetEmailConfigDetails(int TypeID)
          {
               eTailingBAL.HOVDAL.SqlParameter[] ProvInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               ProvInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               ProvInfoParams[0].ParameterName = "@TypID";
               ProvInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               ProvInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
               ProvInfoParams[0].Size = 10;
               ProvInfoParams[0].Value = TypeID;
               DataTable dt = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_EmailConfigStatus", ProvInfoParams).Tables[0];
               return dt;
          }

          private static void InsertEmailQueue(EmailProperties prm)
          {
               eTailingBAL.HOVDAL.SqlParameter[] InsertParams = new eTailingBAL.HOVDAL.SqlParameter[6];

               InsertParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[0].ParameterName = "@FrmAddr";
               InsertParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[0].Size = 100;
               InsertParams[0].Value = prm.FromMailAddress;

               InsertParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[1].ParameterName = "@ToAddr";
               InsertParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[1].Size = 1000;
               InsertParams[1].Value = prm.ToMailAddress;

               InsertParams[2] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[2].ParameterName = "@CCAddr";
               InsertParams[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[2].Size = 1000;
               InsertParams[2].Value = prm.MailCc;

               InsertParams[3] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[3].ParameterName = "@BccAddr";
               InsertParams[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[3].Size = 1000;
               InsertParams[3].Value = prm.MailBcc;

               InsertParams[4] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[4].ParameterName = "@MailSub";
               InsertParams[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[4].Size = 100;
               InsertParams[4].Value = prm.MailSubject;


               InsertParams[5] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[5].ParameterName = "@MailCont";
               InsertParams[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[5].Size = 8000;
               InsertParams[5].Value = prm.MailContent;

               WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_InsertProv_EmailQueue", InsertParams);
          }

          private static void InsertTransactionPassedInEmailQueue(EmailProperties prm)
          {
               eTailingBAL.HOVDAL.SqlParameter[] InsertParams = new eTailingBAL.HOVDAL.SqlParameter[6];

               InsertParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[0].ParameterName = "@FrmAddr";
               InsertParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[0].Size = 100;
               InsertParams[0].Value = prm.FromMailAddress;

               InsertParams[1] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[1].ParameterName = "@ToAddr";
               InsertParams[1].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[1].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[1].Size = 1000;
               InsertParams[1].Value = prm.ToMailAddress;

               InsertParams[2] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[2].ParameterName = "@CCAddr";
               InsertParams[2].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[2].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[2].Size = 1000;
               InsertParams[2].Value = prm.MailCc;

               InsertParams[3] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[3].ParameterName = "@BccAddr";
               InsertParams[3].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[3].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[3].Size = 1000;
               InsertParams[3].Value = prm.MailBcc;

               InsertParams[4] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[4].ParameterName = "@MailSub";
               InsertParams[4].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[4].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[4].Size = 100;
               InsertParams[4].Value = prm.MailSubject;


               InsertParams[5] = new eTailingBAL.HOVDAL.SqlParameter();
               InsertParams[5].ParameterName = "@MailCont";
               InsertParams[5].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
               InsertParams[5].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.VarChar;
               InsertParams[5].Size = 8000;
               InsertParams[5].Value = prm.MailContent;

               WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_InsertProv_EmailQueue", InsertParams);
          }

          public static void SendResetSuccessMail(EmailProperties em)
          {
               DataTable dtResetPass = GetEmailConfigDetails(7);
               if (dtResetPass != null && dtResetPass.Rows.Count != 0)
               {
                    {
                         if (Convert.ToString(dtResetPass.Rows[0]["CustomerMail"]) == "True")
                         {
                              EmailToAddress = Convert.ToString(HttpContext.Current.Session["EMailID"]);
                              em.ToMailAddress = EmailToAddress;
                         }
                         else
                         {
                              em.ToMailAddress = string.Empty;
                         }
                    }
                    if (Convert.ToString(dtResetPass.Rows[0]["AdminMail"]) != "True")
                    {
                         em.MailBcc = string.Empty;
                    }
                    else
                    {
                         strEmailBCC = !string.IsNullOrEmpty(WebConfigBCC) ? WebConfigBCC : string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtResetPass.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtResetPass.Rows[0]["MoreRecipients"]);
                         }
                         em.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    em.MailSubject = Convert.ToString(dtResetPass.Rows[0]["MailSubject"]);
                    InsertEmailQueue(em);
               }
          }

          public static void ProviderRegistrationDetails(string providersqlID)
          {
               EmailProperties prdMail = new EmailProperties();
               string strUserCode = string.Empty;
               DataTable dtProvinfo = GetProviderLoginInfo(providersqlID);       //Retrive Provider Login Information
               DataTable dtMailinfo = GetEmailConfigDetails(1);       //Retrive Provider Email Informatiom for Type Id 1
               if (dtProvinfo != null && dtProvinfo.Rows.Count != 0)             //Retrive Login information from Usermaster and Loginmaster tables
               {
                    prdMail.ToMailAddress = Convert.ToString(dtProvinfo.Rows[0]["EMailID"]);
                    prdMail.UserName = Convert.ToString(dtProvinfo.Rows[0]["UserLoginID"]);
                    prdMail.Password = Convert.ToString(dtProvinfo.Rows[0]["Password"]);
                    strUserCode = Convert.ToString(dtProvinfo.Rows[0]["UserCode"]);
               }

               if (dtMailinfo != null && dtMailinfo.Rows.Count != 0)                                 //Get Email information from email config table
               {
                    if (Convert.ToString(dtMailinfo.Rows[0]["AdminMail"]) != "True")
                         prdMail.MailBcc = string.Empty;
                    else
                    {
                         //Mail Bind CC Address into BCC Address          
                         if (!string.IsNullOrEmpty(WebConfigBCC))
                              strEmailBCC = WebConfigBCC;
                         else
                              strEmailBCC = string.Empty;
                         if (!string.IsNullOrEmpty(Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"])))
                         {
                              strEmailBCC = strEmailBCC + "," + Convert.ToString(dtMailinfo.Rows[0]["MoreRecipients"]);
                         }
                         prdMail.MailBcc = strEmailBCC.TrimStart(',');
                    }
                    if (Convert.ToString(dtMailinfo.Rows[0]["CustomerMail"]) != "True")
                    {
                         prdMail.ToMailAddress = string.Empty;
                    }
                    prdMail.MailSubject = Convert.ToString(dtMailinfo.Rows[0]["MailSubject"]);
                    prdMail.MailContent = ReplaceProviderRegMailArgument(Convert.ToString(dtMailinfo.Rows[0]["MailContent"]), prdMail.UserName, prdMail.Password, strUserCode, prdMail.ServerURL);
                    InsertEmailQueue(prdMail);
               }
          }

          private static string ReplaceProviderRegMailArgument(string MailCont, string PuserName, string Ppassword, string PprovID, string ServerURL)
          {
               PasswordEncription pwdDec = new PasswordEncription();
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", PuserName);
               strbMailCnt.Replace("{1}", pwdDec.Decription(Ppassword));
               //      BLL_Login.GetUserSeqId("");
               strbMailCnt.Replace("{2}", PprovID);
               strbMailCnt.Replace("{3}", ServerURL);
               return Convert.ToString(strbMailCnt);
          }

          private static DataTable GetProviderLoginInfo(string providersqlID)
          {
               eTailingBAL.HOVDAL.SqlParameter[] LoginInfoParams = new eTailingBAL.HOVDAL.SqlParameter[1];
               DataTable dtProvinfo = new DataTable();
               dtProvinfo = null;
               if (providersqlID != null)
               {
                    LoginInfoParams[0] = new eTailingBAL.HOVDAL.SqlParameter();
                    LoginInfoParams[0].ParameterName = "@UseqID";
                    LoginInfoParams[0].Direction = eTailingBAL.HOVDAL.ParameterDirection.Input;
                    LoginInfoParams[0].SqlDbType = eTailingBAL.HOVDAL.SqlDbType.Int;
                    LoginInfoParams[0].Size = 10;
                    LoginInfoParams[0].Value = providersqlID;// Convert.ToString(System.Web.HttpContext.Current.Session["providersqlID"]);
                    dtProvinfo = WSC.HDAL.ExecuteDataset(GlobalVal.strcon, objCommand, "ET_SP_UserMasAndLoginMas", LoginInfoParams).Tables[0];
               }
               return dtProvinfo;
          }

          public static int contactHovSupportMail(string FullName, string CompanyName, string Address, string City, string State, string Zip, string EMailID, string Phone, string Fax, string Subject, string Message)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    DataTable dtHovSupportMail = GetEmailConfigDetails(22);            //Type ID 22
                    if (dtHovSupportMail != null && dtHovSupportMail.Rows.Count != 0)  //Get Email information from email config table
                    {
                         if (Convert.ToString(dtHovSupportMail.Rows[0]["CustomerMail"]) == "True")
                         {
                              prdMail.ToMailAddress = Convert.ToString(ConfigurationManager.AppSettings["wfsupport"]);

                         }
                         else
                         {
                              prdMail.ToMailAddress = string.Empty;
                         }
                         if (Convert.ToString(dtHovSupportMail.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtHovSupportMail.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtHovSupportMail.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }
                         prdMail.MailSubject = Convert.ToString(dtHovSupportMail.Rows[0]["MailSubject"]);
                         prdMail.MailContent = ReplaceHovSupportArgument(Convert.ToString(dtHovSupportMail.Rows[0]["MailContent"]), FullName, CompanyName, Address, City, State, Zip, EMailID, Phone, Fax, Subject, Message);

                         InsertEmailQueue(prdMail);
                    }
                    return 0;

               }
               catch
               { return 1; }
          }

          private static string ReplaceHovSupportArgument(string MailCont, string FullName, string CompanyName, string Address, string City, string State, string Zip, string EMailID, string Phone, string Fax, string Subject, string Message)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", FullName);
               strbMailCnt.Replace("{1}", CompanyName);
               strbMailCnt.Replace("{2}", Address);
               strbMailCnt.Replace("{3}", City);
               strbMailCnt.Replace("{4}", State);
               strbMailCnt.Replace("{5}", Zip);
               strbMailCnt.Replace("{6}", EMailID);
               strbMailCnt.Replace("{7}", Phone);
               strbMailCnt.Replace("{8}", Fax);
               strbMailCnt.Replace("{9}", Subject);
               strbMailCnt.Replace("{10}", Message);
               return Convert.ToString(strbMailCnt);
          }

          public static int ForgetPasswordMail(string Email, string UserSeqID, string Password, string UserName)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    //int[] intArrEmailFlag = GetContactPreferences(UserSeqID);//Get Contact Preferences Based on UserSeqID
                    DataTable dtFPwd = GetEmailConfigDetails(6);            //Type ID 6
                    if (dtFPwd != null && dtFPwd.Rows.Count != 0)          //Get Email information from email config table
                    {
                         // if (intArrEmailFlag.Contains(2))
                         {
                              if (Convert.ToString(dtFPwd.Rows[0]["CustomerMail"]) == "True")
                              {
                                   EmailToAddress = Email;
                                   prdMail.ToMailAddress = EmailToAddress;
                              }
                         }
                         // else
                         //  prdMail.ToMailAddress = string.Empty;



                         if (Convert.ToString(dtFPwd.Rows[0]["AdminMail"]) != "True")
                              prdMail.MailBcc = string.Empty;
                         else
                         {
                              //Mail Bind CC Address into BCC Address          
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtFPwd.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtFPwd.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }

                         prdMail.MailSubject = Convert.ToString(dtFPwd.Rows[0]["MailSubject"]);
                         strbMailCnt = new StringBuilder(Convert.ToString(dtFPwd.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", UserName);
                         strbMailCnt.Replace("{1}", Password);
                         strbMailCnt.Replace("{2}", prdMail.ServerURL);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);
                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }

               catch
               {
                    return 1;
               }

          }

          public static string ReplaceContactInfoMailArgument(string MailCont, string Phone, string PhoneExtn, string Emailid, string Fax, string Mobile, string CompanyUrl, string ServerURl)
          {
               strbMailCnt = null;
               strbMailCnt = new StringBuilder(MailCont);
               strbMailCnt.Replace("{0}", Phone);
               strbMailCnt.Replace("{1}", PhoneExtn);
               strbMailCnt.Replace("{2}", Emailid);
               strbMailCnt.Replace("{3}", Fax);
               strbMailCnt.Replace("{4}", Mobile);
               strbMailCnt.Replace("{5}", CompanyUrl);
               strbMailCnt.Replace("{6}", ServerURl);
               return Convert.ToString(strbMailCnt);
          }

          public static int ChangePasswordMail(string UserName, string NewPassword)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    DataTable dtChangePassword = GetEmailConfigDetails(8);
                    if (dtChangePassword != null && dtChangePassword.Rows.Count != 0)
                    {
                         {
                              if (Convert.ToString(dtChangePassword.Rows[0]["CustomerMail"]) == "True")
                              {
                                   int userSeqId = BLL_Login.GetUserSeqId(UserName);
                                   DataTable dtEmail = GetEmailId(userSeqId);
                                   if (dtEmail.Rows.Count > 0)
                                   {
                                        _emailId = dtEmail.Rows[0].ItemArray[0].ToString();
                                   }
                                   if (EmailToAddress == "" || EmailToAddress == null)
                                   {
                                        EmailToAddress = _emailId;
                                   }
                                   prdMail.ToMailAddress = EmailToAddress;
                              }
                         }
                         if (Convert.ToString(dtChangePassword.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtChangePassword.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtChangePassword.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }
                         prdMail.MailSubject = Convert.ToString(dtChangePassword.Rows[0]["MailSubject"]);
                         strbMailCnt = new StringBuilder(Convert.ToString(dtChangePassword.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", UserName);
                         strbMailCnt.Replace("{1}", NewPassword);
                         strbMailCnt.Replace("{2}", prdMail.ServerURL);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);
                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch (Exception ex)
               {
                    string error = ex.Message;
                    return 1;
               }
          }

          public static int SendTransactionStatusMail(int mTypeId, string transactionID)
          {
               try
               {
                    EmailProperties prdMail = new EmailProperties();
                    DataTable dtTransaction = GetEmailConfigDetails(mTypeId);

                    if (dtTransaction != null && dtTransaction.Rows.Count != 0)
                    {
                         {
                              if (Convert.ToString(dtTransaction.Rows[0]["CustomerMail"]) == "True" && dtTransaction.Rows[0]["CustomerMail"] != null)
                              {
                                   EmailToAddress = _emailId;
                                   prdMail.ToMailAddress = EmailToAddress;
                              }
                         }
                         if (Convert.ToString(dtTransaction.Rows[0]["AdminMail"]) != "True")
                         {
                              prdMail.MailBcc = string.Empty;
                         }
                         else
                         {
                              if (!string.IsNullOrEmpty(WebConfigBCC))
                                   strEmailBCC = WebConfigBCC;
                              else
                                   strEmailBCC = string.Empty;
                              if (!string.IsNullOrEmpty(Convert.ToString(dtTransaction.Rows[0]["MoreRecipients"])))
                              {
                                   strEmailBCC = strEmailBCC + "," + Convert.ToString(dtTransaction.Rows[0]["MoreRecipients"]);
                              }
                              prdMail.MailBcc = strEmailBCC.TrimStart(',');
                         }
                         prdMail.MailSubject = Convert.ToString(dtTransaction.Rows[0]["MailSubject"]);
                         strbMailCnt = new StringBuilder(Convert.ToString(dtTransaction.Rows[0]["MailContent"]));
                         strbMailCnt.Replace("{0}", transactionID);
                         prdMail.MailContent = Convert.ToString(strbMailCnt);
                         InsertEmailQueue(prdMail);
                    }
                    return 0;
               }
               catch
               {
                    return 1;
               }
          }
     }                
}