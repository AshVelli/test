﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eTailingWebApp
{
     public partial class ErrorPage : System.Web.UI.Page
     {
          protected void Page_Load(object sender, EventArgs e)
          {
               CaptchaRefresh();
          }

          public void CaptchaRefresh()
          {
               Session["Code"] = null;
               Random ran = new Random();
               //myImage.ImageUrl = "~/CaptchaControl.aspx?Id=" + ran.Next(1, 9).ToString();
          }                                                       
     }
}