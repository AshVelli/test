﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using eTailingBAL;
using System.Diagnostics;

namespace eTailingWebApp
{
     public partial class ChangePassword : System.Web.UI.Page
     {
          private string _userName = "";
          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (appCode == "dataforce")
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;

               }
          }
          protected void Page_Load(object sender, EventArgs e)
          {
               if (!Page.IsPostBack)
               {
                    if (TxtUserName.Text != null)
                    {
                         _userName = TxtUserName.Text;
                         TxtUserName.Text = Convert.ToString(Session["UserName"]);
                    }
               }
               System.Text.StringBuilder sbValid = new System.Text.StringBuilder();
               sbValid.Append("if(Validation() == false){return false;}");
               sbValid.Append("this.value = 'Please wait...';");
               sbValid.Append("this.disabled = true;");
               sbValid.Append(value: this.Page.GetPostBackEventReference(this.btn_Submit));
               sbValid.Append(";");
               this.btn_Submit.Attributes.Add("onclick", sbValid.ToString());
          }
          protected void btn_Submit_Click(object sender, EventArgs e)
          {
               DataSet dsUserInfo = null;
               PasswordEncription PassDesc = new PasswordEncription();
               ChangePassword1 CP = new ChangePassword1();
               myprofileInfo MP = new myprofileInfo();
               string strOPass = TxtOldPass.Text;
               string strNPass = TxtNewPass.Text;
               string strCPass = TxtConfirmPass.Text;
               string encOldPwd, encNewPwd;
               try
               {
                    if (TxtUserName.Text != null)
                    {
                         _userName = TxtUserName.Text;
                    }
                    dsUserInfo = PmsUserMethods.ProviderRegistration.GetUserDetails(_userName);
                    string temp = PassDesc.Decription(dsUserInfo.Tables[0].Rows[0]["Password"].ToString());
                    if (dsUserInfo.Tables.Count > 0 && dsUserInfo.Tables[0].Rows.Count > 0)
                    {
                         if (temp == strOPass)
                         {
                              if (strNPass == strCPass)
                              {
                                   encOldPwd = PassDesc.Encription(strOPass);
                                   encNewPwd = PassDesc.Encription(strNPass);
                                   ChangePassword1.ChangePassword(_userName, encOldPwd, encNewPwd);
                                   SendMail.ChangePasswordMail(_userName, strNPass);
                                   TxtUserName.Text = "";
                                   lblMsg.InnerText = "successfully changed password";
                              }
                              else
                              {
                                   lblMsg.InnerHtml = "Password must be same in New and Confirm Password";
                              }
                         }
                         else
                         {
                              lblMsg.InnerHtml = "Please enter the correct Old password";
                         }
                    }
                    else
                    {
                         lblMsg.InnerHtml = "Invalid user name or password";
                    }
               }

               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("SubmitClick_Error: " + ex.Message, "ChangePassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //Common.InsertErrorLog("btn_Submit_Click : " + ex.Message, "ChangePassword.aspx.cs", "", 0);
                    //throw;
               }
          }
     }
}