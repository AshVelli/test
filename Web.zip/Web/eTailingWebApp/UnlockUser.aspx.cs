﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using eTailingBAL;
using System.Diagnostics;

namespace eTailingWebApp
{
     public partial class UnlockUser : System.Web.UI.Page
     {
          protected void Page_Load(object sender, EventArgs e)
          {
               Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
               Response.Cache.SetAllowResponseInBrowserHistory(false);
               Response.Cache.SetNoStore();
               try
               {
                    if (!IsPostBack)
                    {
                         PageLoadSettings();
                         CaptchaRefresh();
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("PageLoad_Error: " + ex.Message, "UnlockUser.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (appCode == "dataforce")
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;                         
               }
          }

          protected void PageLoadSettings()
          {
               lblMsgSteps.InnerHtml = "";
               txtSecAns1.Text = "";
               txtVerCode.Text = "";
          }

          protected void btn_Submit_Click(object sender, CommandEventArgs e)
          {
               try
               {
                    string UserName = string.Empty;

                    if (e.CommandName == "Step1")
                    {
                         UserName = TxtUserName.Text.Trim();
                         DataTable dtChkUserexists = ProTransaction.CheckUserInfo(UserName, "", "C");
                         if (dtChkUserexists == null)
                         {
                              lblMsgSteps.InnerHtml = "Username does not exist.";
                              return;
                         }
                         if (dtChkUserexists.Rows.Count == 0)
                         {
                              lblMsgSteps.InnerHtml = "Username does not exist.";
                              return;
                         }
                         else
                         {
                              DataTable dtLoadSecQ = ProTransaction.GetUserSecQuest(UserName);
                              if (dtLoadSecQ != null)
                              {
                                   if (dtLoadSecQ.Rows.Count != 0)
                                   {
                                        lblMsgSteps.InnerHtml = "";
                                        mvwUnlock.ActiveViewIndex = 1;
                                        ddlsecquestion.DataSource = dtLoadSecQ;
                                        ddlsecquestion.DataTextField = "Question";
                                        ddlsecquestion.DataValueField = "Qid";
                                        ddlsecquestion.DataBind();
                                        ddlsecquestion.Items.Insert(0, new ListItem("--Select--", ""));
                                   }
                                   else
                                   {
                                        lblMsgSteps.InnerHtml = "Security questions do not exist. Please contact administrator.";
                                   }
                              }
                         }
                    }
                    else if (e.CommandName == "Step2")
                    {
                         if (Session["Code"].ToString().Trim() == txtVerCode.Text.Trim())
                         {
                              lblMsgSteps.InnerHtml = "";
                              PasswordEncription pass = new PasswordEncription();
                              UserName = TxtUserName.Text.Trim();
                              string SecureAns1 = GlobalVal.GetDecryptValue(txtSecAns1.Text.Trim());
                              DataTable dtChkUserSecurity = ProTransaction.CheckUserSecurity(UserName, SecureAns1, ddlsecquestion.SelectedValue, "", "", "");
                              if (dtChkUserSecurity == null)
                              {
                                   lblMsgSteps.InnerHtml = "Invalid security Answer(s)";
                                   CaptchaRefresh();
                              }
                              if (dtChkUserSecurity.Rows.Count == 0)
                              {
                                   lblMsgSteps.InnerHtml = "Invalid security Answer(s)";
                                   CaptchaRefresh();
                              }
                              if (dtChkUserSecurity.Rows.Count > 0)
                              {
                                   if (TxtUserName.Text.ToString().TrimEnd().TrimStart().Length > 0)
                                   {
                                        UserName = TxtUserName.Text.TrimEnd().TrimStart();
                                        DataTable dtUnlock = ProTransaction.CheckUserInfo(UserName, "", "UL");
                                        txtSecAns1.Text = "";
                                        txtVerCode.Text = "";
                                        ddlsecquestion.SelectedIndex = 0;
                                        lblMsgSteps.InnerHtml = "Your username has been unlocked.";
                                        CaptchaRefresh();
                                   }
                              }
                         }
                         else
                         {
                              CaptchaRefresh();
                              txtVerCode.Text = "";
                              txtSecAns1.Text = "";
                              ddlsecquestion.SelectedIndex = 0;
                              lblMsgSteps.InnerHtml = "Please enter the verification code correctly.";
                         }
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("UnlockClick_Error: " + ex.Message, "UnlockUser.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void btn1back_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("loginhome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackButton1_Error: " + ex.Message, "UnlockUser.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void btnBack2_Click(object sender, EventArgs e)
          {
               try
               {
                    mvwUnlock.ActiveViewIndex = 0;
                    CaptchaRefresh();
                    PageLoadSettings();
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackButton2_Error: " + ex.Message, "UnlockUser.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void ImgRefresh_Click(object sender, ImageClickEventArgs e)
          {
               try
               {
                    CaptchaRefresh();
                    mvwUnlock.ActiveViewIndex = 1;
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CaptchaRefresh_Error: " + ex.Message, "UnlockUser.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          private void CaptchaRefresh()
          {
               Session["Code"] = null;
               Random ran = new Random();
               myImage.ImageUrl = "~/CaptchaControl.aspx?Id=" + ran.Next(1, 9).ToString();
          }

          protected void hlLogin_Click(object sender, EventArgs e)
          {
               try
               {
                    Session.Abandon();
                    Session["Start"] = null;
                    HttpContext.Current.Cache.Remove(TxtUserName.Text);
                    Server.Transfer("~/LoginHome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("LoginHyperlinkClick_Error: " + ex.Message, "ChangePassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }
     }
}