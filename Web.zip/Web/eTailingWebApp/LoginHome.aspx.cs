﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.Profile;
using System.Text;
using System.Xml.Linq;
using System.Diagnostics;
using System.Reflection;
using eTailingBAL;


namespace eTailingWebApp
{
     public partial class LoginHome : System.Web.UI.Page
     {
          PasswordEncription pass = new PasswordEncription();
          private int _userSeqId;
          private int _flag = -1;

          #region Page Pre-Init: force uplevel browser setting
          protected void Page_PreInit(object sender, EventArgs e)
          {
               if (BrowserCompatibility.IsUplevel)
               {
                    Page.ClientTarget = "uplevel";
               }
          }
          #endregion


          protected void Page_Init(object sender, EventArgs e)
          {
               if (Request.Form.Count > 0)
               {
                    string appCode = Convert.ToString(Request.Form["ApplicationCode"]);
                    if (!string.IsNullOrEmpty(appCode))
                    {
                         string cssPath = "~/css/" + appCode + "_styles.css";
                         lnkCSS.Attributes["href"] = cssPath;
                    }
               }
               else if (Convert.ToString(Session["ApplicationCode"]) != null)
               {
                    string appCode = Convert.ToString(Session["ApplicationCode"]);
                    if (!string.IsNullOrEmpty(appCode))
                    {
                         string cssPath = "~/css/" + appCode + "_styles.css";
                         lnkCSS.Attributes["href"] = cssPath;
                    }
               }

          }


          protected void Page_Load(object sender, EventArgs e)
          {
               try
               {
                    string sessionId = Session.SessionID;
                    if (!IsPostBack)
                    {
                         txtUserName.Attributes.Add("onkeypress", "return validateAlphaNumeric()");
                         txtPassword.Attributes.Add("onkeypress", "return validatePassword()");                         
                         if (Request.Form.Count > 0)
                         {
                              if (Request.UrlReferrer != null)
                                   Session["prevPage"] = Request.UrlReferrer.ToString();
                              if (Request.Form["Amount"] == "")
                              {
                                   ClientScript.RegisterClientScriptBlock(this.GetType(), "Amount", "<script type = 'text/javascript'>alert('Amount is empty & you should enter amount to complete transaction');</script>");
                                   if (Request.UrlReferrer.ToString() != null)
                                   {
                                        Response.Redirect(Request.UrlReferrer.ToString());
                                   }
                              }
                              else
                              {
                                   Session["Amount"] = Request.Form["Amount"];
                              }
                              Session["ApplicationCode"] = Request.Form["ApplicationCode"];
                         }
                         else if (Session["ApplicationCode"] == null || Session["Amount"] == null)
                         {
                              btnSubmit.Visible = false;
                         }
                    }
                    System.Text.StringBuilder sbValid = new System.Text.StringBuilder();
                    sbValid.Append("if(Validation() == false){return false;}");
                    sbValid.Append("this.value = 'Please wait...';");
                    sbValid.Append("this.disabled = true;");
                    sbValid.Append(this.Page.GetPostBackEventReference(this.btnSubmit));
                    sbValid.Append(";");
                    this.btnSubmit.Attributes.Add("onclick", sbValid.ToString());
                    txtUserName.Attributes.Add("onpaste", "return false");
                    txtUserName.Focus();
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Page_load_Error: " + ex.Message, "LoginHome.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
               finally
               {
                    txtUserName.Focus();
               }
          }

          protected void btnSubmit_Click(object sender, EventArgs e)
          {
               try
               {
                    PasswordEncription pass = new PasswordEncription();
                    DataTable dt = ProTransaction.CheckUserInfo(HttpUtility.HtmlEncode(txtUserName.Text.Trim()), pass.Encription(txtPassword.Text.Trim()), "V");
                    if (dt != null)
                    {
                         if (dt.Rows.Count > 0)
                         {
                              if (dt.Rows[0]["ApprovalFlag"].ToString() == "0")
                              {
                                   lblMsg.Text = "The user is not approved.  Please contact the system admin to activate.";
                              }
                              else if (Convert.ToInt32((dt.Rows[0]["USERLOCKFLG"].ToString())) == 1)
                              {
                                   lblMsg.Text = "Username is locked";
                              }
                              else
                              {
                                   int userSeqId = BLL_Login.GetUserSeqId(txtUserName.Text);
                                   _flag = BLL_Login.GetUserLoggedInFlag(userSeqId);
                                   if (_flag == 0)
                                   {
                                        CallLogin(txtUserName.Text, dt);
                                        lblMsg.Text = "logged in";
                                        if (Session["prevPage"] != null && Session["Amount"] != null &&
                                            Session["ApplicationCode"] != null)
                                        {
                                             string transactionId = "";
                                             HOVSPaymentService.CreditCardPaymentResponse res = MakePayment(out transactionId);
                                             LogUserTransaction(res, txtUserName.Text, transactionId);
                                             NameValueCollection collections = new NameValueCollection();
                                             collections.Add("TransactionId", transactionId);
                                             collections.Add("Status", res.Status.ToString());
                                             collections.Add("Error", res.ErrorDesc);
                                             if (collections["Status"] == "SUCCESS")
                                             {
                                                  SendMail.SendTransactionStatusMail(56, transactionId);
                                             }
                                             else if (collections["Status"] == "FAILED")
                                             {
                                                  SendMail.SendTransactionStatusMail(57, transactionId);
                                             }
                                             Session["Amount"] = null;
                                             Session["ApplicationCode"] = null;
                                             string prevPage = Session["prevPage"].ToString();
                                             BLL_Login.SetFlagInSessionLog(userSeqId, 0);
                                             Session["prevPage"] = null;
                                             PostData(prevPage, collections);
                                             //Response.Redirect(prevPage, true);
                                        }
                                   }
                                   else if (_flag == 1)
                                   {
                                        _flag = 0;
                                        BLL_Login.SetFlagInSessionLog(userSeqId, _flag);
                                        lblMsg.Text = "You have already logged in , Enter password again & click login to continue";
                                   }
                              }
                         }
                         else
                         {
                              lblMsg.Text = "Invalid username or password";
                         }
                    }
                    else
                    {
                         lblMsg.Text = "Invalid username or password";
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Login_Error: " + ex.Message, "LoginHome.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          private void LogUserTransaction(HOVSPaymentService.CreditCardPaymentResponse res, string userLoginId, string etTransactionID)
          {
               CCTransactions ccTran = new CCTransactions();
               ccTran.ET_TransactionID = etTransactionID;
               ccTran.PG_TransactionID = res.TransactionID == null ? "" : res.TransactionID;
               ccTran.Status = res.Status.ToString();
               ccTran.ErrorDescription = res.ErrorDesc == null ? "" : res.ErrorDesc;
               ccTran.TransactionAmount = Convert.ToDecimal(Session["Amount"]);
               ccTran.ApplicationCode = Session["ApplicationCode"].ToString();
               ccTran.InsertUserTransactionLog(userLoginId);
          }

          protected void PostData(string url, NameValueCollection collections)
          {
               string html = "<html><head>";
               html += "</head><body onload='document.forms[0].submit()'>";
               html += string.Format("<form name='PostForm' method='POST' action='{0}'>", url);
               foreach (string key in collections.Keys)
               {
                    html += string.Format("<input name='{0}' type='hidden' value='{1}'>", key, collections[key]);
               }
               html += "</form></body></html>";
               Response.Clear();
               Response.ContentEncoding = Encoding.GetEncoding("ISO-8859-1");
               Response.HeaderEncoding = Encoding.GetEncoding("ISO-8859-1");
               Response.Charset = "ISO-8859-1";
               Response.Write(html);
               HttpContext.Current.ApplicationInstance.CompleteRequest();
               //Response.End();
          }

          private void CallLogin(string sKey, DataTable dt)
          {
               string Rolename = string.Empty;
               Session["UserName"] = dt.Rows[0]["UserLoginID"].ToString();
               Session["UserSeqID"] = Convert.ToInt32(dt.Rows[0]["UserSeqID"].ToString());
               Session["providersqlID"] = Convert.ToInt32(dt.Rows[0]["UserSeqID"].ToString());
               Session["Url"] = Request.Url.ToString().Substring(0, Convert.ToInt32(Request.Url.ToString().LastIndexOf('/')));
               Session["OrigUserSeqId"] = Convert.ToString(dt.Rows[0]["UserSeqID"].ToString());
               Session["EMailID"] = Convert.ToString(dt.Rows[0]["EMailID"].ToString());
               SendMail._emailId = Session["EMailID"].ToString();
               string strUserCode = dt.Rows[0]["UserCode"].ToString();
               Session["Start"] = dt.Rows[0]["GettingStart"].ToString();
               Application["User"] = Convert.ToInt32(Application["User"]) + 1;
               Session["UserCode"] = strUserCode;
               HttpContext.Current.Session.Timeout = 15;
               TimeSpan SessTimeOut = new TimeSpan(0, 0, HttpContext.Current.Session.Timeout, 0, 0);
               HttpContext.Current.Cache.Insert(sKey, sKey, null, DateTime.MaxValue, SessTimeOut, System.Web.Caching.CacheItemPriority.NotRemovable, null);
               Session["singleuser"] = HttpUtility.HtmlEncode(txtUserName.Text);
               HttpCookie SingleUserCookie = new HttpCookie("singleuser", HttpUtility.HtmlEncode(txtUserName.Text));
               SingleUserCookie.Expires = DateTime.Now.AddMinutes((double)HttpContext.Current.Session.Timeout);
               Response.Cookies.Add(SingleUserCookie);
               string IPAddr = string.Empty;
               IPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
               if (IPAddr == "" || IPAddr == null)
                    IPAddr = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
               BLL_Login.SessionLog(Convert.ToInt32(dt.Rows[0]["UserSeqID"].ToString()), Session.SessionID, IPAddr, HttpContext.Current.Session.Timeout);
               BLL_Login.SetFlagInSessionLog(Convert.ToInt32(dt.Rows[0]["UserSeqID"].ToString()), 1);
               FormsAuthentication.Initialize();
               FormsAuthenticationTicket fat = new FormsAuthenticationTicket(1,
                    HttpUtility.HtmlEncode(txtUserName.Text.Trim()), DateTime.Now,
                   DateTime.Now.AddMinutes(Convert.ToDouble(HttpContext.Current.Session.Timeout)), false, Rolename,
                   FormsAuthentication.FormsCookiePath);
               Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName,
                   FormsAuthentication.Encrypt(fat)));

          }

          private HOVSPaymentService.CreditCardPaymentResponse MakePayment(out string transactionId)
          {
               HOVSPaymentService.CreditCardPaymentRequest ccPaymentRequest = new HOVSPaymentService.CreditCardPaymentRequest();
               DataSet ds = PmsUserMethods.ProviderRegistration.GetCCDetails(Session["UserName"].ToString());
               PasswordEncription PassDesc = new PasswordEncription();

               ccPaymentRequest.eftRegisteredUserName = Convert.ToString(ConfigurationManager.AppSettings["PGRegisteredUserID"]);
               ccPaymentRequest.eftRegisteredpassword = Convert.ToString(ConfigurationManager.AppSettings["PGRegisteredUserPassword"]);

               transactionId = GetTransactionID();
               ccPaymentRequest.reftransactionID = transactionId;

               ccPaymentRequest.cardHolderName = PassDesc.Decription(ds.Tables[0].Rows[0]["CardHolderName"].ToString());

               string creditCartType = ds.Tables[0].Rows[0]["CardType"].ToString();
               if (creditCartType == "Visa")
                    ccPaymentRequest.cardType = HOVSPaymentService.CardType.Visa;
               else if (creditCartType == "Master")
                    ccPaymentRequest.cardType = HOVSPaymentService.CardType.MasterCard;
               else if (creditCartType == "American Express")
                    ccPaymentRequest.cardType = HOVSPaymentService.CardType.AMEX;

               ccPaymentRequest.cardNumber = PassDesc.Decription(ds.Tables[0].Rows[0]["CardNumber"].ToString());

               DateTime expiryDate = Convert.ToDateTime(PassDesc.Decription(ds.Tables[0].Rows[0]["ExpiryDate"].ToString()));
               ccPaymentRequest.expMonth = (HOVSPaymentService.ExpMonth)expiryDate.Month;
               ccPaymentRequest.expYear = expiryDate.Year;

               //ccPaymentRequest.CVV2 = PassDesc.Decription(ds.Tables[0].Rows[0]["CVV"].ToString());
               ccPaymentRequest.billingUserName = PassDesc.Decription(ds.Tables[0].Rows[0]["CardHolderName"].ToString());
               ccPaymentRequest.userAddress1 = PassDesc.Decription(ds.Tables[0].Rows[0]["Address1"].ToString());
               ccPaymentRequest.userAddress2 = PassDesc.Decription(ds.Tables[0].Rows[0]["Address2"].ToString());
               ccPaymentRequest.userState = PassDesc.Decription(ds.Tables[0].Rows[0]["State"].ToString());
               ccPaymentRequest.userCity = PassDesc.Decription(ds.Tables[0].Rows[0]["City"].ToString());
               ccPaymentRequest.userZip = Convert.ToInt32(PassDesc.Decription(ds.Tables[0].Rows[0]["Zip"].ToString()));
               ccPaymentRequest.userPhone = PassDesc.Decription(ds.Tables[0].Rows[0]["Mobile"].ToString());
               ccPaymentRequest.userEmailID = ds.Tables[0].Rows[0]["EMailID"].ToString();

               ccPaymentRequest.depositAmount = Convert.ToDecimal(Session["BillAmount"]);
               ccPaymentRequest.tipAmount = 0;
               ccPaymentRequest.eCommerce = "yes";
               ccPaymentRequest.cardPresent = "Yes";
               ccPaymentRequest.token = Convert.ToString(ConfigurationManager.AppSettings["RequestToken"]);
               ccPaymentRequest.serverIP = Convert.ToString(ConfigurationManager.AppSettings["PGServerIP"]);
               ccPaymentRequest.serverName = Convert.ToString(ConfigurationManager.AppSettings["PGServerName"]);

               HOVSPaymentService.HOVSPaymentServiceClient svc = new HOVSPaymentService.HOVSPaymentServiceClient();
               return svc.CreditCardPayment(ccPaymentRequest);

          }

          private string GetTransactionID()
          {

               Random random = new Random();
               string r = "";
               int i;
               for (i = 1; i < 7; i++)
               {
                    r += random.Next(0, 9).ToString();
               }

               return "ET" + "BC" + r;
          }

          private void Autologin()
          {
               try
               {
                    string UserName = string.Empty;
                    if (Request.Form["Autologin"] != null)
                    {
                         string[] AutoLog = Request.Form["Autologin"].Split(',');
                         UserName = AutoLog[0].ToString();
                    }
                    else if (Request.QueryString["UserName"] != null)
                    {
                         string uname = Request.QueryString["UserName"].ToString();
                         UserName = pass.Decription(uname.Replace(" ", "+"));
                    }
                    DataTable dt = ProTransaction.CheckInfo(UserName);
                    if (dt != null)
                    {
                         if (dt.Rows.Count > 0)
                         {
                              if (Convert.ToInt32((dt.Rows[0]["USERLOCKFLG"].ToString())) == 1)
                              {
                                   lblMsg.Text = "Username is locked";
                              }
                              else
                              {
                                   string sKey = HttpUtility.HtmlEncode(txtUserName.Text);
                                   string sUser = Convert.ToString(Cache[sKey]);
                                   if (sUser == null || sUser == String.Empty)
                                   {
                                        CallLogin(sKey, dt);
                                        Session["Start"] = "FALSE";
                                   }
                                   else
                                   {
                                        lblMsg.Text = "Already logged in";
                                   }
                              }
                         }
                         else
                         {
                              lblMsg.Text = "Invalid username or password";
                         }
                    }
                    else
                    {
                         lblMsg.Text = "Invalid username or password";
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Auto_Login_Error: " + ex.Message, "LoginHome.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }
          //#<asp:Button class="btn btn-primary btn-lg" runat="server" Style="font-family: 'Arial Rounded MT'; font-size: larger; font-size-adjust: inherit;" Text="Update Profile " ID="btnUpdateProfile" OnClick="btnUpdateProfile_OnClick" />
          // protected void btnUpdateProfile_OnClick(object sender, EventArgs e)
          // {
          //    PasswordEncription pass = new PasswordEncription();
          //    DataTable dt = ProTransaction.CheckUserInfo(HttpUtility.HtmlEncode(txtUserName.Text.Trim()), pass.Encription(txtPassword.Text.Trim()), "V");
          //    if (dt != null)
          //    {
          //       if (dt.Rows.Count > 0)
          //       {
          //          int userSeqId = BLL_Login.GetUserSeqId(txtUserName.Text);
          //          _userSeqId = userSeqId;
          //       }
          //    }
          //    Response.Redirect("ModifyProfile.aspx?UserSeqId=" + _userSeqId);
          // }
          protected void hrefModifyProfile_Click(object sender, EventArgs e)
          {
               try
               {
                    PasswordEncription pass = new PasswordEncription();
                    DataTable dt = ProTransaction.CheckUserInfo(HttpUtility.HtmlEncode(txtUserName.Text.Trim()), pass.Encription(txtPassword.Text.Trim()), "V");
                    if (dt != null)
                    {
                         if (dt.Rows.Count > 0)
                         {
                              if (dt.Rows[0]["ApprovalFlag"].ToString() == "0")
                              {
                                   lblMsg.Text = "The user is not approved.  Please contact the system admin to activate.";
                              }
                              else if (Convert.ToInt32((dt.Rows[0]["USERLOCKFLG"].ToString())) == 1)
                              {
                                   lblMsg.Text = "Username is locked";
                              }
                              else
                              {
                                   int userSeqId = BLL_Login.GetUserSeqId(txtUserName.Text);
                                   _userSeqId = userSeqId;
                                   Response.Redirect("ModifyProfile.aspx?UserSeqId=" + _userSeqId);
                              }
                         }
                         else
                         {
                              lblMsg.Text = "Invalid username or password";
                         }
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Modify_Profile_Error: " + ex.Message, "LoginHome.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }
     }
}