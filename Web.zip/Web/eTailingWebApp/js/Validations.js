//Filling Date in Dropdownlist
/* Checks for Saturdays after 10 days from the current date */
function ValidEnd(year, month, day) {
    var chkDate = new Date(year, month, day);
    var curDate = new Date();
    if (chkDate < curDate) {
        return false;
    }
    return true;
}

function ValidStart(year, month, day) {
    var chkDate = new Date(year, month, day);
    var curDate = new Date();
    if (chkDate > curDate) {
        return false;
    }
    return true;
}

function FillDate(DDL) {
    var myindex = DDL.selectedIndex;
    var dt_datetime = new Date;
    if (myindex == 0) {
        var dt = dt_datetime.getDate();
        dt_datetime.setDate(dt - 1)
        document.getElementById("txt_frmdate").value = (dt_datetime.getMonth() < 9 ? '0' : '') + (dt_datetime.getMonth() + 1) + "/" + (dt_datetime.getDate() < 10 ? '0' : '') + dt_datetime.getDate() + "/" + dt_datetime.getFullYear()
        document.getElementById("txt_todate").value = (dt_datetime.getMonth() < 9 ? '0' : '') + (dt_datetime.getMonth() + 1) + "/" + (dt_datetime.getDate() < 10 ? '0' : '') + dt_datetime.getDate() + "/" + dt_datetime.getFullYear()
    }
    if (myindex == 1) {
        StartOfLastWeekMS = dt_datetime.getTime() - (24 * 60 * 60 * 1000 * (dt_datetime.getDay() + 6));
        dt_datetime = new Date(StartOfLastWeekMS);

        document.getElementById("txt_frmdate").value = (dt_datetime.getMonth() + 1 < 9 ? '0' : '') + (dt_datetime.getMonth() + 1) + "/" + ((dt_datetime.getDate()) < 10 ? '0' : '') + (dt_datetime.getDate()) + "/" + dt_datetime.getFullYear()
        var dt = dt_datetime.getDate();
        dt_datetime.setDate(dt + 6)
        document.getElementById("txt_todate").value = (dt_datetime.getMonth() + 1 < 9 ? '0' : '') + (dt_datetime.getMonth() + 1) + "/" + ((dt_datetime.getDate()) < 10 ? '0' : '') + (dt_datetime.getDate()) + "/" + dt_datetime.getFullYear()
    }
    if (myindex == 2) {
        document.getElementById("txt_frmdate").value = (dt_datetime.getMonth() < 9 ? '0' : '') + (dt_datetime.getMonth()) + "/" + '01' + "/" + dt_datetime.getFullYear()
        document.getElementById("txt_todate").value = (dt_datetime.getMonth() < 9 ? '0' : '') + (dt_datetime.getMonth()) + "/" + (daysInMonth(dt_datetime.getMonth(), dt_datetime.getFullYear()) < 10 ? '0' : '') + daysInMonth(dt_datetime.getMonth(), dt_datetime.getFullYear()) + "/" + dt_datetime.getFullYear()
    }
}

function daysInMonth(month, year) {
    var dd = new Date(year, month, 0);
    return dd.getDate();
}


// Setting the date
function getDate(from_txt_name, to_txt_name) {
    aDate = new Date();
    cur_date = aDate.format("MM/dd/yyyy");

    if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(document.getElementById(to_txt_name).value)) {
        alert("'From Date' should be less than or equal to 'To Date'");
        return false;
    }

    if (document.getElementById(from_txt_name).value == "" && document.getElementById(to_txt_name).value == "") {
        document.getElementById(from_txt_name).value = cur_date;
    }
    if (document.getElementById(from_txt_name).value != "" && document.getElementById(to_txt_name).value == "") {
        if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(cur_date)) {
            document.getElementById(to_txt_name).value = document.getElementById(from_txt_name).value;
        }
        else {

            document.getElementById(to_txt_name).value = cur_date;
        }
    }
    if (document.getElementById(from_txt_name).value == "" && document.getElementById(to_txt_name).value != "") {
        document.getElementById(from_txt_name).value = document.getElementById(to_txt_name).value;
    }
    return true;


}

function statusgetDate(from_txt_name, to_txt_name) {

    aDate = new Date();
    intMonth = aDate.getMonth() + 1;
    intDate = aDate.getDate();
    intDay = aDate.getDay();
    intYear = aDate.getFullYear();
    //added by paranthaman for date format
    if (intDate < 10) {
        intDate = "0" + intDate;
    }

    if (intMonth < 10) {
        intMonth = "0" + intMonth;
    }

    cur_date = intMonth + "/" + intDate + "/" + intYear;

    if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(document.getElementById(to_txt_name).value)) {
        alert("To date should less than From date");
        return false;
    }

    if (document.getElementById(from_txt_name).value != "" && document.getElementById(to_txt_name).value == "") {
        if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(cur_date)) {
            document.getElementById(to_txt_name).value = document.getElementById(from_txt_name).value;
        }
        else {

            document.getElementById(to_txt_name).value = cur_date;
        }
    }
    if (document.getElementById(from_txt_name).value == "" && document.getElementById(to_txt_name).value != "") {
        document.getElementById(from_txt_name).value = document.getElementById(to_txt_name).value;
    }
    return true;
}

// Restrict the user entry
function changeFocus(form_name, btn_name) {
    document.forms[form_name].elements[btn_name].focus();
    return false;
}

// Allow Numeric values only
function validateNumeric(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 65 && KeyID <= 90) || (KeyID >= 97 && KeyID <= 122) || (KeyID >= 32 && KeyID <= 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

// Allow Numeric values only
function validateNumericDate(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 65 && KeyID <= 90) || (KeyID >= 97 && KeyID <= 122) || (KeyID >= 32 && KeyID <= 46) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}
// Allow Character values only
function validateCharacter(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 32 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}


function validatedecimal(e) {
   
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 65 && KeyID <= 90) || (KeyID >= 97 && KeyID <= 122) || (KeyID >= 32 && KeyID <= 45) || (KeyID == 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

function validatedecimalforamountpaid(e) {
   
    var v = e.value;   
      
    var KeyID = (window.event) ? event.keyCode : e.which;
    if (v.length > 0 && ((v.indexOf('.', 0) != -1 && KeyID == 46)|| ((v.indexOf('+', 0) != -1 || v.indexOf('-', 0) != -1) && (KeyID == 43 || KeyID == 45))))
        return false;
    if ((KeyID >= 48 && KeyID <= 57) || KeyID == 46 || KeyID == 45 || KeyID == 43)
        return true;    
    return false;
}

// Allow Character values only
function validateCharacterWithSpace(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 33 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

// Allow AlphaNumeric values only
function validateAlphaNumeric(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 32 && KeyID <= 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}
// Allow AlphaNumeric  values only and Dot
function validatedotAlphaNumeric(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 32 && KeyID <= 45) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126 || (KeyID == 47))) {
        return false;
    }
    return true;
}

// Allow Alphabets only
function validateAlpha(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 32 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

// Allow AlphaNumeric values only
function validateNumericComma(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 65 && KeyID <= 90) || (KeyID >= 97 && KeyID <= 122) || (KeyID >= 32 && KeyID <= 43) || (KeyID >= 45 && KeyID <= 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

// Allow AlphaNumeric and space only
function validateAlphaNumericWithSpace(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 33 && KeyID <= 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}
// Allow Alpha and space only
function validateAlphaWithSpace(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 33 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}
// Restrict Space Only
function validatePassword(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if (KeyID >= 32 && KeyID <= 32) {
        return false;
    }
    return true;
}
function validatepagelink(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 32 && KeyID <= 45) || (KeyID == 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 94) || (KeyID == 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

function validatePageDesc(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 33 && KeyID <= 45) || (KeyID == 47) || (KeyID >= 58 && KeyID <= 64) || (KeyID >= 91 && KeyID <= 94) || (KeyID == 96) || (KeyID >= 123 && KeyID <= 126)) {
        return false;
    }
    return true;
}

function func_close() {
    var ret = new Object();
    ret.obj = "N";
    window.returnValue = ret;
    window.close();
}
// Textarea restriction
function textCounter(field, cntfield, maxlimit) {
    if (field.value.length > maxlimit) // if too long...trim it!
        field.value = field.value.substring(0, maxlimit);
    // otherwise, update 'characters left' counter
    else {
        if (cntfield != "")
            cntfield.value = maxlimit - field.value.length + " characters left";
    }
}

function RestrictKeys(e) {
    return false;
}

function IsNumeric(sText) {
    var ValidChars = "0123456789.";
    var IsNumber = true;
    var Char;

    for (i = 0; i < sText.length && IsNumber == true; i++) {
        Char = sText.charAt(i);
        if (ValidChars.indexOf(Char) == -1) {
            IsNumber = false;
        }
    }
    return IsNumber;
}

function Chk_SplCharsWithSpace(sText) {
    var NotValidChars = ".!@#$%^&*()_+=-~`{}[]|\\:\"; '<>,.?/";
    var Chk_SplCharsWithSpace = true;
    var Char;

    for (i = 0; i < sText.length && Chk_SplCharsWithSpace == true; i++) {
        Char = sText.charAt(i);
        if (NotValidChars.indexOf(Char) != -1) {
            Chk_SplCharsWithSpace = false;
        }
    }
    return Chk_SplCharsWithSpace;
}

function Chk_SplChars(sText) {
    var NotValidChars = ".!@#$%^&*()_+=-~`{}[]|\\:\"; '<>,.?/";
    var Chk_SplChars = true;
    var Char;

    for (i = 0; i < sText.length && Chk_SplChars == true; i++) {
        Char = sText.charAt(i);
        if (NotValidChars.indexOf(Char) != -1) {
            Chk_SplChars = false;
        }
    }
    return Chk_SplChars;
}

function Chk_SplNumCharsWithSpace(sText) {
    var NotValidChars = "1234567890.!@#$%^&*()_+=-~`{}[]|\\:\"; '<>,.?/";
    var Chk_SplNumCharsWithSpace = true;
    var Char;

    for (i = 0; i < sText.length && Chk_SplNumCharsWithSpace == true; i++) {
        Char = sText.charAt(i);
        if (NotValidChars.indexOf(Char) != -1) {
            Chk_SplNumCharsWithSpace = false;
        }
    }
    return Chk_SplNumCharsWithSpace;
}

function Chk_SplNumChars(sText) {
    var NotValidChars = "1234567890.!@#$%^&*()_+=-~`{}[]|\\:\"; '<>,.?/";
    var Chk_SplNumChars = true;
    var Char;

    for (i = 0; i < sText.length && Chk_SplNumChars == true; i++) {
        Char = sText.charAt(i);
        if (NotValidChars.indexOf(Char) != -1) {
            Chk_SplNumChars = false;
        }
    }
    return Chk_SplNumChars;
}

//date format validation checking start
// Declaring valid date character, minimum year and maximum year
var dtCh = "/";
var minYear = 1900;
var maxYear = 2100;

function isInteger(s) {
    var i;
    for (i = 0; i < s.length; i++) {
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag) {
    var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary(year) {
    // February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ((!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28);
}
function DaysArray(n) {
    for (var i = 1; i <= n; i++) {
        this[i] = 31
        if (i == 4 || i == 6 || i == 9 || i == 11) { this[i] = 30 }
        if (i == 2) { this[i] = 29 }
    }
    return this
}

function isDate(dtStr) {
    aDate = new Date();
    var daysInMonth = DaysArray(12)
    var pos1 = dtStr.indexOf(dtCh)
    var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
    var strMonth = dtStr.substring(0, pos1)
    var strDay = dtStr.substring(pos1 + 1, pos2)
    var strYear = dtStr.substring(pos2 + 1)
    strYr = strYear
    if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
    if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
    for (var i = 1; i <= 3; i++) {
        if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
    }
    month = parseInt(strMonth)
    day = parseInt(strDay)
    year = parseInt(strYr)
    if (pos1 == -1 || pos2 == -1) {
        alert("The date format should be : mm/dd/yyyy")
        return false
    }
    if (strMonth.length < 1 || month < 1 || month > 12) {
        alert("Please enter a valid month")
        return false
    }
    if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
        alert("Please enter a valid day")
        return false
    }
    if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
        alert("Please enter a valid year between " + minYear + " and " + maxYear)
        return false
    }
    if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) == false) {
        alert("Please enter a valid date")
        return false
    }
    if (Date.parse(dtStr) > Date.parse(aDate)) {
        alert("Future date is not allowed.")
        return false
    }

    return true
}

function isValidMCDOB(dtStr, boxno, msgstr) {
    aDate = new Date();
    var daysInMonth = DaysArray(12)
    var pos1 = dtStr.indexOf(dtCh)
    var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
    var strMonth = dtStr.substring(0, pos1)
    var strDay = dtStr.substring(pos1 + 1, pos2)
    var strYear = dtStr.substring(pos2 + 1)
    strYr = strYear
    if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
    if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
    for (var i = 1; i <= 3; i++) {
        if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
    }
    month = parseInt(strMonth)
    day = parseInt(strDay)
    year = parseInt(strYr)
    if (pos1 == -1 || pos2 == -1) {
        alert("The date format should be : mm/dd/yyyy")
        return false
    }
    if (strMonth.length < 1) {
        alert(boxno + ". Claim is missing " + msgstr + " Month of Birth")
        return false
    }
    if (month < 1 || month > 12) {
        alert(boxno + ". Claim has invalid " + msgstr + " Month of Birth")
        return false
    }
    if (strDay.length < 1) {
        alert(boxno + ". Claim is missing " + msgstr + " Day of Birth")
        return false
    }
    if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
        alert(boxno + ". Claim has invalid " + msgstr + " Day of Birth")
        return false
    }
    if (strYear.length < 1) {
        alert(boxno + ". Claim is missing " + msgstr + " Year of Birth")
        return false
    }
    if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
        alert(boxno + ". Claim has invalid " + msgstr + " Year of Birth.[Try between " + minYear + " and Current Year ]")
        return false
    }
    if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) == false) {
        alert(boxno + ". Claim has invalid " + msgstr + " Date of Birth")
        return false
    }
    if (Date.parse(dtStr) > Date.parse(aDate)) {
        alert(boxno + ". Future date not allowed for " + msgstr + " Date of Birth")
        return false
    }

    return true
}

function IsValidDateBox(dtStr, boxno,msg) {
    aDate = new Date();
    var daysInMonth = DaysArray(12)
    var pos1 = dtStr.indexOf(dtCh)
    var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
    var strMonth = dtStr.substring(0, pos1)
    var strDay = dtStr.substring(pos1 + 1, pos2)
    var strYear = dtStr.substring(pos2 + 1)
    strYr = strYear
    if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
    if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
    for (var i = 1; i <= 3; i++) {
        if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
    }
    month = parseInt(strMonth)
    day = parseInt(strDay)
    year = parseInt(strYr)
    if (pos1 == -1 || pos2 == -1) {
        alert(boxno + ". The date format should be : mm/dd/yyyy")
        return false
    }
    if (month < 1 || month > 12) {
        alert(boxno + ". Claim has invalid Month.")
        return false
    }
    if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
        alert(boxno + ". Claim has invalid Day.")
        return false
    }
    if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
        alert(boxno + ". Claim has invalid Year.[" + msg + " ]")
        return false
    }
    if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) == false) {
        alert(boxno + ". Claim has invalid Date.")
        return false
    }
    if (Date.parse(dtStr) > Date.parse(aDate)) {
        alert(boxno + ". Future date not allowed here.")
        return false
    }
    return true
}

function CheckIsValidDate(dtStr, rowno) {
    aDate = new Date();
    var daysInMonth = DaysArray(12)
    var pos1 = dtStr.indexOf(dtCh)
    var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
    var strMonth = dtStr.substring(0, pos1)
    var strDay = dtStr.substring(pos1 + 1, pos2)
    var strYear = dtStr.substring(pos2 + 1)
    strYr = strYear
    if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
    if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
    for (var i = 1; i <= 3; i++) {
        if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
    }
    minYear = 2000;
    maxYear = 2100;
    month = parseInt(strMonth)
    day = parseInt(strDay)
    year = parseInt(strYr)
    if (pos1 == -1 || pos2 == -1) {
        if (rowno)
            alert("The date format should be : mm/dd/ccyy in row" + rowno)
        else
            alert("The date format should be : mm/dd/ccyy")
        return false
    }
    if (month < 1 || month > 12) {
        if (rowno)
            alert("Invalid Date in row" + rowno)
        else
            alert("Invalid Date.The Date format should be 'mm/dd/yyyy' only.")
        return false
    }
    if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
        if (rowno)
            alert("Invalid Date in row" + rowno)
        else
            alert("Invalid Date.The Date format should be 'mm/dd/yyyy' only.")
        return false
    }
    if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
        if (rowno)
            alert("Date has invalid Year in row" + rowno)
        else
            alert("Date has invalid Year.")
        return false
    }
    if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) == false) {
        if (rowno)
            alert("Invalid Date in row" + rowno)
        else
            alert("Invalid Date.The Date format should be 'mm/dd/yyyy' only.")
        return false
    }
    if (Date.parse(dtStr) > Date.parse(aDate)) {
        if (rowno)
            alert("Future date not allowed in row" + rowno)
        else
            alert("Future date not allowed here.")
        return false
    }
    return true
}

function IsValidSrvDate(dtStr, boxno) {
    aDate = new Date();
    var daysInMonth = DaysArray(12)
    var pos1 = dtStr.indexOf(dtCh)
    var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
    var strMonth = dtStr.substring(0, pos1)
    var strDay = dtStr.substring(pos1 + 1, pos2)
    var strYear = dtStr.substring(pos2 + 1)
    strYr = strYear
    if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
    if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
    for (var i = 1; i <= 3; i++) {
        if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
    }
    month = parseInt(strMonth)
    day = parseInt(strDay)
    year = parseInt(strYr)
    if (pos1 == -1 || pos2 == -1) {
        alert(boxno + ". The date format should be : mm/dd/yyyy")
        return false
    }
    if (month < 1 || month > 12) {
        alert(boxno + ". Claim has invalid Month.")
        return false
    }
    if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day > daysInFebruary(year)) || day > daysInMonth[month]) {
        alert(boxno + ". Claim has invalid Day.")
        return false
    }
    if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
        alert(boxno + ". Claim has invalid Year.[Try between " + minYear + " and " + maxYear + "]")
        return false
    }
    if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || isInteger(stripCharsInBag(dtStr, dtCh)) == false) {
        alert(boxno + ". Claim has invalid Date.")
        return false
    }
    
    return true
}
function Validatedateformat(sText) {
    //var dt=document.frmSample.txtDate
    var dt = sText
    if (isDate(dt.value) == false) {
        dt.focus()
        return false
    }
    return true
}

// date format validation check end

function confirmationmsg() {
    alert("This page is under construction...");
    return false;
}

//Trim the leading & trailing edge
function trim(str) {
    if (str == "")
        return "";
    else {
        return str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
    }
}

//Validation to allow only numeric value with Dot(.) and comma(,) on click
function Chk_SplaphaCharswithdot(sText) {
    if (sText == "") return false;
    var ValidChars = "0123456789.,";
    var IsNumber = true;
    var Char;
    var dotCnt = 0;

    for (i = 0; i < sText.length && IsNumber == true; i++) {
        Char = sText.charAt(i);
        if (Char == ".") dotCnt = dotCnt + 1;
        if (ValidChars.indexOf(Char) == -1 || dotCnt > 1) {
            IsNumber = false;
        }
    }
    return IsNumber;
}

//Validation to allow only numeric value with Dot(.) on click
function Chk_SplaphaCharswithoutcomma(sText) {
    if (sText == "") return false;
    var ValidChars = "0123456789.";
    var IsNumber = true;
    var Char;
    var dotCnt = 0;

    for (i = 0; i < sText.length && IsNumber == true; i++) {
        Char = sText.charAt(i);
        if (Char == ".") dotCnt = dotCnt + 1;
        if (ValidChars.indexOf(Char) == -1 || dotCnt > 1) {
            IsNumber = false;
        }
    }
    return IsNumber;
}

//Validation to allows alphanumeric, #():/-,. & space on click
function validateAlphaNumericwithsplchar(sText) {
    if (sText == "") return false;
    var ValidChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#()/:-,. ";
    var IsValid = true;
    var Char;
    var dotCnt = 0;

    for (i = 0; i < sText.length && IsValid == true; i++) {
        Char = sText.charAt(i);
        if (Char == ".") dotCnt = dotCnt + 1;
        if (ValidChars.indexOf(Char) == -1 || dotCnt > 1) {
            IsValid = false;
        }
    }
    return IsValid;
}

//Validation to allow only numeric value with Dot(.) and ,
function validateNumwithdotKPress(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 48 && KeyID <= 57) || (KeyID >= 44 && KeyID <= 44) || (KeyID >= 46 && KeyID <= 46))
        return true;
    else
        return false;
}

//Validation to allows alphanumeric, #():/-,. & space
function validateAlphaNumKPress(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 97 && KeyID <= 122) || (KeyID >= 65 && KeyID <= 90) || (KeyID >= 48 && KeyID <= 58) || (KeyID >= 32 && KeyID <= 32) || (KeyID >= 35 && KeyID <= 35) || (KeyID >= 40 && KeyID <= 41) || (KeyID >= 44 && KeyID <= 47))
        return true;
    else
        return false;

}

//Validation to allows alphanumeric with - & _
function Chk_SplAlphaNumericWithMinusUnderscore(sText) {
    var NotValidChars = ".!@#$%^&*()+=~`{}[]|\\:\"; '<>,.?/";
    var Chk_SplCharsWithSpace = true;
    var Char;

    for (i = 0; i < sText.length && Chk_SplCharsWithSpace == true; i++) {
        Char = sText.charAt(i);
        if (NotValidChars.indexOf(Char) != -1) {
            Chk_SplCharsWithSpace = false;
        }
    }
    return Chk_SplCharsWithSpace;
}

//Validation to allows alphanumeric, - & _
function validateAlphaNumKMinusUnderscorePress(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 97 && KeyID <= 122) || (KeyID >= 65 && KeyID <= 90) || (KeyID >= 48 && KeyID <= 57) || (KeyID >= 45 && KeyID <= 45) || (KeyID >= 95 && KeyID <= 95))
        return true;
    else
        return false;

}

//Validation to allows alphanumeric on click
function chk_validateAlphaNumeric(sText) {
    if (sText == "") return false;
    var ValidChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var IsValid = true;
    var Char;
    var dotCnt = 0;

    for (i = 0; i < sText.length && IsValid == true; i++) {
        Char = sText.charAt(i);
        if (Char == ".") dotCnt = dotCnt + 1;
        if (ValidChars.indexOf(Char) == -1 || dotCnt > 1) {
            IsValid = false;
        }
    }
    return IsValid;
}

//Validation to allows Numeric
function validateNumericOnKPress(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if ((KeyID >= 48 && KeyID <= 57))
        return true;
    else
        return false;

}

function datediff(stDate, endDate) {

    //Getting Start date value from the control   

    var dtStDate = new Date(stDate);

    //Getting End date value from the control

    var dtEndDate = new Date(endDate);

    var one_day = 1000 * 60 * 60 * 24;

    if (dtStDate != "NaN" && dtEndDate != "NaN")

    //Assigning the Difference in days to the control

        return Math.ceil((dtEndDate.getTime() - dtStDate.getTime()) / (one_day)) + 1;


}







// latest getdate 
function getDate_valid(from_txt_name, to_txt_name) {
    aDate = new Date();
    cur_date = aDate.format("MM/dd/yyyy");

    if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(document.getElementById(to_txt_name).value)) {
        alert("'From Date' should be less than or equal to 'To Date'");
        return false;
    }

    if (document.getElementById(from_txt_name).value == "" && document.getElementById(to_txt_name).value == "") {
        document.getElementById(from_txt_name).value = cur_date;
    }
    if (document.getElementById(from_txt_name).value != "" && document.getElementById(to_txt_name).value == "") {
        if (Date.parse(document.getElementById(from_txt_name).value) > Date.parse(cur_date)) {
            document.getElementById(to_txt_name).value = document.getElementById(from_txt_name).value;
        }
        else {

            document.getElementById(to_txt_name).value = cur_date;
        }
    }
    if (document.getElementById(from_txt_name).value == "" && document.getElementById(to_txt_name).value != "") {
        document.getElementById(from_txt_name).value = document.getElementById(to_txt_name).value;
    }
    return true;


}

function isValidEmail(email) {
    email = email.toLowerCase();  
    var RegExp = /^((([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|\/|=|\?|\^|_|`|\{|\||\}|~)+(\.([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|\/|=|\?|\^|_|`|\{|\||\}|~)+)*)@((((([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.))*([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.)[\w]{2,4}|(((([0-9]){1,3}\.){3}([0-9]){1,3}))|(\[((([0-9]){1,3}\.){3}([0-9]){1,3})\])))$/
    if (RegExp.test(email)) {
        return true;
    } else {
        return false;
    }
}


function isValidURL(url) {
    var RegExp = /^(([\w]+:)?\/\/)?(([\d\w]|%[a-fA-f\d]{2,2})+(:([\d\w]|%[a-fA-f\d]{2,2})+)?@)?([\d\w][-\d\w]{0,253}[\d\w]\.)+[\w]{2,4}(:[\d]+)?(\/([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)*(\?(&?([-+_~.\d\w]|%[a-fA-f\d]{2,2})=?)*)?(#([-+_~.\d\w]|%[a-fA-f\d]{2,2})*)?$/;
    if (RegExp.test(url)) {
        return true;
    } else {
        return false;
    }
}
function Upper(e, r) {
    if (e.keyCode > 96 && e.keyCode < 123)
        r.value = r.value.toUpperCase();
}

function f(o) {

    o.value = o.value.toUpperCase().replace(/([^0-9A-Z])/g, "");

}

function IsValidTime(timeStr) {
    // Checks if time is in HH:MM:SS AM/PM format.
    // The seconds and AM/PM are optional.

    if (timeStr.length == 1)
        return true;

    var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?(\s?(AM|am|PM|pm))?$/;

    var matchArray = timeStr.match(timePat);
    if (matchArray == null) {
        alert("Time is not in a valid format.");
        return false;
    }
    hour = matchArray[1];
    minute = matchArray[2];
    second = matchArray[4];
    ampm = matchArray[6];

    if (second == "") { second = null; }
    if (ampm == "") { ampm = null }

    if (hour < 0 || hour > 23) {
        alert("Hour must be between 1 and 23.");
        return false;
    }
    if (minute < 0 || minute > 59) {
        alert("Minute must be between 0 and 59.");
        return false;
    }
    return true;
}
function trimAll(sString) {
    while (sString.substring(0, 1) == ' ') {
        sString = sString.substring(1, sString.length);
    }
    while (sString.substring(sString.length - 1, sString.length) == ' ') {
        sString = sString.substring(0, sString.length - 1);
    }
    return sString;
}


function Npi_IsLUNH(sText) {
    if (sText != '') {
        var TotalSum = 0;
        var LastNumber = 0;
        var LastNumber = parseInt(sText.charAt(9));
        for (i = 0; i < sText.length - 1; i++) {
            //alert((i+1)%2);
            if ((i + 1) % 2 != 0) {
                if ((parseInt(sText.charAt(i)) * 2) > 9) {
                    TotalSum = TotalSum + Math.floor(((parseInt(sText.charAt(i)) * 2) / 10)) + ((parseInt(sText.charAt(i)) * 2) % 10);
                    //alert(TotalSum);               
                }
                else {
                    TotalSum = TotalSum + (parseInt(sText.charAt(i)) * 2);
                    //alert(TotalSum);           
                }
            }
            else {
                TotalSum = TotalSum + parseInt(sText.charAt(i));
                //alert(TotalSum);             
            }
            //alert(TotalSum);
        }

        TotalSum = TotalSum + 24 //adding US code
        var RoundedSum = (Math.floor((TotalSum / 10)) * 10) + 10;

        if ((RoundedSum - TotalSum) >= 10) {
            RoundedSum = TotalSum;
        }
        if ((RoundedSum - TotalSum) != LastNumber) {
            return false;
        }
        else {
            return true;
        }
    }
    return true;
}
function trim1(sString) {
    var e = sString.length - 1;
    //sString.substring(0, e-1)
    sString = sString.substring(0, e);
    return sString;
}
function validateSpace(e) {
    var KeyID = (window.event) ? event.keyCode : e.which;
    if (KeyID == 46 || KeyID == 32) {
        return false;
    }
    return true;
}

