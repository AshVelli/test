﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using eTailingBAL;
using System.Text;
using System.Diagnostics;
using AjaxControlToolkit;


namespace eTailingWebApp
{
     public partial class ModifyProfile : System.Web.UI.Page
     {
          PasswordEncription pass = new PasswordEncription();
          private int _userSeqId;

          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (appCode == "dataforce")
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;
               }
          }
          protected void Page_Load(object sender, EventArgs e)
          {
               Page.Title = "Update Details";
               Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
               Response.Cache.SetAllowResponseInBrowserHistory(false);
               Response.Cache.SetNoStore();
               _userSeqId = Convert.ToInt32(Request.QueryString["UserSeqId"]);
               try
               {
                    txtUpdateAnswer1.Attributes["type"] = "password";
                    txtUpdateAnswer2.Attributes["type"] = "password";
                    if (!IsPostBack)
                    {
                         //Load Countries
                         DataTable dtCountry = ProTransaction.GetCountryNames().Tables[0];
                         //#also change this       ddlProviderState                                          
                         ddlUpdateCountry.DataSource = dtCountry;
                         ddlUpdateCountry.DataTextField = "country_name";
                         ddlUpdateCountry.DataValueField = "country_code";
                         ddlUpdateCountry.DataBind();
                         ddlUpdateCountry.Items.Insert(0, new ListItem("--Select--", ""));
                         ddlUpdateCCCountry.DataSource = dtCountry;
                         ddlUpdateCCCountry.DataTextField = "country_name"; ;
                         ddlUpdateCCCountry.DataValueField = "country_code";
                         ddlUpdateCCCountry.DataBind();
                         ddlUpdateCCCountry.Items.Insert(0, new ListItem("--Select--", ""));
                         ddlUpdateCCCountry.SelectedIndex = 0;
                         //Load State
                         DataTable dtState = ProTransaction.GetStateNames().Tables[0];
                         ddlUpdateState.DataSource = dtState;
                         ddlUpdateState.DataTextField = "State";
                         ddlUpdateState.DataValueField = "Code";
                         ddlUpdateState.DataBind();
                         ddlUpdateState.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlPUpdateState.DataSource = dtState;
                         DdlPUpdateState.DataTextField = "State";
                         DdlPUpdateState.DataValueField = "Code";
                         DdlPUpdateState.DataBind();
                         DdlPUpdateState.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlPUpdateState.SelectedIndex = 0;

                         //Load Security QA
                         DataSet dsQuestion = ProTransaction.GetQuestions();
                         DdlUpdateQuestion1.DataSource = dsQuestion.Tables[0];
                         DdlUpdateQuestion1.DataTextField = "SecQues";
                         DdlUpdateQuestion1.DataValueField = "SecQuesId";
                         DdlUpdateQuestion1.DataBind();
                         DdlUpdateQuestion1.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlUpdateQuestion2.DataSource = dsQuestion.Tables[1];
                         DdlUpdateQuestion2.DataTextField = "SecQues";
                         DdlUpdateQuestion2.DataValueField = "SecQuesId";
                         DdlUpdateQuestion2.DataBind();
                         DdlUpdateQuestion2.Items.Insert(0, new ListItem("--Select--", ""));

                         //Load Card Expiry Month
                         ddlMonth.Items.Insert(0, new ListItem("--Select Month--", ""));
                         string[] myMonthsL = CultureInfo.CurrentCulture.DateTimeFormat.MonthNames;
                         int inc = 0;
                         foreach (string stmoname in myMonthsL)
                         {
                              inc += 1;
                              if (inc != 13)
                              {
                                   ddlMonth.Items.Insert(inc, new ListItem(stmoname, inc.ToString()));
                              }
                         }
                         ddlMonth.SelectedIndex = 11;

                         //Load Card Expiry Year
                         inc = 0;
                         int intCurYear = (int)DateTime.Now.Year;
                         ddlYear.Items.Insert(0, new ListItem("--Select Year--", ""));
                         for (int inyr = intCurYear; inyr <= intCurYear + 15; inyr++)
                         {
                              inc += 1;
                              ddlYear.Items.Insert(inc, new ListItem(inyr.ToString(), inyr.ToString()));
                         }
                         ddlYear.SelectedIndex = 1;
                         //#bind data to the view#
                         try
                         {
                              //##get mUserSeqId from source page##
                              DataTable dtGetUserInfo = BLL_Login.GetUserInfo(_userSeqId);
                              if (dtGetUserInfo.Rows.Count != 0)
                              {
                                   //bind data to the view
                                   BindDataToView(dtGetUserInfo);
                                   //lblMsg.Text = "You got all the data";
                              }
                              else
                              {
                                   Response.Write("<script>alert('Problem with SP');</script>");
                                   Response.Redirect("LoginHome.aspx", false);
                              }
                         }
                         catch (Exception ex)
                         {
                              StackTrace trace = new StackTrace(ex, true);
                              StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                              Common.InsertErrorLog("PageLoad_GetUserInfo&BindtoVIew_Error: " + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                              Server.Transfer("ErrorPage.aspx");
                         }
                    }
                    System.Text.StringBuilder sbValid = new System.Text.StringBuilder();
                    sbValid.Append("if(ValidateSecurityInfo() == false){return false;}");
                    sbValid.Append("this.value = 'Please wait...';");
                    sbValid.Append("this.disabled = true;");
                    sbValid.Append(this.Page.GetPostBackEventReference(this.btnProviderUpdate));
                    sbValid.Append(";");
                    this.btnProviderUpdate.Attributes.Add("onclick", sbValid.ToString());
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("PageLoad_Error: " + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //lblMsg.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }
          }

          private void BindDataToView(DataTable dtGetUserInfo)
          {
               txtUpdateFirstName.Text = dtGetUserInfo.Rows[0]["FirstName"].ToString();
               txtUpdateMiddleName.Text = dtGetUserInfo.Rows[0]["MiddleName"].ToString();
               txtUpdateLastName.Text = dtGetUserInfo.Rows[0]["LastName"].ToString();
               txtUpdateSuffix.Text = dtGetUserInfo.Rows[0]["Suffix"].ToString();
               txtUpdateEmail.Text = dtGetUserInfo.Rows[0]["EMailID"].ToString();
               if (!string.IsNullOrEmpty(dtGetUserInfo.Rows[0]["CompanyURL"].ToString()))
                    txtUpdateWebSite.Text = pass.Decription(dtGetUserInfo.Rows[0]["CompanyURL"].ToString());
               txtUpdateAdd1.Text = pass.Decription(dtGetUserInfo.Rows[0]["Address1"].ToString());
               txtUpdateAdd2.Text = pass.Decription(dtGetUserInfo.Rows[0]["Address2"].ToString());
               txtUpdatecity.Text = pass.Decription(dtGetUserInfo.Rows[0]["City"].ToString());
               ddlUpdateState.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["State"].ToString());
               ddlUpdateCountry.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["County"].ToString());
               txtUpdateZip.Text = pass.Decription(dtGetUserInfo.Rows[0]["Zip"].ToString());
               txtUpdatePhone.Text = pass.Decription(dtGetUserInfo.Rows[0]["Phone"].ToString());
               txtUpdatePhoneExtn.Text = pass.Decription(dtGetUserInfo.Rows[0]["PhoneExtn"].ToString());
               txtUpdateMobile.Text = pass.Decription(dtGetUserInfo.Rows[0]["Mobile"].ToString());
               txtUpdateFax.Text = pass.Decription(dtGetUserInfo.Rows[0]["Fax"].ToString());
               DdlUpdateQuestion1.SelectedValue = dtGetUserInfo.Rows[0]["SecQuesId1"].ToString();
               txtUpdateAnswer1.Text = pass.Decription(dtGetUserInfo.Rows[0]["Answer1"].ToString());
               DdlUpdateQuestion2.SelectedValue = dtGetUserInfo.Rows[0]["SecQuesId2"].ToString();
               txtUpdateAnswer2.Text = pass.Decription(dtGetUserInfo.Rows[0]["Answer2"].ToString());
               ddlUpdateCardType.SelectedValue = dtGetUserInfo.Rows[0]["CardType"].ToString();
               txtUpdateHolderName.Text = pass.Decription(dtGetUserInfo.Rows[0]["CardHolderName"].ToString());
               //#
               //string CCNumber = pass.Decription(dtGetUserInfo.Rows[0]["CardNumber"].ToString());
               //string maskedCCNumber = CCNumber.Substring(CCNumber.Length - 4).PadLeft(CCNumber.Length, '*');
               //txtUpdateCCNumber.Text = maskedCCNumber;
               //#
               txtUpdateCCNumber.Text = pass.Decription(dtGetUserInfo.Rows[0]["CardNumber"].ToString());
               DateTime expiryDate = Convert.ToDateTime(pass.Decription(dtGetUserInfo.Rows[0]["EXPIRYDate"].ToString()));
               ddlMonth.SelectedValue = expiryDate.Month.ToString();
               ddlYear.SelectedValue = expiryDate.Year.ToString();
               TxtPUpdateAddress1.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayAddress1"].ToString());
               TxtPUpdateAddress2.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayAddress2"].ToString());
               TxtPUpdateCity.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayCity"].ToString());
               DdlPUpdateState.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["PayState"].ToString());
               ddlUpdateCCCountry.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["PayCountry"].ToString());
               TxtPUpdateZip.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayZip"].ToString());
               if (IsUserCCAddressSame(dtGetUserInfo))
               {
                    ChkFill.Checked = true;
               }
          }

          private bool IsUserCCAddressSame(DataTable dtGetUserInfo)
          {
               bool isSame = false;
               txtUpdateAdd1.Text = pass.Decription(dtGetUserInfo.Rows[0]["Address1"].ToString());
               txtUpdateAdd2.Text = pass.Decription(dtGetUserInfo.Rows[0]["Address2"].ToString());
               txtUpdatecity.Text = pass.Decription(dtGetUserInfo.Rows[0]["City"].ToString());
               ddlUpdateState.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["State"].ToString());
               string temp = pass.Decription(dtGetUserInfo.Rows[0]["County"].ToString());
               ddlUpdateCountry.Text = temp;
               ddlUpdateCountry.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["County"].ToString());
               txtUpdateZip.Text = pass.Decription(dtGetUserInfo.Rows[0]["Zip"].ToString());
               TxtPUpdateAddress1.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayAddress1"].ToString());
               TxtPUpdateAddress2.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayAddress2"].ToString());
               TxtPUpdateCity.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayCity"].ToString());
               DdlPUpdateState.SelectedValue = pass.Decription(dtGetUserInfo.Rows[0]["PayState"].ToString());
               ddlUpdateCCCountry.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayCountry"].ToString());
               TxtPUpdateZip.Text = pass.Decription(dtGetUserInfo.Rows[0]["PayZip"].ToString());
               if (txtUpdateAdd1.Text == TxtPUpdateAddress1.Text && txtUpdateAdd2.Text == TxtPUpdateAddress2.Text && txtUpdatecity.Text == TxtPUpdateCity.Text && ddlUpdateState.SelectedValue == DdlPUpdateState.SelectedValue && ddlUpdateCCCountry.Text == ddlUpdateCountry.Text && txtUpdateZip.Text == TxtPUpdateZip.Text)
               {
                    isSame = true;
               }
               return isSame;
          }

          public void CaptchaRefresh()
          {
               Session["Code"] = null;
               Random ran = new Random();
               myImage.ImageUrl = "~/CaptchaControl.aspx?Id=" + ran.Next(1, 9).ToString();
          }

          protected void ImgRefresh_OnClick(object sender, ImageClickEventArgs e)
          {
               try
               {
                    CaptchaRefresh();
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CaptchaRefresh_Error: " + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void btnProviderUpdate_OnClick(object sender, EventArgs e)
          {
               try
               {
                    //verify captcha  
                    if (!VerifyCaptchaCode(txtUpdateVerificationCode.Text))
                    {
                         lblTDText.Text = "You typed incorrect verification code, Please try again.";
                         //btnProviderSave.Enabled = true;
                         return;
                    }
                    else if (VerifyCaptchaCode(txtUpdateVerificationCode.Text))
                    {
                         lblTDText.Text = "";
                         lblTDText.Visible = false;
                         PasswordEncription PassDesc = new PasswordEncription();
                         ProTransaction userInfo = new ProTransaction();
                         userInfo.UserSeqID = _userSeqId;
                         userInfo.FirstName = txtUpdateFirstName.Text;
                         userInfo.LastName = txtUpdateLastName.Text;
                         userInfo.MiddleName = txtUpdateMiddleName.Text;
                         userInfo.EMailID = txtUpdateEmail.Text;
                         userInfo.CompanyURL = txtUpdateWebSite.Text;
                         userInfo.Suffix = txtUpdateSuffix.Text;
                         userInfo.Address1 = PassDesc.Encription(txtUpdateAdd1.Text);
                         userInfo.Address2 = PassDesc.Encription(txtUpdateAdd2.Text);
                         userInfo.City = PassDesc.Encription(txtUpdatecity.Text);
                         userInfo.state = PassDesc.Encription(ddlUpdateState.SelectedValue);
                         userInfo.Country = PassDesc.Encription(ddlUpdateCountry.Text);
                         userInfo.Zip = PassDesc.Encription(txtUpdateZip.Text);
                         userInfo.Phone = PassDesc.Encription(txtUpdatePhone.Text);
                         userInfo.PhoneExtn = PassDesc.Encription(txtUpdatePhoneExtn.Text);
                         userInfo.Mobile = PassDesc.Encription(txtUpdateMobile.Text);
                         userInfo.Fax = PassDesc.Encription(txtUpdateFax.Text);
                         userInfo.SecQuesId1 = DdlUpdateQuestion1.SelectedValue;
                         userInfo.Answer1 = PassDesc.Encription(txtUpdateAnswer1.Text.Trim());
                         userInfo.SecQuesId2 = DdlUpdateQuestion2.SelectedValue;
                         userInfo.Answer2 = PassDesc.Encription(txtUpdateAnswer2.Text.Trim());
                         userInfo.CardType = ddlUpdateCardType.SelectedValue;
                         userInfo.CardHolderName = PassDesc.Encription(txtUpdateHolderName.Text);
                         userInfo.CardNumber = PassDesc.Encription(txtUpdateCCNumber.Text);
                         string strCardExpiryDate = ddlMonth.SelectedValue + "/" + ddlYear.SelectedValue;
                         //userInfo.CardCVV = PassDesc.Encription(txtUpdateCVVNumber.Text);
                         userInfo.EXPIRYDate = PassDesc.Encription(strCardExpiryDate);
                         userInfo.PayAddress1 = PassDesc.Encription(TxtPUpdateAddress1.Text);
                         userInfo.PayAddress2 = PassDesc.Encription(TxtPUpdateAddress2.Text);
                         userInfo.PayCity = PassDesc.Encription(TxtPUpdateCity.Text);
                         userInfo.PayCountry = PassDesc.Encription(ddlUpdateCCCountry.Text);
                         userInfo.PayZip = PassDesc.Encription(TxtPUpdateZip.Text);
                         userInfo.Paystate = PassDesc.Encription(DdlPUpdateState.SelectedValue);
                         userInfo.UpdateProfile(userInfo);
                         if (CheckIfCcDetailsUpdated(userInfo))
                         {
                              userInfo.UpdateCCInfo(userInfo);
                         }
                         BLL_Login.SetFlagInSessionLog(_userSeqId, 0);
                         Response.Redirect("LoginHome.aspx", false);
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("UpdateClick_Error: " + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          private bool VerifyCaptchaCode(string userVerificationCode)
          {
               bool isCaptchVerified = false;
               string getCaptchCode = Session["Code"].ToString();
               if (userVerificationCode == getCaptchCode)
               {
                    isCaptchVerified = true;
               }
               else
               {
                    txtUpdateVerificationCode.Text = string.Empty;
                    isCaptchVerified = false;
               }
               return isCaptchVerified;
          }

          private bool CheckIfCcDetailsUpdated(ProTransaction userInfo)
          {
               try
               {     
                    DataTable dtGetUserInfo = BLL_Login.GetUserInfo(_userSeqId);
                    if (userInfo.CardType != dtGetUserInfo.Rows[0].ItemArray[20].ToString())
                    {
                         return true;
                    }
                    if (userInfo.CardHolderName != dtGetUserInfo.Rows[0].ItemArray[21].ToString())
                    {
                         return true;
                    }
                    if (userInfo.CardNumber != dtGetUserInfo.Rows[0].ItemArray[22].ToString())
                    {
                         return true;
                    }
                    DateTime expiryDate = Convert.ToDateTime(pass.Decription(dtGetUserInfo.Rows[0]["ExpiryDate"].ToString()));
                    string oldExpiryDate = pass.Encription(expiryDate.Month.ToString() + "/" + expiryDate.Year.ToString());
                    if (userInfo.EXPIRYDate != oldExpiryDate)
                    {
                         return true;
                    }
                    //if (userInfo.CardCVV != dtGetUserInfo.Rows[0].ItemArray[24].ToString())
                    //{
                    //     return true;
                    //}
                    if (userInfo.PayAddress1 != dtGetUserInfo.Rows[0].ItemArray[24].ToString())
                    {
                         return true;
                    }
                    if (userInfo.PayAddress2 != dtGetUserInfo.Rows[0].ItemArray[25].ToString())
                    {
                         return true;
                    }
                    if (userInfo.PayCity != dtGetUserInfo.Rows[0].ItemArray[26].ToString())
                    {
                         return true;
                    }
                    if (userInfo.Paystate != dtGetUserInfo.Rows[0].ItemArray[27].ToString())
                    {
                         return true;
                    }
                    if (userInfo.PayCountry != dtGetUserInfo.Rows[0].ItemArray[28].ToString())
                    {
                         return true;
                    }
                    if (userInfo.PayZip != dtGetUserInfo.Rows[0].ItemArray[29].ToString())
                    {
                         return true;
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Error" + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
               return false;
          }

          protected void btnUpdateLogout_OnClick(object sender, EventArgs e)
          {
               Response.Redirect("Logout.aspx");
          }

          protected void btnBack_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("LoginHome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackClick_Error: " + ex.Message, "ModifyProfile.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }
     }
}