﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using eTailingBAL;
using System.Diagnostics;
using System.Text.RegularExpressions;


namespace eTailingWebApp
{
     public partial class ForgotPassword : System.Web.UI.Page
     {
          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (appCode == "dataforce")
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;

               }
          }
          protected void Page_Load(object sender, EventArgs e)
          {
               /* To disable storing pages in cache*/
               Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
               Response.Cache.SetAllowResponseInBrowserHistory(false);
               Response.Cache.SetNoStore();
               try
               {
                    lblMsgStep2.Text = " ";
                    if (!IsPostBack)
                    {
                         PageLoadSettings();
                         Session["Url"] = Request.Url.ToString().Substring(0, Convert.ToInt32(Request.Url.ToString().LastIndexOf('/')));
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);                
                    //splitStackTrace(stackFrame.ToString());
                    Common.InsertErrorLog("PageLoad_Error: " + ex.Message, "ForgetPassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          //void splitStackTrace(string fileName)
          //{
          //     Regex r = new Regex(@"Page_Load at (?<namespace>.*)\.(?<class>.*)\.(?<method>.*(.*)) in (?<file>.*):line (?<line>\d*)");
          //     var result = r.Match(@"fileName");
          //     if (result.Success)
          //     {
          //          string _namespace = result.Groups["namespace"].Value.ToString();
          //          string _class = result.Groups["class"].Value.ToString();
          //          string _method = result.Groups["method"].Value.ToString();
          //          string _file = result.Groups["file"].Value.ToString();
          //          string _line = result.Groups["line"].Value.ToString();
          //          Console.WriteLine("namespace: " + _namespace);
          //          Console.WriteLine("class: " + _class);
          //          Console.WriteLine("method: " + _method);
          //          Console.WriteLine("file: " + _file);
          //          Console.WriteLine("line: " + _line);
          //     }
          //}

          private void PageLoadSettings()
          {
               mvwForgotPwd.ActiveViewIndex = 0;
               TxtUserName.Enabled = true;
          }

          protected void btn_SubmitStep1_Click(object sender, CommandEventArgs e)
          {
               try
               {
                    string UserName = TxtUserName.Text.Trim();
                    if (e.CommandName == "Step1")
                    {
                         DataTable dtChkUserexists = ProTransaction.CheckUserInfo(UserName, "", "C");
                         if (dtChkUserexists == null)
                         {
                              lblMsgStep2.Text = "Username does not exist.";
                              return;
                         }
                         else if (dtChkUserexists.Rows.Count == 0)
                         {
                              lblMsgStep2.Text = "Username does not exist.";
                              return;
                         }
                         else
                         {
                              DataTable dtLoadSecQ = ProTransaction.GetUserSecQuest(UserName);
                              if (dtLoadSecQ != null)
                              {
                                   if (dtLoadSecQ.Rows.Count > 0)
                                   {
                                        ddlsecquestion.DataSource = dtLoadSecQ;
                                        ddlsecquestion.DataTextField = "Question";
                                        ddlsecquestion.DataValueField = "Qid";
                                        ddlsecquestion.DataBind();
                                        ddlsecquestion.Items.Insert(0, new ListItem("--Select--", ""));
                                        TxtUserName.Enabled = false;
                                        mvwForgotPwd.ActiveViewIndex = 1;
                                   }
                                   else
                                   {
                                        lblMsgStep2.Text = "Security questions do not exist. Please contact administrator.";
                                   }
                              }
                         }
                    }
                    else if (e.CommandName == "Step2")
                    {
                         string SecureAns = GlobalVal.GetDecryptValue(txtSecAns1.Text.TrimStart().TrimEnd());
                         DataTable dtChkUserSecurity = ProTransaction.CheckUserSecurity(UserName, SecureAns, ddlsecquestion.SelectedValue, "", "", "");
                         if (dtChkUserSecurity == null)
                         {
                              lblMsgStep2.Text = "Invalid Security Answer";
                         }
                         else if (dtChkUserSecurity.Rows.Count == 0)
                         {
                              lblMsgStep2.Text = "Invalid Security Answer";
                         }
                         else if (dtChkUserSecurity.Rows.Count > 0)
                         {
                              PasswordEncription objPassDec = new PasswordEncription();
                              string Email = dtChkUserSecurity.Rows[0]["EMailID"].ToString();
                              string Password = objPassDec.Decription(dtChkUserSecurity.Rows[0]["Password"].ToString());
                              string UserSeqID = Convert.ToString(dtChkUserSecurity.Rows[0]["UserSeqID"]);
                              int intMailStatus = SendMail.ForgetPasswordMail(Email, UserSeqID, Password, UserName);
                              if (intMailStatus != 1)
                              {
                                   lblMsgStep2.Text = "Your password information will be sent to the email address specified in your profile.";
                                   TxtUserName.Text = "";
                                   //mvwForgotPwd.ActiveViewIndex = 2;
                                   ClearForm();
                              }
                         }
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("SubmitClick_Error: " + ex.Message, "ForgetPassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          public void ClearForm()
          {
               txtSecAns1.Text = "";
               ddlsecquestion.SelectedIndex = 0;    
          }

          protected void btnBack1_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("Loginhome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackClick1_Error: " + ex.Message, "ForgetPassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void btnBack2_Click(object sender, EventArgs e)
          {
               try
               {
                    PageLoadSettings();
                    ClearForm();
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackClick2_Error: " + ex.Message, "ForgetPassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }

          protected void hlLogin_Click(object sender, EventArgs e)
          {
               try
               {
                    Session.Abandon();
                    Session["Start"] = null;
                    HttpContext.Current.Cache.Remove(TxtUserName.Text);
                    Response.Redirect("~/LoginHome.aspx", false);
               }

               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("LoginHyperlinkClick_Error: " + ex.Message, "ChangePassword.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
               }
          }
     }
}