﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Globalization;
using System.IO;           
using System.Text;
using System.Diagnostics;
using eTailingBAL;

namespace eTailingWebApp
{
     public partial class ProviderRegistration : System.Web.UI.Page
     {
          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (!string.IsNullOrEmpty(appCode))
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;
               }
          }

          protected void Page_Load(object sender, EventArgs e)
          {
               /* To disable storing pages in cache*/
               Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
               Response.Cache.SetAllowResponseInBrowserHistory(false);
               Response.Cache.SetNoStore();
               try
               {
                    if (!IsPostBack)
                    {
                         PageLoadSettings();
                         //Load Countries
                         DataTable dtCountry = ProTransaction.GetCountryNames().Tables[0];        
                         ddlCountriesList.DataSource = dtCountry;
                         ddlCountriesList.DataTextField = "country_name";
                         ddlCountriesList.DataValueField = "country_code";
                         ddlCountriesList.DataBind();
                         ddlCountriesList.Items.Insert(0, new ListItem("--Select--", ""));
                         ddlCCCountry.DataSource = dtCountry;
                         ddlCCCountry.DataTextField = "country_name"; ;
                         ddlCCCountry.DataValueField = "country_code";
                         ddlCCCountry.DataBind();
                         ddlCCCountry.Items.Insert(0, new ListItem("--Select--", ""));
                         ddlCCCountry.SelectedIndex = 0;
                         //Load State
                         DataTable dtState = ProTransaction.GetStateNames().Tables[0];
                         ddlProviderState.DataSource = dtState;
                         ddlProviderState.DataTextField = "State";
                         ddlProviderState.DataValueField = "Code";
                         ddlProviderState.DataBind();
                         ddlProviderState.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlPState.DataSource = dtState;
                         DdlPState.DataTextField = "State";
                         DdlPState.DataValueField = "Code";
                         DdlPState.DataBind();
                         DdlPState.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlPState.SelectedIndex = 0;
                         //Load Security QA
                         DataSet dsQuestion = ProTransaction.GetQuestions();
                         DdlQuestion1.DataSource = dsQuestion.Tables[0];
                         DdlQuestion1.DataTextField = "SecQues";
                         DdlQuestion1.DataValueField = "SecQuesId";
                         DdlQuestion1.DataBind();
                         DdlQuestion1.Items.Insert(0, new ListItem("--Select--", ""));
                         DdlQuestion2.DataSource = dsQuestion.Tables[1];
                         DdlQuestion2.DataTextField = "SecQues";
                         DdlQuestion2.DataValueField = "SecQuesId";
                         DdlQuestion2.DataBind();
                         DdlQuestion2.Items.Insert(0, new ListItem("--Select--", ""));
                         //Load Card Expiry Month
                         ddlMonth.Items.Insert(0, new ListItem("--Select Month--", ""));
                         string[] myMonthsL = CultureInfo.CurrentCulture.DateTimeFormat.MonthNames;
                         int inc = 0;
                         foreach (string stmoname in myMonthsL)
                         {
                              inc += 1;
                              if (inc != 13)
                              {
                                   ddlMonth.Items.Insert(inc, new ListItem(stmoname, inc.ToString()));
                              }
                         }
                         ddlMonth.SelectedIndex = 11;
                         //Load Card Expiry Year
                         inc = 0;
                         int intCurYear = (int)DateTime.Now.Year;
                         ddlYear.Items.Insert(0, new ListItem("--Select Year--", ""));
                         for (int inyr = intCurYear; inyr <= intCurYear + 15; inyr++)
                         {
                              inc += 1;
                              ddlYear.Items.Insert(inc, new ListItem(inyr.ToString(), inyr.ToString()));
                         }
                         ddlYear.SelectedIndex = 1;
                    }
                    System.Text.StringBuilder sbValid = new System.Text.StringBuilder();
                    sbValid.Append("if(ValidateSecurityInfo() == false){return false;}");
                    sbValid.Append("this.value = 'Please wait...';");
                    sbValid.Append("this.disabled = true;");
                    sbValid.Append(this.Page.GetPostBackEventReference(this.btnProviderSave));
                    sbValid.Append(";");
                    this.btnProviderSave.Attributes.Add("onclick", sbValid.ToString());  
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("PageLoad_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");                                                                                       
               }
          }

          protected void PageLoadSettings()
          {
               //imgavl.Visible = false;
               //imgntavl.Visible = false;
               lblTDText.Text = "";
          }

          protected void btnProviderSave_Click(object sender, EventArgs e)
          {
               string emailid = txtProviderEmail.Text;
               string UserLoginName = txtProviderUserName.Text.ToString();
               try
               {
                    //verify captcha  
                    if (!VerifyCaptchaCode(txtVerificationCode.Text))
                    {
                         lblTDText.Text = "You typed incorrect verification code, Please try again.";      
                         return;
                    }
                    if (ProTransaction.CheckPrvAvailability(UserLoginName))
                    {
                         lblTDText.Text = "Username already in use. Please choose different Username.";
                         return;
                    }
                    if (ProTransaction.CheckEmailAvailability(emailid))
                    {
                         lblTDText.Text = "EmailId is already present.Please give different EmailId";
                         return;
                    }
                    else
                    {
                         PasswordEncription PassDesc = new PasswordEncription();
                         ProTransaction PUM = new ProTransaction();
                         string strpassword = RandomPassword.Generate(8, 10);
                         PUM.Password = PassDesc.Encription(strpassword);
                         PUM.prdActiveStatus = 1;
                         PUM.UserLoginID = UserLoginName;
                         PUM.LastName = txtProviderLastName.Text.ToString();
                         PUM.FirstName = txtProviderFirstName.Text.ToString();
                         PUM.MiddleName = txtProviderMiddleName.Text.ToString();
                         PUM.Suffix = txtProviderSuffix.Text.ToString();
                         PUM.Address1 = PassDesc.Encription(txtProviderAdd1.Text.ToString());
                         PUM.Address2 = PassDesc.Encription(txtProviderAdd2.Text.ToString());
                         PUM.City = PassDesc.Encription(txtProvidercity.Text.ToString());
                         PUM.state = PassDesc.Encription(ddlProviderState.Text.ToString());
                         PUM.Country = PassDesc.Encription(ddlCountriesList.Text.ToString());
                         PUM.Zip = PassDesc.Encription(txtProviderZip.Text.ToString());
                         PUM.Phone = PassDesc.Encription(txtProviderPhone.Text.ToString());
                         PUM.PhoneExtn = PassDesc.Encription(txtProviderPhoneExtn.Text.ToString());
                         PUM.EMailID = txtProviderEmail.Text.ToString();
                         PUM.Fax = PassDesc.Encription(txtProviderFax.Text.ToString());
                         PUM.Mobile = PassDesc.Encription(txtProviderMobile.Text.ToString());
                         if (!string.IsNullOrEmpty(txtproviderWebSite.Text))
                              PUM.CompanyURL = PassDesc.Encription(txtproviderWebSite.Text);
                         PUM.CardorCheck = "CC";
                         PUM.CardType = ddlCardType.SelectedValue.ToString();
                         PUM.CardHolderName = PassDesc.Encription(txtProviderHolderName.Text.ToString());
                         PUM.CardNumber = PassDesc.Encription(txtProviderCCNumber.Text.ToString());
                         string strCardExpiryDate = ddlMonth.SelectedValue.ToString() + "/" + ddlYear.SelectedValue.ToString();
                         //CVV shouldnot be stored in DB
                         PUM.CardCVV = PassDesc.Encription(txtCVVNumber.Text);
                         PUM.EXPIRYDate = PassDesc.Encription(strCardExpiryDate);
                         PUM.PayAddress1 = PassDesc.Encription(TxtPAddress1.Text.ToString());

                         PUM.PayAddress2 = PassDesc.Encription(TxtPAddress2.Text.ToString());
                         PUM.PayCity = PassDesc.Encription(TxtPCity.Text.ToString());
                         PUM.PayCountry = PassDesc.Encription(ddlCCCountry.Text.ToString());
                         PUM.PayZip = PassDesc.Encription(TxtPZip.Text.ToString());
                         PUM.Paystate = PassDesc.Encription(DdlPState.SelectedValue.ToString());

                         PUM.SecQuesId1 = DdlQuestion1.SelectedValue;
                         PUM.Answer1 = PassDesc.Encription(txtAnswer1.Text.Trim());
                         PUM.SecQuesId2 = DdlQuestion2.SelectedValue;
                         PUM.Answer2 = PassDesc.Encription(txtAnswer2.Text.Trim());
                         string[] providersqlID = ProTransaction.RegProviderInfo(PUM);
                         if (providersqlID[1].ToString() != "0")
                         {
                              SendMail.ProviderRegistrationDetails(providersqlID[1].ToString());
                              lblTDText.Text = "The user is registered successfully and login details has been sent to the registered e-mail Id";
                              Response.Redirect("LoginHome.aspx", false);
                         }
                         else
                         {
                              lblTDText.Text = "Your Registration is not completed, Please contact Support Team";
                         }
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("RegisterClick_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");                   
               }
          }

          private bool VerifyCaptchaCode(string userVerificationCode)
          {
               bool isCaptchVerified = false;
               string getCaptchCode = Session["Code"].ToString();
               if (userVerificationCode == getCaptchCode)
               {
                    isCaptchVerified = true;
               }
               else
               {
                    txtVerificationCode.Text = string.Empty;
                    isCaptchVerified = false;
               }
               return isCaptchVerified;
          }

          protected void BtnCheckAvailability_Click(object sender, EventArgs e)
          {
               try
               {
                    if (txtProviderUserName.Text.ToString() != "")
                    {
                         if (ProTransaction.CheckPrvAvailability(txtProviderUserName.Text.ToString()))
                         {
                              imgavl.Visible = true;
                              imgavl.ImageUrl = "~/Images/Gra_Cross_new.png";
                         }
                         else
                         {
                              imgavl.ImageUrl = "~/Images/Gra_Tick_new.png";
                              imgavl.Visible = true;
                         }
                    }
                    else
                    {
                         imgavl.ImageUrl = "";
                         imgavl.Visible = true;
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CheckUserAvailability_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");             
               }
          }

          protected void Btnclose_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("~/LoginHome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CloseButton_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");           
               }
          }

          protected void ImgRefresh_Click(object sender, ImageClickEventArgs e)
          {
               CaptchaRefresh();
          }

          public void CaptchaRefresh()
          {
               try
               {
                    Session["Code"] = String.Empty;
                    Random ran = new Random();
                    myImage.ImageUrl = "~/CaptchaControl.aspx?Id=" + ran.Next(1, 9).ToString();
                    //myImage = imgCaptch;
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CaptchaRefresh_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");                                                                       
               }
          }

          protected void btnBack_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("LoginHome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackClick_Error: " + ex.Message, "ProviderRegistration.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");     
               }
          }        
     }
}