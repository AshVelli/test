﻿using eTailingBAL;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eTailingWebApp
{
     public partial class CaptchaControl : System.Web.UI.Page
     {
          private Random rand = new Random();
          public static string capCode;
          protected void Page_Load(object sender, EventArgs e)
          {
               /* To disable storing pages in cache*/
               Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
               Response.Cache.SetAllowResponseInBrowserHistory(false);
               Response.Cache.SetNoStore();

               if (!Page.IsPostBack)
               {
                    CreateImage();
               }
          }

          private void CreateImage()
          {
               try
               {
                    string code = GetRandomText();
                    Bitmap bitmap = new Bitmap(100, 20, System.Drawing.Imaging.PixelFormat.Format32bppArgb); //100,20         
                    Graphics g = Graphics.FromImage(bitmap);
                    //Pen pen = new Pen(Color.Yellow);
                    Pen pen = new Pen(Color.Black);
                    Rectangle rect = new Rectangle(0, 0, 200, 50);//200                         
                    //SolidBrush b = new SolidBrush(Color.Ivory);
                    SolidBrush b = new SolidBrush(Color.Black);
                    //SolidBrush blue = new SolidBrush(Color.Brown);
                    SolidBrush blue = new SolidBrush(Color.White);
                    int counter = 0;
                    g.DrawRectangle(pen, rect);
                    g.FillRectangle(b, rect);
                    for (int i = 0; i < code.Length; i++)
                    {
                         g.DrawString(code[i].ToString(), new Font("Verdena", 6 + rand.Next(4, 8)), blue, new PointF(1 + counter, 1));
                         //counter += 20;
                         counter += 10;
                    }
                    DrawRandomLines(g);
                    bitmap.Save(Response.OutputStream, ImageFormat.Gif);
                    g.Dispose();
                    bitmap.Dispose();
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Captcha_Image_Error: " + ex.Message, "CaptchaControl.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //Common.InsertErrorLog("Page_Load : " + ex.Message, "MyProfileProviderSubUser.aspx.cs", "", 0);
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "<script>alert('" + ex.Message.Replace("'", "") + "');</script>", false);
               }
          }


          private void DrawRandomLines(Graphics g)
          {
               SolidBrush green = new SolidBrush(Color.Green);
               //for (int i = 0; i < 20; i++)
               //{
               //    g.DrawLines(new Pen(green, 2), GetRandomPoints());
               //}

          }

          private Point[] GetRandomPoints()
          {
               Point[] points = { new Point(rand.Next(10, 150), rand.Next(10, 150)), new Point(rand.Next(10, 100), rand.Next(10, 100)) };
               return points;
          }

          private string GetRandomText()
          {
               StringBuilder randomText = new StringBuilder();
               if (Session["Code"] == null)
               {
                    string alphabets = "abcdefghijklmnopqrstuvwxyz1234567890";

                    Random r = new Random();
                    for (int j = 0; j <= 5; j++)
                    {

                         randomText.Append(alphabets[r.Next(alphabets.Length)]);
                    }

                    Session["Code"] = randomText.ToString();
               }
               capCode = Session["Code"].ToString();
               return Session["Code"] as String;
          }
     }
}