﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using eTailingBAL;
using System.Diagnostics;

namespace eTailingWebApp
{
     public partial class ForgotUserName : System.Web.UI.Page
     {
          protected void Page_Init(object sender, EventArgs e)
          {
               string appCode = Convert.ToString(Session["ApplicationCode"]);
               if (!string.IsNullOrEmpty(appCode))
               {
                    string cssPath = "~/css/" + appCode + "_styles.css";
                    lnkCSS.Attributes["href"] = cssPath;
               }
          }

          protected void Page_Load(object sender, EventArgs e)
          {
               try
               {
                    /* To disable storing pages in cache*/
                    Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache);
                    Response.Cache.SetAllowResponseInBrowserHistory(false);
                    Response.Cache.SetNoStore();


                    if (!IsPostBack)
                    {
                         lblMsgSteps.Text = "";
                         mvwForgotPwd.ActiveViewIndex = 0;
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("PageLoad_Error: " + ex.Message, "ForgetUserName.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //string strErrorId = string.Empty;
                    //strErrorId = Common.InsertErrorLog(ex.Message, "ForgetUserName.aspx.cs", "", 0, "Page_Load");
                    //lblMsgSteps.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }
          }

          protected void btnBack_Click(object sender, EventArgs e)
          {
               try
               {
                    mvwForgotPwd.ActiveViewIndex = 0;
                    lblMsgSteps.Text = "";

               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("BackClick_Error: " + ex.Message, "ForgetUserName.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //string strErrorId = string.Empty;
                    //strErrorId = Common.InsertErrorLog(ex.Message, "ForgetUserName.aspx.cs", "", 0, "btnBack_Click");
                    //lblMsgSteps.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }
          }

          protected void btn_Submit_Click(object sender, CommandEventArgs e)
          {
               try
               {
                    string Email = string.Empty;
                    string Mobile = string.Empty;
                    if (e.CommandName == "Step1")
                    {

                         Email = TxtUserEmail.Text.Trim();
                         Mobile = GlobalVal.GetDecryptValue(TxtMobileNumber.Text.Trim());
                         DataTable dt = ProTransaction.CheckEmailInfo(Email, Mobile);
                         if (dt.Rows.Count == 0)
                         {
                              lblMsgSteps.Text = "Email or Mobile Number does not exists";
                         }
                         else
                         {
                              DataTable dtq = ProTransaction.GetUserSecQuestForEmailMobile(Email, Mobile);
                              if (dtq.Rows.Count != 0)
                              {
                                   lblMsgSteps.Text = "";
                                   mvwForgotPwd.ActiveViewIndex = 1;
                                   ddlsecquestion.DataSource = dtq;
                                   ddlsecquestion.DataTextField = "Question";
                                   ddlsecquestion.DataValueField = "Qid";
                                   ddlsecquestion.DataBind();
                                   ddlsecquestion.Items.Insert(0, new ListItem("--Select--", ""));
                              }
                              else
                              {
                                   lblMsgSteps.Text = "Security questions does not exist. Please contact administrator";
                              }
                         }
                    }
                    else if (e.CommandName == "Step2")
                    {
                         if (Session["Code"].ToString() == txtVerCode.Text.Trim())
                         {
                              Email = TxtUserEmail.Text.Trim();
                              Mobile = GlobalVal.GetDecryptValue(TxtMobileNumber.Text.Trim());
                              string SecureAns = GlobalVal.GetDecryptValue(txtSecAns1.Text.Trim());
                              DataTable dt = ProTransaction.CheckUserSecurity("", SecureAns, ddlsecquestion.SelectedValue, Email, Mobile, "forgotuser");
                              if (dt.Rows.Count == 0)
                              {
                                   lblMsgSteps.Text = "Invalid Security Answers";
                              }
                              else
                              {
                                   PasswordEncription objPassDec = new PasswordEncription();
                                   Email = dt.Rows[0]["EmailID"].ToString();
                                   string Password = objPassDec.Decription(dt.Rows[0]["Password"].ToString());
                                   string UserSeqID = Convert.ToString(dt.Rows[0]["UserSeqID"]);
                                   string UserCode = Convert.ToString(dt.Rows[0]["UserCode"]);
                                   string UserName = Convert.ToString(dt.Rows[0]["UserLoginID"]);
                                   int intMailStatus = SendMail.ForgetPasswordMail(Email, UserSeqID, Password, UserName);
                                   if (intMailStatus != 1)
                                   {
                                        lblMsgSteps.Text = "Your LoginID has been sent to your registered E-Mail Id";
                                        //mvwForgotPwd.ActiveViewIndex = 2;
                                        ClearForm();
                                   }
                              }
                         }
                         else
                         {
                              txtVerCode.Text = "";
                              CaptchaRefresh();
                              lblMsgSteps.Text = "Please enter the verification code correctly.";
                         }
                    }
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("SubmitClick_Error: " + ex.Message, "ForgetUserName.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //string strErrorId = string.Empty;
                    //strErrorId = Common.InsertErrorLog(ex.Message, "ForgetUserName.aspx.cs", "", 0, "btn_Submit_Click");
                    //lblMsgSteps.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }

          }

          public void ClearForm()
          {
               txtSecAns1.Text = String.Empty;
               ddlsecquestion.SelectedIndex = 0;
               txtVerCode.Text = "";
          }

          protected void ImgRefresh_Click(object sender, ImageClickEventArgs e)
          {
               try
               {
                    CaptchaRefresh();
                    mvwForgotPwd.ActiveViewIndex = 1;
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("CaptchaRefresh_Error: " + ex.Message, "ForgetUserName.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //string strErrorId = string.Empty;
                    //strErrorId = Common.InsertErrorLog(ex.Message, "ForgetUserName.aspx.cs", "", 0, "ImgRefresh_Click");
                    //lblMsgSteps.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }

          }

          private void CaptchaRefresh()
          {
               Session["Code"] = null;
               Random ran = new Random();
               myImage.ImageUrl = "~/CaptchaControl.aspx?Id=" + ran.Next(1, 9).ToString();
          }

          protected void btnBack1_Click(object sender, EventArgs e)
          {
               try
               {
                    Response.Redirect("LoginHome.aspx", false);
               }
               catch (Exception ex)
               {
                    StackTrace trace = new StackTrace(ex, true);
                    StackFrame stackFrame = trace.GetFrame(trace.FrameCount - 1);
                    Common.InsertErrorLog("Back1Click_Error: " + ex.Message, "ForgetUserName.aspx.cs", stackFrame.GetMethod().Name);
                    Server.Transfer("ErrorPage.aspx");
                    //string strErrorId = string.Empty;
                    //strErrorId = Common.InsertErrorLog(ex.Message, "ForgetUserName.aspx.cs", "", 0, "btnBack1_Click");
                    //lblMsgSteps.Text = "Error Code: " + strErrorId + ". Please try after sometime";
               }
          }
     }
}