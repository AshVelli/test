You have downloaded the ASP.NET AJAX Control Toolkit v15.1.3 nuget package.

To learn more about this release, please read this post:
https://community.devexpress.com/blogs/aspnet/archive/2015/05/21/asp-net-ajax-control-toolkit-v15-1-2-nuget-bug-fixes-and-more.aspx


Getting Started
---------------
Please see https://www.devexpress.com/go/AjaxControlToolkit_Nuget_TextFile_CodePlex.aspx for more information on using AjaxControlToolkit.


Upgrading from earlier version
------------------------------
Please see https://ajaxcontroltoolkit.codeplex.com/wikipage?title=Upgrade%20your%20project%20to%20AjaxControlToolkit%20v15.1 for more information on how to
upgrade to version 15.1


Maintained by DevExpress
------------------------

The ASP.NET AJAX Control Toolkit is now maintained by DevExpress.

Visit http://devexpress.com/ms-act for more information.
