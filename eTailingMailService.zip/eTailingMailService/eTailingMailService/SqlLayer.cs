﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace eTailingMailService
{
     class SqlLayer
     {
          private static readonly string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["eTailingMailService_Connection"]);

          public static void InsLogInfo(String StrDesc, String StrModule, string FunctionName, String StrHTN, int intErrID, int statuscode)
          {
               LogFile.WriteLog(StrDesc);
               Console.WriteLine(GlobalVal.strApplicationName + ": " + StrDesc);

               if (intErrID == 1)
               {
                    LogFile.ErrorLog(StrDesc);
                    SqlLayer.Insert(StrDesc, StrModule, FunctionName, StrHTN, intErrID, statuscode);
               }

          }

          public static bool Insert(string Description, string Module, string FunctionName, string StrHTN, int ErrID, int statuscode)
          {
               bool result = false;

               try
               {
                    using (var cn = new SqlConnection(ConnectionString))
                    {
                         cn.Open();
                         using (var cmd = new SqlCommand("ET_SP_AppErrLog", cn))
                         {
                              cmd.CommandType = CommandType.StoredProcedure;
                              cmd.Parameters.Add("@ApplicationName", SqlDbType.VarChar, 100).Value = GlobalVal.strApplicationName;
                              cmd.Parameters.Add("@ProcessInfo", SqlDbType.VarChar, 100).Value = Module;
                              cmd.Parameters.Add("@ExceptionDetail", SqlDbType.VarChar, -1).Value = Description;
                              cmd.Parameters.Add("@HTN", SqlDbType.VarChar, 30).Value = StrHTN;
                              cmd.Parameters.Add("@StatusSeqId", SqlDbType.Int).Value = statuscode;
                              cmd.Parameters.Add("@FunctionName", SqlDbType.VarChar, 20).Value = FunctionName;
                              cmd.ExecuteNonQuery();
                         }
                    }
                    result = true;
               }
               catch (Exception ex)
               {
                    InsLogInfo(ex.Message, GlobalVal.strApplicationName, "Insert", "", 0, 0);
               }
               return result;
          }

          public static DataSet GetMailContent(int maximumNumberOfRecordsToBeProcessed, int noOfAttemptsOnError)
          {
               DataSet dsMailContent = null;
               try
               {
                    using (var cn = new SqlConnection(ConnectionString))
                    {
                         cn.Open();
                         using (var cmd = new SqlCommand("ET_SP_GetMailContent", cn))
                         {
                              cmd.CommandType = CommandType.StoredProcedure;
                              cmd.Parameters.Add("@MaximumNumberOfRecordsToBeProcessed", SqlDbType.Int).Value = maximumNumberOfRecordsToBeProcessed;
                              cmd.Parameters.Add("@NoOfAttemptsOnError", SqlDbType.Int).Value = noOfAttemptsOnError;
                              using (var da = new SqlDataAdapter(cmd))
                              {
                                   dsMailContent = new DataSet();
                                   da.Fill(dsMailContent);
                              }
                              if (dsMailContent.Tables.Count > 0 && dsMailContent.Tables[0].Rows.Count == 0)
                                   dsMailContent = null;
                         }
                    }
               }
               catch (Exception ex)
               {
                    InsLogInfo(ex.Message, GlobalVal.strApplicationName, "GetMailContent();", "", 0, 0);
               }
               return dsMailContent;
          }

          public static void InsertEmailLog(int logId,string status, string description)
          {
               try
               {
                    using (var cn = new SqlConnection(ConnectionString))
                    {
                         cn.Open();
                         using (var cmd = new SqlCommand("ET_SP_LogMailSentStatus", cn))
                         {
                              cmd.CommandType = CommandType.StoredProcedure;
                              cmd.Parameters.Add("@LogId", SqlDbType.BigInt).Value = logId;
                              cmd.Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = status;
                              cmd.Parameters.Add("@Description", SqlDbType.VarChar, 250).Value = description;
                              cmd.ExecuteNonQuery();
                         }
                    }
               }
               catch (Exception ex)
               {                                                                                                                                    
                    InsLogInfo(ex.Message, GlobalVal.strApplicationName, "InsertEmailLog", "", 0, 0);
               }
          }                                 
     }
}
