﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace eTailingMailService
{
    class LogFile
    {
        public static void WriteLog(string message)
        {
            try
            {
                if (!GlobalVal.BlDebug)
                    return;

                string debugDir = GlobalVal.StrDebugPath;
                Directory.CreateDirectory(debugDir);

                using (var fs = new FileStream(debugDir + "\\" + GlobalVal.strApplicationName + "_" + DateTime.Now.Date.ToString("yyyyMMdd") + ".log", FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    using (var tw = new StreamWriter(fs))
                    {
                        tw.WriteLine(Convert.ToString(DateTime.Now) + "\t" + message);
                    }
                }
            }
            catch (Exception ex)
            {
                SqlLayer.InsLogInfo("Debug Directory Creation Error :" + ex.Message, GlobalVal.strApplicationName, "WriteLog()", "", 1, 0);
            }
        }

        public static void ErrorLog(string message)
        {
            try
            {
                if (!GlobalVal.BlError)
                    return;

                string errorDir = GlobalVal.StrErrorPath;
                Directory.CreateDirectory(errorDir);

                using (var fs = new FileStream(errorDir + "\\" + GlobalVal.strApplicationName + "_" + DateTime.Now.Date.ToString("yyyyMMdd") + ".log", FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                {
                    using (var tw = new StreamWriter(fs))
                    {
                        tw.WriteLine(Convert.ToString(DateTime.Now) + "\t" + message);
                    }
                }
            }
            catch (Exception ex)
            {
                SqlLayer.InsLogInfo("Debug Directory Creation Error :" + ex.Message, GlobalVal.strApplicationName, "WriteLog()", "", 1, 0);
            }
        }
    }
}
