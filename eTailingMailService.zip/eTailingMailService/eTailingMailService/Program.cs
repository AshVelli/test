﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace eTailingMailService
{
    class Program
    {


        public static void Main()
        {
            try
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]{new Service1()};
                ServiceBase.Run(ServicesToRun);
            }
            catch (Exception ex)
            {
                SqlLayer.InsLogInfo(ex.Message, GlobalVal.strApplicationName, "Main()", "", 0, 0);
            }
        }        
    }
}
