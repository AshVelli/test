﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Threading.Tasks;

namespace eTailingMailService
{
     class Mail
     {
          public void StartMailService()
          {
               string strAppName = GlobalVal.strApplicationName;
               int intInterval = GlobalVal.iIntervalMinutes;
               int iThreadCount = GlobalVal.iThreadCount;
               string strDebugPath = GlobalVal.StrDebugPath;
               string strErrorPath = GlobalVal.StrErrorPath; var fileThreads = new Thread[iThreadCount];
               DataSet dsMailContent = SqlLayer.GetMailContent(GlobalVal.maximumNumberOfRecordsToBeProcessed, GlobalVal.noOfAttemptsOnError);              
               //SqlLayer.InsLogInfo("Mail Firing Process Started.", GlobalVal.strApplicationName, "StartMailService", "", 0, 0);
                //if (dsMailContent == null)
               //{
               //     //if (dsMailContent.Tables[0].Rows.Count > 0)
               //     //{                                                              
               //     //SqlLayer.InsLogInfo("There is no mail pending in EmailQueue table!!!!", GlobalVal.strApplicationName, "StartMailService", "", 0, 0);
               //     return;
               //     //}
               //}
               foreach (DataRow dr in dsMailContent.Tables[0].Rows)
               {
                    try
                    {
                         string FromAddress = Convert.ToString(dr["FromAddress"]);
                         string ToAddress = Convert.ToString(dr["ToAddress"]);
                         string CcAddress = Convert.ToString(dr["CcAddress"]);
                         string BccAddress = Convert.ToString(dr["BccAddress"]);
                         string MailSubject = Convert.ToString(dr["MailSubject"]);
                         string MailContent = Convert.ToString(dr["MailContent"]);
                         string AttachmentPath = Convert.ToString(dr["AttachmentPath"]);
                         string LogId = Convert.ToString(dr["LogID"]);
                         if (iThreadCount == 1)
                              SendMail(FromAddress, ToAddress, CcAddress, BccAddress, GlobalVal.strAdminMail, MailSubject, MailContent, LogId, AttachmentPath);
                         else
                         {
                              while (true)
                              {
                                   try
                                   {
                                        //  int temp =  threadIndex;
                                        int threadIndex = GetFreeThreadIndex(fileThreads, iThreadCount);

                                        if (threadIndex >= 0)
                                        {
                                             fileThreads[threadIndex] = new Thread(() => SendMail(FromAddress, ToAddress, CcAddress, BccAddress, GlobalVal.strAdminMail, MailSubject, MailContent, LogId, AttachmentPath));
                                             fileThreads[threadIndex].Start();
                                             break;
                                        }
                                        Thread.Sleep(200);
                                   }
                                   catch (Exception ex)
                                   {
                                        SqlLayer.InsLogInfo(ex.Message, GlobalVal.strApplicationName, "StartMailService()", "", 1, 0);
                                   }
                              }
                         }
                    }
                    catch (Exception ex)
                    {
                         SqlLayer.InsLogInfo(ex.Message, GlobalVal.strApplicationName, "StartMailService()", "", 1, 0);
                    }
               }
               SqlLayer.InsLogInfo("Mail Firing Process Completed.", GlobalVal.strApplicationName, "StartMailService", "", 0, 0);
          }

          private static void SendMail(string FromAddress, string ToAddress, string CcAddress, string BccAddress, string AdminMailAddress, string Subject, string BodyContent, string LogId, string AttachmentPath)
          {
               SmtpClient smtpClient = new SmtpClient();
               MailMessage message = new MailMessage();
               try
               {
                    if (!string.IsNullOrEmpty(FromAddress.Trim()))
                    { //From address will be given as a MailAddress Object
                         MailAddress fromAddress = new MailAddress(FromAddress);
                         message.From = fromAddress;
                    }
                    // You can specify the host name or ipaddress of your server
                    // Default in IIS will be localhost 
                    smtpClient.Host = GlobalVal.strMailServer;
                    //Default port will be 25
                    smtpClient.Port = 25;
                    if (!string.IsNullOrEmpty(ToAddress.Trim()))
                    {
                         // To address collection of MailAddress
                         ToAddress = ToAddress.Replace(";", ",");
                         message.To.Add(ToAddress);
                    }
                    if (!string.IsNullOrEmpty(Subject.Trim()))
                    {
                         message.Subject = Subject;
                    }
                    if (!string.IsNullOrEmpty(CcAddress.Trim()))
                    {
                         // You can specify Address directly as string
                         CcAddress = CcAddress.Replace(";", ",");
                         // * 02 Start
                         message.CC.Add(CcAddress);
                         // * 02 End
                    }
                    if (!string.IsNullOrEmpty(BccAddress.Trim()))
                    {
                         // You can specify Address directly as string
                         BccAddress = BccAddress.Replace(";", ",");
                         // * 02 Start
                         message.Bcc.Add(BccAddress);
                         // * 02 End
                    }
                    //Body can be Html or text format
                    //Specify true if it  is html message
                    message.IsBodyHtml = true;

                    if (!string.IsNullOrEmpty(BodyContent.Trim()))
                    {
                         // Message body content
                         message.Body = BodyContent;
                    }
                    //Attachement 
                    if (!string.IsNullOrEmpty(AttachmentPath.Trim()))
                    {
                         message.Attachments.Add(new Attachment(AttachmentPath));
                    }
                    // Send SMTP mail
                    smtpClient.Send(message);
                    SqlLayer.InsertEmailLog(Convert.ToInt32(LogId), EmailStatus.SUCCESS.ToString(), "Email is sent successfully");
                    
               }
               catch (Exception ex)
               {
                    SqlLayer.InsLogInfo(ToAddress + "-" + ex.Message, GlobalVal.strApplicationName, "SendMail()", "", 1, 0);
                    SqlLayer.InsertEmailLog(Convert.ToInt32(LogId), EmailStatus.FAIL.ToString(), ex.Message);
               }
          }

          #region Thread
          private int GetFreeThreadIndex(Thread[] threads, int threadCount)
          {
               int freeThreadIndex = -1;

               for (int i = 0; i < threadCount; i++)
               {
                    try
                    {
                         if (threads[i] != null && !threads[i].IsAlive)
                              threads[i] = null;

                         if (threads[i] == null)
                         {
                              freeThreadIndex = i;
                              break;
                         }
                    }
                    catch (Exception ex)
                    {
                         SqlLayer.InsLogInfo(ex.Message, GlobalVal.strApplicationName, "GetFreeThreadIndex()", "", 1, 0);
                    }
               }
               return freeThreadIndex;
          }
          private bool IsThreadAlive(Thread[] threads, int threadCount)
          {
               bool isAlive = false;

               for (int i = 0; i < threadCount; i++)
               {
                    try
                    {
                         if (threads[i] != null && threads[i].IsAlive)
                              isAlive = true;
                         else
                              threads[i] = null;
                    }
                    catch (Exception ex)
                    {
                         SqlLayer.InsLogInfo(ex.Message, GlobalVal.strApplicationName, "IsThreadAlive()", "", 1, 0);
                    }
               }
               return isAlive;
          }
          #endregion
     }
}

