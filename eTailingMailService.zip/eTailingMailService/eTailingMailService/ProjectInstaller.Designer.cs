﻿namespace eTailingMailService
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eTailingMailServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.eTailingMailServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // eTailingMailServiceProcessInstaller
            // 
            this.eTailingMailServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
            this.eTailingMailServiceProcessInstaller.Password = null;
            this.eTailingMailServiceProcessInstaller.Username = null;
            // 
            // eTailingMailServiceInstaller
            // 
            this.eTailingMailServiceInstaller.DisplayName = "eTailing Mail Service";
            this.eTailingMailServiceInstaller.ServiceName = "Service1";
            this.eTailingMailServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.eTailingMailServiceInstaller,
            this.eTailingMailServiceProcessInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller eTailingMailServiceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller eTailingMailServiceInstaller;
    }
}