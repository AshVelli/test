﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;

namespace eTailingMailService
{
     enum EmailStatus
     {
          SUCCESS,
          FAIL
     }

    class GlobalVal
    {

        #region Global Values
        public static string strApplicationName;
        public static bool BlStartImmediately;
        public static int iIntervalMinutes;
        public static int iThreadCount;
        public static bool BlDebug;
        public static string StrDebugPath;
        public static bool BlError;
        public static string StrErrorPath;
        public static string strAdminMail;
        public static string strMailServer;
        public static string strConnType;
        public static string strproxyAddress;
        public static string strproxyUserName;
        public static string strproxyPassword;        
        public static int maximumNumberOfRecordsToBeProcessed;
        public static int noOfAttemptsOnError;
        #endregion


        static GlobalVal()
        {
            strApplicationName = ConfigurationManager.AppSettings["ApplicationName"].ToString();
            BlStartImmediately = Convert.ToBoolean(ConfigurationManager.AppSettings["StartImmediately"]);
            iIntervalMinutes = Convert.ToInt32(ConfigurationManager.AppSettings["IntervalMinutes"]);
            iThreadCount = Convert.ToInt32(ConfigurationManager.AppSettings["ThreadCount"]);
            BlDebug = Convert.ToBoolean(ConfigurationManager.AppSettings["Debug"]);
            StrDebugPath = ConfigurationManager.AppSettings["DebugPath"].ToString();
            BlError = Convert.ToBoolean(ConfigurationManager.AppSettings["Error"]);
            StrErrorPath = ConfigurationManager.AppSettings["ErrorPath"].ToString();
            strAdminMail = ConfigurationManager.AppSettings["AdminMailAddress"].ToString();
            strMailServer = ConfigurationManager.AppSettings["MailServer"].ToString();
            strConnType = ConfigurationManager.ConnectionStrings["eTailingMailService_Connection"].ConnectionString;
            strproxyAddress = ConfigurationManager.AppSettings["ProxyAddress"].ToString();
            strproxyUserName = ConfigurationManager.AppSettings["ProxyUserName"].ToString();
            strproxyPassword = ConfigurationManager.AppSettings["ProxyPassword"].ToString();
            maximumNumberOfRecordsToBeProcessed = Convert.ToInt32(ConfigurationManager.AppSettings["MaximumNumberOfRecordsToBeProcessed"]);
            noOfAttemptsOnError = Convert.ToInt32(ConfigurationManager.AppSettings["NoOfAttemptsOnError"]);
        }
    }

    public class GetMailContentVO
    {
        private string _strlogid = string.Empty;
        private string _strflag = string.Empty;

        public string Logid
        {
            get { return _strlogid; }
            set { _strlogid = value; }
        }

        public string Flag
        {
            get { return _strflag; }
            set { _strflag = value; }
        }
    }
}
