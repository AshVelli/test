﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace eTailingMailService
{
    public partial class Service1 : ServiceBase
    {
        readonly Timer _ttimer = new Timer();
        readonly Mail _Mail = new Mail();

        public Service1()
        {
            InitializeComponent();
        }



        protected override void OnStart(string[] args)
        {
            StartProcess();
        }

        protected override void OnStop()
        {
        }


        private void StartProcess()
        {
            _ttimer.Enabled = false;

            if (GlobalVal.BlStartImmediately)
            {
                _Mail.StartMailService();

            }

            _ttimer.Enabled = true;
            _ttimer.Interval = GlobalVal.iIntervalMinutes * 1000;
            _ttimer.AutoReset = true;
            _ttimer.Start();
            _ttimer.Elapsed += OnTimedEvent;
        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            _ttimer.Enabled = false;

            _Mail.StartMailService();
            _ttimer.Enabled = true;
        }
    }
}
