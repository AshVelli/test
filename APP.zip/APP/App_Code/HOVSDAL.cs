using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Configuration;




public class OutParams
{
    public string OParamName;
    public string OParamValue;
}

public class HTN_Result
{
    public int ResultCode = 0;
    public string HTN;
    private string sErrrorMessage;

    public String ErrrorMessage
    {
        get
        {
            if (ResultCode == 0)
            {
                return null;
            }
            else
            {
                return sErrrorMessage;
            }
        }
        set
        {
            sErrrorMessage = value;
        }
    }
}



[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.None)]

public class HOVSDAL : System.Web.Services.WebService
{
    public HOVSDAL()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }




    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod(MessageName = "ThisMethodneedsToBeCalledAfterEsort..")]
    public string UpdateEsortHTN(String ChildHTN, String ParentHTN, String FileSeqId, String ClaimTypeId, String StatusSeqId, String ProjectId)
    {
        String Msg = String.Empty;
        SqlConnection strConn = null;
        String SqlCon = ConfigurationManager.ConnectionStrings["PCHConnectingString"].ToString();
        String strClaimType = ConfigurationManager.AppSettings["ClaimTypeId"].ToString();
        String strFileType = ConfigurationManager.AppSettings["FileTypeId"].ToString();
        String strStatus = ConfigurationManager.AppSettings["StatusId"].ToString();
        String strProjectId = ConfigurationManager.AppSettings["ProjectId"].ToString();
        if (ChildHTN == String.Empty)
            Msg = Msg + "Child HTN Should not be Empty";
        else if (ChildHTN.Length < 21)
            Msg = Msg + "Child HTN Should not be less than 21";
        if (ParentHTN == String.Empty)
            Msg = Msg + "HTN Should not be Empty\n";
        else if (ParentHTN.Length != 21)
            Msg = Msg + "HTN Lenght Should be Equal to 21\n";
        if (FileSeqId == String.Empty)
            Msg = Msg + "FileSeqId Should not be Empty\n";
        else if (!(strFileType.Contains(FileSeqId)))
            Msg = Msg + "Invalid FileSeqId\n";
        if (ClaimTypeId == String.Empty)
            Msg = Msg + "ClaimTypeId Should not be Empty";
        else if (!(strClaimType.Contains(strClaimType)))
            Msg = Msg + "Invalid ClaimTypeId";
        if (StatusSeqId == String.Empty)
            Msg = Msg + "StatusSeqId Should not be Empty";
        else if (!(strStatus.Contains(StatusSeqId)))
            Msg = Msg + "Invalid StatusSeqId";
        if (ProjectId == String.Empty)
            Msg = Msg + "ProjectId Should not be Empty";
        else if (!(strProjectId.Contains(ProjectId)))
            Msg = Msg + "Invalid ProjectId";

        if (Msg == String.Empty)
        {
            try
            {
                using (strConn = new SqlConnection(SqlCon))
                {
                    String Serviceseqid = string.Empty;
                    strConn.Open();
                    string[] strProject = strProjectId.Split(',');
                    if (ProjectId.ToLower() == Convert.ToString(strProject[0]))
                    {
                        if (FileSeqId == "1")
                            Serviceseqid = ConfigurationManager.AppSettings["HCFA_DDE"].ToString();
                        else if (FileSeqId == "2")
                            Serviceseqid = ConfigurationManager.AppSettings["HCFA_PTIUploadPrintToImageServiceId"].ToString();
                        else if (FileSeqId == "3")
                            Serviceseqid = ConfigurationManager.AppSettings["HCFA_PTIUploadImageUploadServiceId"].ToString();
                        else if (FileSeqId == "4")
                            Serviceseqid = ConfigurationManager.AppSettings["HCFA_FAX"].ToString();
                    }
                    else if (ProjectId.ToLower() == Convert.ToString(strProject[1]))
                    {
                        Serviceseqid = ConfigurationManager.AppSettings["MC_HCFA_DDE"].ToString();
                    }
                    SqlCommand SqlCom = new SqlCommand("PMS_SP_EsortCalimsupdate", strConn);
                    SqlCom.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] param = new SqlParameter[7];

                    param[0] = new SqlParameter();
                    param[0].ParameterName = "@ParentHTN";
                    param[0].Direction = ParameterDirection.Input;
                    param[0].SqlDbType = SqlDbType.VarChar;
                    param[0].Size = 25;
                    param[0].Value = ParentHTN;

                    param[1] = new SqlParameter();
                    param[1].ParameterName = "@ChildHTN";
                    param[1].Direction = ParameterDirection.Input;
                    param[1].SqlDbType = SqlDbType.VarChar;
                    param[1].Size = 25;
                    param[1].Value = ChildHTN;

                    param[2] = new SqlParameter();
                    param[2].Direction = ParameterDirection.Input;
                    param[2].ParameterName = "@FileSeqid";
                    param[2].SqlDbType = SqlDbType.Int;
                    param[2].Value = 4;
                    param[2].Value = Convert.ToInt32(FileSeqId);

                    param[3] = new SqlParameter();
                    param[3].Direction = ParameterDirection.Input;
                    param[3].ParameterName = "@ClaimTypeId";
                    param[3].SqlDbType = SqlDbType.Int;
                    param[3].Size = 4;
                    param[3].Value = Convert.ToInt32(ClaimTypeId);

                    param[4] = new SqlParameter();
                    param[4].Direction = ParameterDirection.Input;
                    param[4].ParameterName = "@Statusseqid";
                    param[4].SqlDbType = SqlDbType.Int;
                    param[4].Size = 4;
                    param[4].Value = Convert.ToInt32(StatusSeqId);

                    param[5] = new SqlParameter();
                    param[5].Direction = ParameterDirection.Input;
                    param[5].ParameterName = "@ServicesSeqId";
                    param[5].SqlDbType = SqlDbType.Int;
                    param[5].Size = 4;
                    param[5].Value = Convert.ToInt32(Serviceseqid);

                    param[6] = new SqlParameter();
                    param[6].Direction = ParameterDirection.Output;
                    param[6].ParameterName = "@output";
                    param[6].SqlDbType = SqlDbType.VarChar;
                    param[6].Size = 100;

                    SqlCom.Parameters.Add(param[0]);
                    SqlCom.Parameters.Add(param[1]);
                    SqlCom.Parameters.Add(param[2]);
                    SqlCom.Parameters.Add(param[3]);
                    SqlCom.Parameters.Add(param[4]);
                    SqlCom.Parameters.Add(param[5]);
                    SqlCom.Parameters.Add(param[6]);

                    Msg = param[6].Value.ToString();
                }
            }
            catch (Exception e)
            {
                if (e.Message.Contains("PRIMARY KEY"))
                    Msg = "Duplicate Child HTN";
                else
                    Msg = "Failure";
            }
            finally
            {
                if (strConn != null) strConn.Dispose();
            }
        }
        return Msg.ToLower();
    }



    [WebMethod(MessageName = "FAXHTNupdation")]
    public string HTNFaxIntermediate(String HTN, String FaxFileName, String FaxReceiveDate, String Provider, String DocumentType, int PageCount)
    {
        String Msg = String.Empty;
        SqlConnection SqlCon = null;
        String strConn = ConfigurationManager.ConnectionStrings["PCHConnectingString"].ToString();
        if (HTN == String.Empty)
            Msg = Msg + "HTN Should not be Empty\n";
        else if (HTN.Length != 21)
            Msg = Msg + "HTN Lenght Should be Equal to 21\n";
        if (FaxFileName == String.Empty)
            Msg = Msg + "FaxFileName Should not be Empty\n";
        if (FaxReceiveDate == String.Empty)
            Msg = Msg + "FaxReceiveDate Should not be Empty\n";
        if (Provider == String.Empty)
            Msg = Msg + "Provider Should not be Empty \n";
        else if (Provider.Length != 7)
            Msg = Msg + "Provider Lenght Should be Equal to 7\n";
        if (DocumentType == String.Empty)
            Msg = Msg + "Document Type Should not be Empty\n";
        if (PageCount == 0)
            Msg = Msg + "Page Count Should be Greater than 0";

        if (Msg == String.Empty)
        {
            try
            {
                using (SqlCon = new SqlConnection(strConn))
                {
                    SqlCon.Open();
                    SqlCommand SqlCom = new SqlCommand("PMS_SP_HTNFaxIntermediate", SqlCon);
                    SqlCom.CommandType = CommandType.StoredProcedure;
                    SqlParameter[] param = new SqlParameter[6];

                    param[0] = new SqlParameter();
                    param[0].ParameterName = "@HTN";
                    param[0].Direction = ParameterDirection.Input;
                    param[0].SqlDbType = SqlDbType.VarChar;
                    param[0].Size = 25;
                    param[0].Value = HTN;

                    param[1] = new SqlParameter();
                    param[1].ParameterName = "@FaxFileName";
                    param[1].Direction = ParameterDirection.Input;
                    param[1].SqlDbType = SqlDbType.VarChar;
                    param[1].Size = 100;
                    param[1].Value = FaxFileName;

                    param[2] = new SqlParameter();
                    param[2].Direction = ParameterDirection.Input;
                    param[2].ParameterName = "@FaxReceiveDate";
                    param[2].SqlDbType = SqlDbType.DateTime;
                    param[2].Value = FaxReceiveDate;

                    param[3] = new SqlParameter();
                    param[3].Direction = ParameterDirection.Input;
                    param[3].ParameterName = "@Provider";
                    param[3].SqlDbType = SqlDbType.VarChar;
                    param[3].Size = 7;
                    param[3].Value = Provider;

                    param[4] = new SqlParameter();
                    param[4].Direction = ParameterDirection.Input;
                    param[4].ParameterName = "@DocumentType";
                    param[4].SqlDbType = SqlDbType.VarChar;
                    param[4].Size = 100;
                    param[4].Value = DocumentType;

                    param[5] = new SqlParameter();
                    param[5].Direction = ParameterDirection.Input;
                    param[5].ParameterName = "@PageCount";
                    param[5].SqlDbType = SqlDbType.Int;
                    param[5].Size = 4;
                    param[5].Value = PageCount;

                    SqlCom.Parameters.Add(param[0]);
                    SqlCom.Parameters.Add(param[1]);
                    SqlCom.Parameters.Add(param[2]);
                    SqlCom.Parameters.Add(param[3]);
                    SqlCom.Parameters.Add(param[4]);
                    SqlCom.Parameters.Add(param[5]);
                    SqlCom.ExecuteNonQuery();
                    Msg = "Success";
                }
            }
            catch (Exception e)
            {
                Msg = e.Message;
            }
            finally
            {
                if (SqlCon != null) SqlCon.Dispose();
            }
        }
        return Msg.ToLower();
    }


    #region private utility methods & constructors



    /// <summary>
    /// This method is used to attach array of SqlParameters to a SqlCommand.
    /// 
    /// This method will assign a value of DbNull to any parameter with a direction of
    /// InputOutput and a value of null.  
    /// 
    /// This behavior will prevent default values from being used, but
    /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
    /// where the user provided no input value.
    /// </summary>
    /// <param name="command">The command to which the parameters will be added</param>
    /// <param name="commandParameters">an array of SqlParameters tho be added to command</param>
    private static void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
    {
        foreach (SqlParameter p in commandParameters)
        {
            //check for derived output value with no value assigned
            if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
            {
                p.Value = DBNull.Value;
            }

            command.Parameters.Add(p);
        }
    }

    /// <summary>
    /// This method assigns an array of values to an array of SqlParameters.
    /// </summary>
    /// <param name="commandParameters">array of SqlParameters to be assigned values</param>
    /// <param name="parameterValues">array of objects holding the values to be assigned</param>
    private static void AssignParameterValues(SqlParameter[] commandParameters, object[] parameterValues)
    {
        if ((commandParameters == null) || (parameterValues == null))
        {
            //do nothing if we get no data
            return;
        }

        // we must have the same number of values as we pave parameters to put them in
        if (commandParameters.Length != parameterValues.Length)
        {
            throw new ArgumentException("Parameter count does not match Parameter Value count.");
        }

        //iterate through the SqlParameters, assigning the values from the corresponding position in the 
        //value array
        for (int i = 0, j = commandParameters.Length; i < j; i++)
        {
            commandParameters[i].Value = parameterValues[i];
        }
    }

    /// <summary>
    /// This method opens (if necessary) and assigns a connection, transaction, command type and parameters 
    /// to the provided command.
    /// </summary>
    /// <param name="command">the SqlCommand to be prepared</param>
    /// <param name="connection">a valid SqlConnection, on which to execute this command</param>
    /// <param name="transaction">a valid SqlTransaction, or 'null'</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParameters to be associated with the command or 'null' if no parameters are required</param>
    private static void PrepareCommand(SqlCommand command, SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters)
    {
        //if the provided connection is not open, we will open it
        if (connection.State != ConnectionState.Open)
        {
            connection.Open();
        }

        //associate the connection with the command
        command.Connection = connection;
        command.CommandTimeout = 0;

        //set the command text (stored procedure name or SQL statement)
        command.CommandText = commandText;

        //if we were provided a transaction, assign it.
        if (transaction != null)
        {
            command.Transaction = transaction;
        }

        //set the command type
        command.CommandType = commandType;


        //attach the command parameters if they are provided
        if (commandParameters != null)
        {
            AttachParameters(command, commandParameters);
        }

        return;
    }






    #endregion private utility methods & constructors

    #region ExecuteNonQuery

    /// <summary>
    /// Execute a SqlCommand (that returns no resultset and takes no parameters) against the database specified in 
    /// the connection string. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders");
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>an int representing the number of rows affected by the command</returns>
    [WebMethod(MessageName = "ExecuteNonQueryOverload0")]
    public int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            int retval = cmd.ExecuteNonQuery();
            cn.Close();
            return retval;
        }

    }

    [WebMethod(MessageName = "ExecuteNonQueryOverload123")]
    public int ExecuteNonQuery1(string connectionString, CommandType commandType, string commandText)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            int retval = cmd.ExecuteNonQuery();
            cn.Close();
            return retval;
        }

    }

    /// <summary>
    /// Execute a SqlCommand (that returns no resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>an int representing the number of rows affected by the command</returns>
    [WebMethod(MessageName = "ExecuteNonQueryOverload1")]
    public int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText, SqlParameter[] commandParameters)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;

            //attach the command parameters if they are provided
            // SqlParameter[] Param = (SqlParameter[])commandParameters;


            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }

                    cmd.Parameters.Add(p);
                }

            }
            int retval = cmd.ExecuteNonQuery();
            cn.Close();
            return retval;
        }
    }




    /// <summary>
    /// Execute a SqlCommand (that returns no resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>an int representing the number of rows affected by the command</returns>
    [WebMethod(MessageName = "ExecuteNonQueryOverload2")]
    public OutParams[] ExecuteNonQueryOP(string connectionString, CommandType commandType, string commandText, SqlParameter[] commandParameters)
    {
        OutParams[] OUTPARAM = null;

        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;

            //attach the command parameters if they are provided
            // SqlParameter[] Param = (SqlParameter[])commandParameters;


            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }

                    cmd.Parameters.Add(p);
                }

            }
            int retval = cmd.ExecuteNonQuery();

            if (commandParameters != null)
            {
                int cnt = 0;
                foreach (SqlParameter po in cmd.Parameters)
                {
                    if ((po.Direction == ParameterDirection.Output))
                    { cnt += 1; }
                }
                OUTPARAM = new OutParams[cnt];
                cnt = 0;
                foreach (SqlParameter po in cmd.Parameters)
                {
                    if ((po.Direction == ParameterDirection.Output))
                    {
                        OUTPARAM[cnt] = new OutParams();
                        OUTPARAM[cnt].OParamName = po.ParameterName.ToString();
                        OUTPARAM[cnt].OParamValue = po.Value.ToString();
                        cnt += 1;
                    }
                }
            }

            cn.Close();
            return OUTPARAM;


        }
    }






    #endregion

    #region ExecuteDataSet

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the database specified in 
    /// the connection string. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(connString, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteDatasetOverload0")]
    public DataSet ExecuteDataset(string connectionString, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteDataset(connectionString, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(connString, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteDatasetOverload1")]
    public DataSet ExecuteDataset(string connectionString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //call the overload that takes a connection in place of the connection string
            return ExecuteDataset(cn, commandType, commandText, commandParameters);
        }
    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the database specified in 
    /// the connection string using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(connString, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteDatasetOverload2")]
    public DataSet ExecuteDataset(string connectionString, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            //pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
            SqlParameter[] commandParameters = GetSpParameterSet(connectionString, spName);

            //assign the provided values to these parameters based on parameter order
            AssignParameterValues(commandParameters, parameterValues);

            //call the overload that takes an array of SqlParameters
            return ExecuteDataset(connectionString, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteDataset(connectionString, CommandType.StoredProcedure, spName);
        }
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the provided SqlConnection. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(conn, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    /// [WebMethod(MessageName = "ExecuteDatasetOverload3")]     
    public DataSet ExecuteDataset(SqlConnection connection, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteDataset(connection, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the specified SqlConnection 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(conn, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    // [WebMethod(MessageName = "ExecuteDatasetOverload4")]         
    public DataSet ExecuteDataset(SqlConnection connection, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //create a command and prepare it for execution
        SqlCommand cmd = new SqlCommand();
        cmd.CommandTimeout = 900000;	//durga added for test
        PrepareCommand(cmd, connection, (SqlTransaction)null, commandType, commandText, commandParameters);

        //create the DataAdapter & DataSet
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        //fill the DataSet using default values for DataTable names, etc.
        da.Fill(ds);

        // detach the SqlParameters from the command object, so they can be used again.			
        cmd.Parameters.Clear();

        //return the dataset
        return ds;
    }
    ///[WebMethod(MessageName = "ExecuteDatasetByCommand")]   

    public DataSet ExecuteDatasetByCommand(string connectionString, SqlCommand cmd)
    {
        //create a command and prepare it for execution
        //SqlCommand cmd = new SqlCommand();
        //PrepareCommand(cmd, connection, (SqlTransaction)null,  commandType, cmd.commandText, commandParameters);
        SqlConnection cn = new SqlConnection(connectionString);
        //cn.Open();

        try
        {
            cmd.Connection = cn;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.Parameters.Clear();
            return ds;
        }
        catch
        {
            //if we fail to return the SqlDatReader, we need to close the connection ourselves
            cn.Close();
            throw;
        }


    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified SqlConnection 
    /// using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(conn, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    /// [WebMethod(MessageName = "ExecuteDatasetOverload5")]
    public DataSet ExecuteDataset(SqlConnection connection, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            //pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
            SqlParameter[] commandParameters = GetSpParameterSet(connection.ConnectionString, spName);

            //assign the provided values to these parameters based on parameter order
            AssignParameterValues(commandParameters, parameterValues);

            //call the overload that takes an array of SqlParameters
            return ExecuteDataset(connection, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteDataset(connection, CommandType.StoredProcedure, spName);
        }
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the provided SqlTransaction. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(trans, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    /// ///[WebMethod(MessageName = "ExecuteDatasetOverload6")]
    public DataSet ExecuteDataset(SqlTransaction transaction, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteDataset(transaction, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the specified SqlTransaction
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(trans, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    /// ///[WebMethod(MessageName = "ExecuteDatasetOverload7")]
    public DataSet ExecuteDataset(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //create a command and prepare it for execution
        SqlCommand cmd = new SqlCommand();
        PrepareCommand(cmd, transaction.Connection, transaction, commandType, commandText, commandParameters);

        //create the DataAdapter & DataSet
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        //fill the DataSet using default values for DataTable names, etc.
        da.Fill(ds);

        // detach the SqlParameters from the command object, so they can be used again.
        cmd.Parameters.Clear();

        //return the dataset
        return ds;
    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified 
    /// SqlTransaction using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  DataSet ds = ExecuteDataset(trans, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a dataset containing the resultset generated by the command</returns>
    /// ///[WebMethod(MessageName = "ExecuteDatasetOverload8")]
    public DataSet ExecuteDataset(SqlTransaction transaction, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            //pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
            SqlParameter[] commandParameters = GetSpParameterSet(transaction.Connection.ConnectionString, spName);

            //assign the provided values to these parameters based on parameter order
            AssignParameterValues(commandParameters, parameterValues);

            //call the overload that takes an array of SqlParameters
            return ExecuteDataset(transaction, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteDataset(transaction, CommandType.StoredProcedure, spName);
        }
    }

    #endregion ExecuteDataSet

    #region ExecuteReader

    /// <summary>
    /// this enum is used to indicate whether the connection was provided by the caller, or created by SqlHelper, so that
    /// we can set the appropriate CommandBehavior when calling ExecuteReader()
    /// </summary>
    private enum SqlConnectionOwnership
    {
        /// <summary>Connection is owned and managed by SqlHelper</summary>
        Internal,
        /// <summary>Connection is owned and managed by the caller</summary>
        External
    }

    /// <summary>
    /// Create and prepare a SqlCommand, and call ExecuteReader with the appropriate CommandBehavior.
    /// </summary>
    /// <remarks>
    /// If we created and opened the connection, we want the connection to be closed when the DataReader is closed.
    /// 
    /// If the caller provided the connection, we want to leave it to them to manage.
    /// </remarks>
    /// <param name="connection">a valid SqlConnection, on which to execute this command</param>
    /// <param name="transaction">a valid SqlTransaction, or 'null'</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParameters to be associated with the command or 'null' if no parameters are required</param>
    /// <param name="connectionOwnership">indicates whether the connection parameter was provided by the caller, or created by SqlHelper</param>
    /// <returns>SqlDataReader containing the results of the command</returns>

    private static SqlDataReader ExecuteReader(SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters, SqlConnectionOwnership connectionOwnership)
    {



        //create a command and prepare it for execution
        SqlCommand cmd = new SqlCommand();
        PrepareCommand(cmd, connection, transaction, commandType, commandText, commandParameters);

        //create a reader
        SqlDataReader dr;

        // call ExecuteReader with the appropriate CommandBehavior
        if (connectionOwnership == SqlConnectionOwnership.External)
        {
            dr = cmd.ExecuteReader();
        }
        else
        {
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        // detach the SqlParameters from the command object, so they can be used again.
        cmd.Parameters.Clear();

        return dr;
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the database specified in 
    /// the connection string. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(connString, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    //  [WebMethod(MessageName = "ExecuteReaderOverload1")]
    public SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteReader(connectionString, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(connString, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(string connectionString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //create & open a SqlConnection
        SqlConnection cn = new SqlConnection(connectionString);
        cn.Open();

        try
        {
            //call the private overload that takes an internally owned connection in place of the connection string
            return ExecuteReader(cn, null, commandType, commandText, commandParameters, SqlConnectionOwnership.Internal);
        }
        catch
        {
            //if we fail to return the SqlDatReader, we need to close the connection ourselves
            cn.Close();
            throw;
        }
    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the database specified in 
    /// the connection string using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(connString, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(string connectionString, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            //pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
            SqlParameter[] commandParameters = GetSpParameterSet(connectionString, spName);

            //assign the provided values to these parameters based on parameter order
            AssignParameterValues(commandParameters, parameterValues);

            //call the overload that takes an array of SqlParameters
            return ExecuteReader(connectionString, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteReader(connectionString, CommandType.StoredProcedure, spName);
        }
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the provided SqlConnection. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(conn, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlConnection connection, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteReader(connection, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the specified SqlConnection 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(conn, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlConnection connection, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //pass through the call to the private overload using a null transaction value and an externally owned connection
        return ExecuteReader(connection, (SqlTransaction)null, commandType, commandText, commandParameters, SqlConnectionOwnership.External);
    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified SqlConnection 
    /// using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(conn, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="connection">a valid SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlConnection connection, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            SqlParameter[] commandParameters = GetSpParameterSet(connection.ConnectionString, spName);

            AssignParameterValues(commandParameters, parameterValues);

            return ExecuteReader(connection, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteReader(connection, CommandType.StoredProcedure, spName);
        }
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset and takes no parameters) against the provided SqlTransaction. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(trans, CommandType.StoredProcedure, "GetOrders");
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlTransaction transaction, CommandType commandType, string commandText)
    {
        //pass through the call providing null for the set of SqlParameters
        return ExecuteReader(transaction, commandType, commandText, (SqlParameter[])null);
    }

    /// <summary>
    /// Execute a SqlCommand (that returns a resultset) against the specified SqlTransaction
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///   SqlDataReader dr = ExecuteReader(trans, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
    {
        //pass through to private overload, indicating that the connection is owned by the caller
        return ExecuteReader(transaction.Connection, transaction, commandType, commandText, commandParameters, SqlConnectionOwnership.External);
    }

    /// <summary>
    /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified
    /// SqlTransaction using the provided parameter values.  This method will query the database to discover the parameters for the 
    /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
    /// </summary>
    /// <remarks>
    /// This method provides no access to output parameters or the stored procedure's return value parameter.
    /// 
    /// e.g.:  
    ///  SqlDataReader dr = ExecuteReader(trans, "GetOrders", 24, 36);
    /// </remarks>
    /// <param name="transaction">a valid SqlTransaction</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
    /// <returns>a SqlDataReader containing the resultset generated by the command</returns>
    public SqlDataReader ExecuteReader(SqlTransaction transaction, string spName, params object[] parameterValues)
    {
        //if we receive parameter values, we need to figure out where they go
        if ((parameterValues != null) && (parameterValues.Length > 0))
        {
            SqlParameter[] commandParameters = GetSpParameterSet(transaction.Connection.ConnectionString, spName);

            AssignParameterValues(commandParameters, parameterValues);

            return ExecuteReader(transaction, CommandType.StoredProcedure, spName, commandParameters);
        }
        //otherwise we can just call the SP without params
        else
        {
            return ExecuteReader(transaction, CommandType.StoredProcedure, spName);
        }
    }

    #endregion ExecuteReader

    #region ExecuteScalar

    /// <summary>
    /// Execute a SqlCommand (that returns a 1x1 resultset and takes no parameters) against the database specified in 
    /// the connection string. 
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int orderCount = (int)ExecuteScalar(connString, CommandType.StoredProcedure, "GetOrderCount");
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>an object containing the value in the 1x1 resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteScalarOverload0")]
    public object ExecuteScalar(string connectionString, CommandType commandType, string commandText)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;



            //execute the command & return the results
            object retval = cmd.ExecuteScalar();
            cn.Close();
            return retval;
        }


    }

    /// <summary>
    /// Execute a SqlCommand (that returns a 1x1 resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int orderCount = (int)ExecuteScalar(connString, CommandType.StoredProcedure, "GetOrderCount", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>an object containing the value in the 1x1 resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteScalarOverload1")]
    public object ExecuteScalar(string connectionString, CommandType commandType, string commandText, SqlParameter[] commandParameters)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();

            cn.Open();

            //associate the connection with the command
            cmd.Connection = cn;
            cmd.CommandTimeout = 0;
            //set the command text (stored procedure name or SQL statement)
            cmd.CommandText = commandText;
            //set the command type
            cmd.CommandType = commandType;
            //attach the command parameters if they are provided
            // SqlParameter[] Param = (SqlParameter[])commandParameters;


            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }

                    cmd.Parameters.Add(p);


                }

            }

            //execute the command & return the results
            object retval = cmd.ExecuteScalar();

            cn.Close();
            return retval;
        }
    }


    /// <summary>
    /// Execute a SqlCommand (that returns a 1x1 resultset) against the database specified in the connection string 
    /// using the provided parameters.
    /// </summary>
    /// <remarks>
    /// e.g.:  
    ///  int orderCount = (int)ExecuteScalar(connString, CommandType.StoredProcedure, "GetOrderCount", new SqlParameter("@prodid", 24));
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
    /// <returns>an object containing the value in the 1x1 resultset generated by the command</returns>
    [WebMethod(MessageName = "ExecuteScalarOverload2")]
    public OutParams[] ExecuteScalarOP(string connectionString, CommandType commandType, string commandText, SqlParameter[] commandParameters)
    {
        OutParams[] OUTPARAM = null;
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();

            cn.Open();

            //associate the connection with the command
            cmd.Connection = cn;
            cmd.CommandTimeout = 0;
            //set the command text (stored procedure name or SQL statement)
            cmd.CommandText = commandText;
            //set the command type
            cmd.CommandType = commandType;
            //attach the command parameters if they are provided
            // SqlParameter[] Param = (SqlParameter[])commandParameters;


            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }

                    cmd.Parameters.Add(p);

                }

            }

            //execute the command & return the results
            object retval = cmd.ExecuteScalar();

            if (commandParameters != null)
            {
                int cnt = 0;
                foreach (SqlParameter po in cmd.Parameters)
                {
                    if ((po.Direction == ParameterDirection.Output))
                    { cnt += 1; }
                }
                OUTPARAM = new OutParams[cnt];
                cnt = 0;
                foreach (SqlParameter po in cmd.Parameters)
                {
                    if ((po.Direction == ParameterDirection.Output))
                    {
                        OUTPARAM[cnt] = new OutParams();
                        OUTPARAM[cnt].OParamName = po.ParameterName.ToString();
                        OUTPARAM[cnt].OParamValue = po.Value.ToString();
                        cnt += 1;
                    }
                }
            }

            cn.Close();
            return OUTPARAM;
        }
    }




    #endregion


    #region private methods, variables, and constructors



    private static Hashtable paramCache = Hashtable.Synchronized(new Hashtable());

    /// <summary>
    /// resolve at run time the appropriate set of SqlParameters for a stored procedure
    /// </summary>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="includeReturnValueParameter">whether or not to include their return value parameter</param>
    /// <returns></returns>
    private static SqlParameter[] DiscoverSpParameterSet(string connectionString, string spName, bool includeReturnValueParameter)
    {
        using (SqlConnection cn = new SqlConnection(connectionString))
        using (SqlCommand cmd = new SqlCommand(spName, cn))
        {
            cn.Open();
            cmd.CommandType = CommandType.StoredProcedure;

            SqlCommandBuilder.DeriveParameters(cmd);

            if (!includeReturnValueParameter)
            {
                cmd.Parameters.RemoveAt(0);
            }

            SqlParameter[] discoveredParameters = new SqlParameter[cmd.Parameters.Count]; ;

            cmd.Parameters.CopyTo(discoveredParameters, 0);

            return discoveredParameters;
        }
    }

    //deep copy of cached SqlParameter array
    private static SqlParameter[] CloneParameters(SqlParameter[] originalParameters)
    {
        SqlParameter[] clonedParameters = new SqlParameter[originalParameters.Length];

        for (int i = 0, j = originalParameters.Length; i < j; i++)
        {
            clonedParameters[i] = (SqlParameter)((ICloneable)originalParameters[i]).Clone();
        }

        return clonedParameters;
    }

    #endregion private methods, variables, and constructors

    #region caching functions

    /// <summary>
    /// add parameter array to the cache
    /// </summary>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <param name="commandParameters">an array of SqlParamters to be cached</param>
    public static void CacheParameterSet(string connectionString, string commandText, params SqlParameter[] commandParameters)
    {
        string hashKey = connectionString + ":" + commandText;

        paramCache[hashKey] = commandParameters;
    }

    /// <summary>
    /// retrieve a parameter array from the cache
    /// </summary>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="commandText">the stored procedure name or T-SQL command</param>
    /// <returns>an array of SqlParamters</returns>
    public static SqlParameter[] GetCachedParameterSet(string connectionString, string commandText)
    {
        string hashKey = connectionString + ":" + commandText;

        SqlParameter[] cachedParameters = (SqlParameter[])paramCache[hashKey];

        if (cachedParameters == null)
        {
            return null;
        }
        else
        {
            return CloneParameters(cachedParameters);
        }
    }

    #endregion caching functions

    #region Parameter Discovery Functions

    /// <summary>
    /// Retrieves the set of SqlParameters appropriate for the stored procedure
    /// </summary>
    /// <remarks>
    /// This method will query the database for this information, and then store it in a cache for future requests.
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <returns>an array of SqlParameters</returns>
    public static SqlParameter[] GetSpParameterSet(string connectionString, string spName)
    {
        return GetSpParameterSet(connectionString, spName, false);
    }

    /// <summary>
    /// Retrieves the set of SqlParameters appropriate for the stored procedure
    /// </summary>
    /// <remarks>
    /// This method will query the database for this information, and then store it in a cache for future requests.
    /// </remarks>
    /// <param name="connectionString">a valid connection string for a SqlConnection</param>
    /// <param name="spName">the name of the stored procedure</param>
    /// <param name="includeReturnValueParameter">a bool value indicating whether the return value parameter should be included in the results</param>
    /// <returns>an array of SqlParameters</returns>
    public static SqlParameter[] GetSpParameterSet(string connectionString, string spName, bool includeReturnValueParameter)
    {
        string hashKey = connectionString + ":" + spName + (includeReturnValueParameter ? ":include ReturnValue Parameter" : "");

        SqlParameter[] cachedParameters;

        cachedParameters = (SqlParameter[])paramCache[hashKey];

        if (cachedParameters == null)
        {
            cachedParameters = (SqlParameter[])(paramCache[hashKey] = DiscoverSpParameterSet(connectionString, spName, includeReturnValueParameter));
        }

        return CloneParameters(cachedParameters);
    }

    #endregion Parameter Discovery Functions

    [WebMethod(MessageName = "GetHTN")]
    public HTN_Result GenHTN(string connectionString, string sProviderCode, int iFiletype)
    {
        DataSet objDtSet;
        string sQry = "SELECT COUNT(1) FROM t_FileMaster WHERE FileSeqId=" + iFiletype.ToString() + "";

        HTN_Result objHTNRslt = new HTN_Result();

        objDtSet = ExecuteDataset(connectionString, CommandType.Text, sQry);

        if (Convert.ToInt32(objDtSet.Tables[0].Rows[0][0]) == 0)
        {
            objHTNRslt.ResultCode = 1;
            objHTNRslt.ErrrorMessage = "Invalid File Type";
            return objHTNRslt;
        }

        sQry = "SELECT COUNT(1) FROM t_UserMaster WHERE UserCode='" + sProviderCode + "'";

        objDtSet = ExecuteDataset(connectionString, CommandType.Text, sQry);

        if (Convert.ToInt32(objDtSet.Tables[0].Rows[0][0]) == 0)
        {
            objHTNRslt.ResultCode = 2;
            objHTNRslt.ErrrorMessage = "Invalid Provider Code";
            return objHTNRslt;
        }

        SqlParameter[] spParms = new SqlParameter[3];
        spParms[0] = new SqlParameter("@ProviderID", SqlDbType.VarChar, 7);
        spParms[0].Value = sProviderCode;
        spParms[1] = new SqlParameter("@FileType", SqlDbType.Int);
        spParms[1].Value = iFiletype;
        spParms[2] = new SqlParameter("@HTN", SqlDbType.VarChar, 30);
        spParms[2].Direction = ParameterDirection.Output;

        ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "PMS_SP_HTNGen", spParms);

        objHTNRslt.HTN = spParms[2].Value.ToString();
        objHTNRslt.ResultCode = 0;

        return objHTNRslt;
    }

    [WebMethod(MessageName = "SavetheApplicationlastprocessedtime")]
    public int AppLastProcessedTime(string connectionString, string sAppName, float fDuration)
    {

        SqlParameter[] spParms = new SqlParameter[2];
        spParms[0] = new SqlParameter("@ApplicationName", SqlDbType.VarChar, 100);
        spParms[0].Value = sAppName;
        spParms[1] = new SqlParameter("@Duration", SqlDbType.VarChar, 10);
        spParms[1].Value = Convert.ToString(fDuration);
        return ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "PMS_SP_AppPulseInsert", spParms);
    }

    [WebMethod(MessageName = "SavetheApplicationlastprocessedtimeFromAppserver")]
    public int AppLastProcessedTime(string connectionString, string sAppName, float fDuration, DateTime datetime)
    {

        SqlParameter[] spParms = new SqlParameter[3];
        spParms[0] = new SqlParameter("@ApplicationName", SqlDbType.VarChar, 100);
        spParms[0].Value = sAppName;
        spParms[1] = new SqlParameter("@Duration", SqlDbType.VarChar, 10);
        spParms[1].Value = Convert.ToString(fDuration);
        spParms[2] = new SqlParameter("@LastRunTime", SqlDbType.DateTime);
        spParms[2].Value = datetime;
        return ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "PMS_SP_AppPulseInsert", spParms);
    }

    [WebMethod(MessageName = "ApplicationIntervalMail")]
    public int AppLastProcessedMail(string connectionString, string sAppName, int fDuration)
    {

        SqlParameter[] spParms = new SqlParameter[2];
        spParms[0] = new SqlParameter("@ApplicationName", SqlDbType.VarChar, 100);
        spParms[0].Value = sAppName;
        spParms[1] = new SqlParameter("@Duration", SqlDbType.VarChar, 10);
        spParms[1].Value = fDuration;
        return ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "PMS_SP_AppPulseIntervalMail", spParms);

    }

    // [WebMethod(MessageName = "ExecuteDatasetOverloadTieOut")]         
    public DataSet ExecuteDataset(SqlConnection connection, CommandType commandType, string commandText, int CommandTimeOut, params SqlParameter[] commandParameters)
    {
        //create a command and prepare it for execution
        SqlCommand cmd = new SqlCommand();
        cmd.CommandTimeout = 900000;
        PrepareCommand(cmd, connection, (SqlTransaction)null, commandType, commandText, commandParameters);

        //create the DataAdapter & DataSet
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        //fill the DataSet using default values for DataTable names, etc.
        da.Fill(ds);

        // detach the SqlParameters from the command object, so they can be used again.			
        cmd.Parameters.Clear();

        //return the dataset
        return ds;
    }
    [WebMethod(MessageName = "BulkInsertionFromDataTable2DataTable")]
    public void BulkInsertionForDataTable(String StrDestinationTable, DataTable DtSourceDataTable, string Connection)
    {

        using (SqlBulkCopy copy = new SqlBulkCopy(Connection))
        {
            copy.DestinationTableName = StrDestinationTable;
            copy.WriteToServer(DtSourceDataTable);
        }

    }
    //[WebMethod(MessageName = "ExecuteNonQuerywithCommand")]
    public int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText, SqlParameter[] commandParameters, int CommandTimeout)
    {
        //create & open a SqlConnection, and dispose of it after we are done.
        using (SqlConnection cn = new SqlConnection(connectionString))
        {
            cn.Open();

            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = CommandTimeout;

            //attach the command parameters if they are provided
            // SqlParameter[] Param = (SqlParameter[])commandParameters;


            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }

                    cmd.Parameters.Add(p);
                }

            }
            int retval = cmd.ExecuteNonQuery();
            cn.Close();
            return retval;
        }
    }

}
